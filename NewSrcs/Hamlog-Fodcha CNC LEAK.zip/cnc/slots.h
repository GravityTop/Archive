#pragma once

#include <stdint.h>

#include "rand.h"
#include "client.h"

#define GLOBAL_COOLDOWN_DURATION rand_next_range(12, 20)
#define ATTACK_SLOT_COUNT 2

struct attack_slot_t {
	char *username;
	time_t start, cooldown_start;
	uint32_t duration, cooldown;

	BOOL active, cooldown_active;
} typedef attack_slot_t;

void *attack_slot_handler(void *_);

void attack_slot_add(client_t *, uint32_t, uint32_t);

uint32_t attack_slot_get_cooldown(void);
uint32_t attack_slot_count(void);

BOOL attack_slot_is_empty(void);
BOOL attack_slot_is_open(void);
