#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bot.h"
#include "util.h"
#include "groups.h"

static bot_group_t *head = NULL;

bot_group_t *bot_group_create(char *name) {
	bot_group_t *group = calloc(1, sizeof(bot_group_t));
	group->name = strdup(name);
	group->count = 1;

	return group;
}

bot_group_t *bot_find_group(char *name) {
	bot_group_t *tmp = head;

	while (tmp) {
		if (!strcmp(tmp->name, name))
			return tmp;
		tmp = tmp->next;
	}

	return NULL;
}

void bot_group_add(char *name) {
	bot_group_t *group = bot_group_create(name);

	group->next = head;
	group->relative = 1;

	if (head)
		head->prev = group;

	head = group;
}

void bot_inc_group(char *name) {
	bot_group_t *group = bot_find_group(name);

	ATOMIC_INC(&bot_count);

	if (!group)
		return bot_group_add(name);

	group->relative++;

	ATOMIC_INC(&group->count);
}

void bot_delete_group(bot_group_t *group) {
	if (head == group)
		head = group->next;

	if (group->next)
		group->next->prev = group->prev;

	if (group->prev)
		group->prev->next = group->next;

	free(group);
}

void bot_list_count(int fd) {
	bot_group_t *group = head;

	while (group) {

		if (group->relative != 0) {
			util_sockprintf(fd, "%s(%s%d\x1b[0m): %d\r\n", 
				group->name, group->relative >= 0 ? "\x1b[92m+" : "\x1b[91m", group->relative, group->count);
		}
		else {
			util_sockprintf(fd, "%s: %d\r\n", group->name, group->count);
		}

		group->relative = 0;
		group = group->next;
	}
}

void bot_dec_group(char *name) {
	bot_group_t *group = bot_find_group(name);

	/* theoratically impossible */
	if (!group)
		return;

	ATOMIC_DEC(&bot_count);

	if (group->count == 1)
		return bot_delete_group(group);

	group->relative--;

	ATOMIC_DEC(&group->count);
}
