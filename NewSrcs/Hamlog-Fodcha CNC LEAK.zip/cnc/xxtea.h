#include <stdlib.h>

#define XXTEA_KEY_SIZE 16

void * xxtea_encrypt(const void * data, size_t len, const void * key, size_t * out_len);
void * xxtea_decrypt(const void * data, size_t len, const void * key, size_t * out_len);