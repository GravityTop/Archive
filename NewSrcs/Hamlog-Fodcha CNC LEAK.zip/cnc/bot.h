#pragma once

#include <stdint.h>

#include "bool.h"
#include "csum.h"
#include "main.h"

enum bot_disconnect_type_t {
	PING_TIMEOUT = 0,
	EXCHANGE_FAIL = 1,
	BOT_DISCONNECT = 2,
	PROTOCOL_FAIL = 3,
};

struct bot_t {
	int fd;

	enum {
		KEY_HANDOVER,
		VERIFY_EXCHANGE,
		VERIFYING,
		VERIFY_NAME,
		CONNECTED
	} state;

	csum_t hdr;

	uint16_t expected;
	uint8_t rdbuf[128];
	uint32_t bot_port;

	BOOL connected;

	uint16_t next_ping;
	time_t ping_timestamp;

	time_t resp_timestamp;

	uint8_t key[32];
	uint8_t nonce[12];

	char name[15];

} typedef bot_t;

void bot_list_latency(int);
void bot_update_timeout(bot_t *);
void bot_set_connected(bot_t *);
void bot_send_instruction(uint8_t);
void bot_generate_key(bot_t *);

BOOL bot_check_hdr_len(bot_t *, int);
BOOL bot_check_disconnected(bot_t *);

uint32_t bot_send_command(uint8_t, uint8_t *, uint16_t, char *, uint32_t);

void csum_confirm_exchange(bot_t *);
void csum_handover_key(bot_t *);
void csum_handover_nonce(bot_t *);

void bot_init(void);

bot_t *bot_get(int);
bot_t *bot_setup(int, uint16_t);

extern bot_t bots[MAX_CLIENTS];
extern uint32_t bot_count;
