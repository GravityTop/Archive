#pragma once

#define BOT_PING_MIN 250
#define BOT_PING_MAX 300

#define BOT_MAX_TIMEOUT 360

#define BOT_CNC_PORT 1025
#define USER_CNC_PORT 1026

#define MAX_CLIENTS 999999 /* ugly fix for now */
#define BOT_MAX_CLIENTS 999999

void *update_daily_client_attacks(void *);
