#pragma once

#include <stdint.h>

#define KEY_SIZE 32
#define NONCE_SIZE 12

void chacha20_xor(uint8_t key[KEY_SIZE], uint32_t, uint8_t nonce[NONCE_SIZE], uint8_t *, uint8_t *, int);
