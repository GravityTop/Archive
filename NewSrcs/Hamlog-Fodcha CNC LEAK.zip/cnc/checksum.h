#pragma once

#include <stdint.h>
#include <linux/ip.h>

uint16_t checksum_generic(void *, uint32_t);
uint16_t checksum_tcpudp(struct iphdr *, void *, uint16_t, int);
