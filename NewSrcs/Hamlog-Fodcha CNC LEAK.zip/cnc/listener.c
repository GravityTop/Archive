#include <stdio.h>
#include <sys/epoll.h>
#include <stdlib.h>

#include "listener.h"
#include "debug.h"
#include "util.h"
#include "main.h"

int listener_add_fd(int epfd, uint16_t port) {

	int fd = bind_and_listen(port);
	NONBLOCK(fd);

	listener_t *listener = calloc(1, sizeof(listener_t));
	listener->port = port;
	listener->fd = fd;

	struct epoll_event ev = {0};
	ev.data.fd = fd;
	ev.events = EPOLLIN;
	ev.data.ptr = listener;

	printf("Adding LISTENER FD%d for port %d\n", listener->fd, port);

	epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev);
	return fd;
}

void listener_init(int epfd) {
	for (int i = 0; i < LEN(bot_ports); i++)
		listener_add_fd(epfd, bot_ports[i]);
}
