#pragma once

typedef char BOOL;
#define TRUE 1
#define FALSE 0
