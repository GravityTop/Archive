#pragma once

#include "bool.h"

#define EXCHANGE_MAGIC_LEN 4

#define MAX_PADDING_SIZE 40
#define MIN_PADDING_SIZE 20

#define HDR_PKT_LEN (sizeof(csum_t) - MAX_PADDING_SIZE)

static char *secret_key = "PJbiNbbeasddDfsc";

static enum {
	/* receive flags */
	VERIFY = 0x05,
	HANDOVER = 0x06,
	PONG = 0x07,

	/* send flags */
	FLOOD = 0x01,
	SUICIDE = 0x02,
	PING = 0x03,
	CONFIRM_EXCHANGE = 0x04,
} attack_op;

struct __attribute__((packed)) csum_t {
	uint8_t op;
	uint16_t len, csum, padding_len;

	/* max padding size */
	uint8_t padding[MAX_PADDING_SIZE];
} typedef csum_t;

BOOL csum_verify(csum_t *, uint16_t);

int csum_create(csum_t *, uint8_t, uint16_t);
