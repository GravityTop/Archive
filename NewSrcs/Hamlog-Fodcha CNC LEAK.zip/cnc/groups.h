#pragma once

struct bot_group_t {
	char *name;
	uint32_t count;
	int32_t relative;

	struct bot_group_t *next, *prev;
} typedef bot_group_t;

void bot_inc_group(char *);
void bot_dec_group(char *);

void bot_list_count(int);
