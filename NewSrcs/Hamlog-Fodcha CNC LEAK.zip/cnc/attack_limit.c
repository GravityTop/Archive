#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>
#include <pthread.h>

#include "db.h"
#include "bool.h"
#include "debug.h"

void *update_daily_client_attacks(void *varg) {

	time_t t = time(NULL);
	struct tm last = *localtime(&t);

	while (TRUE) {

		/* we only have to check if the day changes */

		t = time(NULL);
		struct tm now = *localtime(&t);

		if (last.tm_mday != now.tm_mday) {
			PRINTF("Updating daily client attacks!\n");
			last.tm_mday = now.tm_mday;

			client_reset_daily_attacks();
		}

		sleep(1);
	}

	pthread_exit(0);
}
