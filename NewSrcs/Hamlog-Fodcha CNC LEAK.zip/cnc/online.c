#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "client.h"
#include "online.h"

client_t *clients = NULL;

void client_list_add(client_t *client) {

	if (!clients) {
		clients = client;
		return;
	}

	clients->prev = client;
	client->next = clients;

	clients = client;
}

void client_list_remove(client_t *client) {

	client_t *tmp = clients;

	if (clients == client)
		clients = clients->next;
	else {
		client->prev->next = client->next;
	}

	free(client);
}

BOOL client_exists(char *username) {

	client_t *tmp = clients;

	if (!tmp)
		return FALSE;

	while (tmp) {
		if (!strcmp(tmp->username, username))
			return TRUE;

		tmp = tmp->next;
	}

	return FALSE;
}
