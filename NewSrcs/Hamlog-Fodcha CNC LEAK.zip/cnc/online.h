#pragma once

void client_list_add(client_t *);
void client_list_remove(client_t *);

BOOL client_exists(char *);
