#pragma once

#include <stdint.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <linux/tcp.h>
#include <sys/socket.h>

#include "bool.h"

/*
	https://gcc.gnu.org/onlinedocs/gcc-5.1.0/gcc/_005f_005fatomic-Builtins.html
	https://gcc.gnu.org/wiki/Atomic/GCCMM/AtomicSync
*/

#define ISDIGIT(x) ((x >= '0' && x <= '9'))
#define ISALPHA(x) ((x >= 'a' && x <= 'z') || (x >= 'A' && x <= 'Z'))

#define MEMORDER __ATOMIC_SEQ_CST

/* shortcuts here */
#define CONVERT_ADDR(x) x & 0xff, (x >> 8) & 0xff, (x >> 16) & 0xff, (x >> 24) & 0xff
#define NODELAY(fd, val) (setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &(int){val}, sizeof(int)))
#define BLOCK(x) (fcntl(x, F_SETFL, fcntl(x, F_GETFL, 0) ^ O_NONBLOCK))
#define NONBLOCK(fd) fcntl(fd, F_SETFL, O_NONBLOCK)
#define LEN(x) (sizeof(x) / sizeof(*x))

#define ATOMIC_GET(ptr) __atomic_load_n(ptr, MEMORDER)

#define ATOMIC_SET(ptr, val) __atomic_store_n(ptr, val, MEMORDER)

#define ATOMIC_INC(ptr) __atomic_fetch_add(ptr, 1, MEMORDER)
#define ATOMIC_DEC(ptr) __atomic_fetch_sub(ptr, 1, MEMORDER)

#define ATOMIC_ADD(ptr, x) __atomic_fetch_add(ptr, x)
#define ATOMIC_SUB(ptr, x) __atomic_fetch_sub(ptr, x)

/* declarations here */
int epoll_mod(int, char, int, int);

int bind_and_listen(uint16_t);

void util_strip(char *);
void util_split_free(char **, int);

int util_split(const char *, char, char ***);
int util_count(char *, char, int);
int util_sockprintf(int, const char *, ...);
int fdgets(int, unsigned char *, int);

BOOL util_isdigit(char *);
BOOL is_valid_name(char *);
BOOL is_alpha_str(char *);
BOOL is_normal_str(char *);
BOOL util_startswith(char *, char *);
