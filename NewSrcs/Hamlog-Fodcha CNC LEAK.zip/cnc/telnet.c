#include <stdio.h>
#include <arpa/inet.h>
#include <string.h>

#include "util.h"
#include "client.h"

void telnet_send_query(client_t *client) {
	send(client->fd, "\033[?1049h", strlen("\033[?1049h"), MSG_NOSIGNAL);
	send(client->fd, "\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22", 9, MSG_NOSIGNAL);
}

BOOL handle_iacs(client_t *client) {

	uint8_t iac;

	while (TRUE) {
		int r = recv(client->fd, &iac, 1, MSG_NOSIGNAL);

		if (r <= 0)
			return FALSE;

		/* idk, just black telnet voodoo */
		switch (iac) {
			case 0x03:
			case 0xfd:
			case 0xff:
			case 0xfb:
			case 0xfc:
			case 0x01:
			case 0x0d:
			case 0x1f:
			case 0x20:
			case 0x18:
			case 0x27:
				break;
			default:
				return TRUE;
		}
	}

	return TRUE;
}

int telnet_wait_for(client_t *client, char *buff, int len, BOOL hidden) {
	char ch;
	int pos = 0;

	while (pos < len) {

		int r = recv(client->fd, &ch, 1, MSG_NOSIGNAL);

		if (r <= 0)
			return -1;

		switch (ch) {
			case '\xFF': {
				int r = recv(client->fd, &ch, 1, MSG_NOSIGNAL);
				break;
			}

			case '\x7F':
			case '\x08': {
				if (pos > 0) {
					buff[pos--] = 0;
					send(client->fd, "\b \b", 3, MSG_NOSIGNAL);
				}

				break;
			}

			case '\r':
			case '\t': {
				if (pos > 0) {
					pos--;
				}
				break;
			}

			case '\n':
			case '\x00': {
				send(client->fd, "\r\n", 2, MSG_NOSIGNAL);
				return pos + 1;
			}

			case '\x03': {
				send(client->fd, "^C\r\n", 4, MSG_NOSIGNAL);
				return 1;
			}

			default: {
				buff[pos++] = ch;

				if (hidden) {
					send(client->fd, "*", 1, MSG_NOSIGNAL);
				}
				else {
					util_sockprintf(client->fd, "%c", ch);
					break;
				}
			}
		}
	}

	return -1;
}
