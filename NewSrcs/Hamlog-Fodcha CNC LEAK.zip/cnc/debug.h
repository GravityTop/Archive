#pragma once

#ifdef DEBUG
#define PRINTF(args, ...) printf("[%s] " args, __FILE__, ##__VA_ARGS__)
#else
#define PRINTF(args, ...)
#endif

#define WRITE(args) write(1, args, util_strlen(args));
