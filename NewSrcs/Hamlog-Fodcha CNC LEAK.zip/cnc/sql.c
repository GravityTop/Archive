#define _GNU_SOURCE

#include <sqlite3.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "db.h"
#include "util.h"
#include "client.h"

BOOL sql_renew_hour(char *username, int expiry_hours) {

    char *sql_query = NULL;
    asprintf(&sql_query, "UPDATE botnet SET expiry = %ld WHERE username = '%s'", 
        time(0) + (expiry_hours * 3600), username);

    int rc = sqlite3_exec(conn, sql_query, 0, 0, NULL);
    free(sql_query);
}


BOOL sql_renew_user(char *username, int expiry_days) {

    char *sql_query = NULL;
    asprintf(&sql_query, "UPDATE botnet SET expiry = %ld WHERE username = '%s'", 
        time(0) + (expiry_days * 86400), username);

    int rc = sqlite3_exec(conn, sql_query, 0, 0, NULL);
    free(sql_query);
}

BOOL sql_delete_user(char *username) {
 
    char *sql_query = NULL;
    asprintf(&sql_query, "DELETE FROM botnet WHERE username = '%s'", username);

    int rc = sqlite3_exec(conn, sql_query, 0, 0, NULL);
    free(sql_query);
}

BOOL sql_mod_daily_attacks(char *username, int attacks) {

    char *sql_query = NULL;
    asprintf(&sql_query, "UPDATE botnet SET daily_attacks = %d AND daily_attacks_left = %d where username = '%s'", attacks, attacks, username);

    int rc = sqlite3_exec(conn, sql_query, 0, 0, NULL);
    free(sql_query);
}

BOOL sql_mod_floods(char *username, char *floods) {

    char *sql_query = NULL;
    asprintf(&sql_query, "UPDATE botnet SET floods = '%s' where username = '%s'", floods, username);

    int rc = sqlite3_exec(conn, sql_query, 0, 0, NULL);
    free(sql_query);
}

BOOL sql_insert_user(char *username, char *password, char *is_admin, char *is_seller, int attack_time, int cooldown, int daily_attacks, int expiry_days) {

    char *sql_query = NULL;
    asprintf(&sql_query, "INSERT INTO botnet (username, password, is_admin, is_seller, max_bots, floods, attack_time, cooldown, daily_attacks, daily_attacks_left, expiry) VALUES (\"%s\", \"%s\", \"%s\", %s, 999999, \"" DEFAULT_CLIENT_FLOODS "\", %d, %d, %d, %d, %ld);", 
        username, password, is_admin, is_seller,attack_time, cooldown, daily_attacks, daily_attacks, time(0) + (expiry_days * 86400));

    int rc = sqlite3_exec(conn, sql_query, 0, 0, NULL);
    free(sql_query);
}

void sql_get_text_val(char *username, char *field, const char **text) {
    sqlite3_stmt *res;

    char *sql_query = NULL;
    asprintf(&sql_query, "SELECT %s FROM botnet WHERE username = ?", field);

    int rc = sqlite3_prepare_v2(conn, sql_query, -1, &res, 0);

    if (sql_query)
        free(sql_query);

    if (rc != SQLITE_OK) {
        sqlite3_finalize(res);
        return;
    }

    /* bind the arguments */
    sqlite3_bind_text(res, 1, username, strlen(username), NULL);

    int step = sqlite3_step(res);

    if (step != SQLITE_ROW) {
        sqlite3_finalize(res);
        return;
    }

    *text = sqlite3_column_text(res, 0);

    sqlite3_finalize(res);
}

int sql_get_int_val(char *username, char *field) {
    sqlite3_stmt *res;

    char *sql_query = NULL;
    asprintf(&sql_query, "SELECT %s FROM botnet WHERE username = ?", field);

	int rc = sqlite3_prepare_v2(conn, sql_query, -1, &res, 0);

	if (sql_query)
		free(sql_query);

    if (rc != SQLITE_OK) {
        sqlite3_finalize(res);
    	return -1;
    }

    /* bind the arguments */
    sqlite3_bind_text(res, 1, username, strlen(username), NULL);

    int step = sqlite3_step(res);

    if (step != SQLITE_ROW) {
        sqlite3_finalize(res);
    	return -1;
    }

    int val = sqlite3_column_int(res, 0);

    sqlite3_finalize(res);

    return val;
}

BOOL sql_set_int_val(char *username, char *field, int val) {
    sqlite3_stmt *res;

    char *sql_query = NULL;
    asprintf(&sql_query, "UPDATE botnet SET %s = ? WHERE username = ?", field);

	int rc = sqlite3_prepare_v2(conn, sql_query, -1, &res, 0);

	if (sql_query)
		free(sql_query);

    if (rc != SQLITE_OK) {
        sqlite3_finalize(res);
    	return FALSE;
    }

    /* bind the arguments */
    sqlite3_bind_int(res, 1, val);
    sqlite3_bind_text(res, 2, username, strlen(username), NULL);

    int step = sqlite3_step(res);

    if (step != SQLITE_ROW) {
        sqlite3_finalize(res);
    	return FALSE;
    }

    sqlite3_finalize(res);

    return TRUE;
}
