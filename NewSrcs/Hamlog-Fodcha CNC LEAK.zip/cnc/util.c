#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdarg.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "util.h"
#include "bool.h"
#include "main.h"

int fdgets(int fd, unsigned char *buffer, int bufferSize) {
	int total = 0, got = 1;
	while(got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
	return got;
}

BOOL util_isdigit(char *str) {

	while (*str) {

		if (!ISDIGIT(*str++))
			return FALSE;
	}

	return TRUE;
}

BOOL is_valid_name(char *x) {
	while (*x) {
		char c = *x++;

		if (!ISALPHA(c) && !ISDIGIT(c) && c != '.')
			return FALSE;
	}

	return TRUE;
}

BOOL is_normal_str(char *x) {
	while (*x) {
		char c = *x++;

		if (!ISALPHA(c) && !ISDIGIT(c))
			return FALSE;
	}

	return TRUE;
}

BOOL is_alpha_str(char *x) {
	while (*x) {
		if (!ISALPHA(*x++))
			return FALSE;
	}

	return TRUE;
}

int epoll_mod(int epfd, char mod, int fd, int events) {
	struct epoll_event ev = {0};
	ev.data.fd = fd;
	ev.events = events;

	return epoll_ctl(epfd, mod, fd, &ev);
}

void util_strip(char *buff) {
	while (*buff) {
		if (*buff == '\r' || *buff == '\n')
			*buff = 0;
		buff++;
	}
}

int util_count(char *buff, char ch, int def_val) {
	int count = def_val;

	while (*buff) {
		if (*buff++ == ch)
			count++;
	}

	return count;
}

int bind_and_listen(uint16_t port) {

	int fd = socket(AF_INET, SOCK_STREAM, 0);

	struct sockaddr_in addr = {0};
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = INADDR_ANY;

	setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int));

	if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) {
		perror("BIND");
		exit(1);
	}

	if (listen(fd, SOMAXCONN) == -1) {
		perror("LISTEN");
		exit(1);
	}

	return fd;
}

BOOL util_startswith(char *haystack, char *needle) {
	while (*needle) {
		if (*haystack++ != *needle++)
			return FALSE;
	}

	return TRUE;
}

int util_sockprintf(int fd, const char *fmt, ...) {
	char *buff;

	va_list args;

	va_start(args, fmt);

	int len = vasprintf(&buff, fmt, args);

	va_end(args);

	int r = send(fd, buff, len, MSG_NOSIGNAL);
	free(buff);

	return r;
}

void util_split_free(char **tokens, int count) {
    int i = 0;

    for (i = 0; i < count; i++)
        free(tokens[i]);

    free(tokens);
}

int util_split(const char *txt, char delim, char ***tokens) {
    int *tklen, *t, count = 1, in_quotes = 0;
    char **arr, *p = (char *) txt;

    while (*p != '\0') {
        char c_ptr = *p++;

        if (c_ptr == '"' && in_quotes == 0)
            in_quotes = 1;
        else if (c_ptr == '"' && in_quotes == 1)
            in_quotes = 0;

        if (c_ptr == delim && in_quotes == 0)
            count += 1;
    }

    in_quotes = 0;
    t = tklen = calloc(count, sizeof (int));
    for (p = (char *) txt; *p != '\0'; p++) {
        char c_ptr = *p;

        if (c_ptr == '"' && in_quotes == 0)
            in_quotes = 1;
        else if (c_ptr == '"' && in_quotes == 1)
            in_quotes = 0;

        if (c_ptr == delim && in_quotes == 0)
            *p == delim ? *t++ : (*t)++;
        else
            (*t)++;
    }

    in_quotes = 0;
    *tokens = arr = malloc(count * sizeof (char *));
    t = tklen;
    p = *arr++ = calloc(*(t++) + 1, sizeof (char *));

    while (*txt != '\0') {
        if (*txt == '"' && in_quotes == 0)
            in_quotes = 1;
        else if (*txt == '"' && in_quotes == 1)
            in_quotes = 0;

        if (*txt == delim && in_quotes == 0) {
            p = *arr++ = calloc(*(t++) + 1, sizeof (char *));
            txt++;
        }
        else
            *p++ = *txt++;
    }

    return count;
}
