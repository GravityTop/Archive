#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#include "client.h"
#include "bool.h"
#include "util.h"
#include "slots.h"

attack_slot_t attack_slots[ATTACK_SLOT_COUNT] = {0};

attack_slot_t *attack_get_empty(void) {
	for (int i = 0; i < ATTACK_SLOT_COUNT; i++) {
		attack_slot_t *slot = &attack_slots[i];

		if (ATOMIC_GET(&slot->active))
			continue;

		return slot;
	}

	return NULL;
}

void attack_slot_add(client_t *client, uint32_t duration, uint32_t cooldown) {
	attack_slot_t *slot = attack_get_empty();

	if (!slot)
		return;

	slot->active = TRUE;
	slot->username = strdup(client->username);

	slot->start = time(0);
	slot->duration = duration;
	slot->cooldown = cooldown;
}

BOOL attack_slot_is_empty(void) {
	return !attack_slot_count();
}

uint32_t attack_slot_count(void) {
	uint32_t count = 0;

	for (int i = 0; i < ATTACK_SLOT_COUNT; i++) {
		attack_slot_t *slot = &attack_slots[i];

		if (ATOMIC_GET(&slot->active))
			++count;
	}

	return count;
}

BOOL attack_slot_is_open(void) {
	for (int i = 0; i < ATTACK_SLOT_COUNT; i++) {
		attack_slot_t *slot = &attack_slots[i];

		if (!ATOMIC_GET(&slot->active))
			return TRUE;
	}

	return FALSE;
}

void attack_slot_expire(attack_slot_t *slot) {
	slot->active = FALSE;
	slot->duration = 0;

	slot->cooldown_start = time(0);
}

void attack_slot_free(attack_slot_t *slot) {

	slot->cooldown = 0;
	slot->cooldown_start = 0;

	if (slot->username)
		free(slot->username);	
}

uint32_t attack_slot_get_cooldown(void) {
	for (int i = 0; i < ATTACK_SLOT_COUNT; i++) {
		attack_slot_t *slot = &attack_slots[i];

		if (ATOMIC_GET(&slot->active))
			continue;

		if ((slot->cooldown_start + slot->cooldown) > time(0))
			return (slot->cooldown_start + slot->cooldown) - time(0);
	}

	return 0;
}

void *attack_slot_handler(void *varg) {
	while (TRUE) {
		for (int i = 0; i < ATTACK_SLOT_COUNT; i++) {
			attack_slot_t *slot = &attack_slots[i];

			if (!ATOMIC_GET(&slot->active)) {

				/* actually free the global cooldown aswell, removing lock */
				if (slot->cooldown > 0 && time(0) >= slot->cooldown_start + slot->cooldown)
					attack_slot_free(slot);

				continue;
			}

			if (time(0) >= slot->start + slot->duration) {
				attack_slot_expire(slot);
				continue;
			}
		}

		sleep(1);
	}
}
