#pragma once

#include <stdint.h>

uint32_t rand_next(void);
uint32_t rand_next_range(uint32_t, uint32_t);

void rand_init(void);

void rand_str(char *, int);
void rand_alphastr(char *, int);
void rand_urandom(char *, int);
