PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE `users` (
              `id` INTEGER PRIMARY KEY AUTOINCREMENT,
              `username` TEXT NOT NULL,
              `password` BLOB NOT NULL,
              `salt` BLOB NOT NULL,
              `admin` BOOLEAN DEFAULT FALSE,
              `parent` INTEGER DEFAULT 0
);
INSERT INTO users VALUES(2,'root',X'd7b02124e1e46dbe111298b3c7846fcff5963c4ac44704767e475da2cab0be3b5c4dfcbc7024c63373dece439b7a7bc4c54e29cf1c9e5fb12b0db8195e5b154d',X'f3cb4c852ae43d83',1,0);
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('users',2);
COMMIT;