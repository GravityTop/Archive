package main

import (
	"hajime/source"
	"hajime/source/db"
	"hajime/source/masters"
	"log"
)

func main() {
	log.Printf("[Hajime is initializing] [%s]\r\n", source.Version)

	if err := db.Conn.Connect(); err != nil {
		log.Fatalf("(db/Connect) %v\r\n", err)
	}

	go source.Serve()

	if err := masters.Configure(); err != nil {
		log.Fatalf("(masters/Configure) %v\r\n", err)
	}
}