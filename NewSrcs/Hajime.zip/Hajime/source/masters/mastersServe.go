package masters

import (
	"fmt"
	"log"
	"net"
)

//Serve listens for operator connections
func (s *Server) Serve() error {
	listener, err := net.Listen("tcp", fmt.Sprintf("%s:%d", s.Config.Listener, s.Config.Port))
	if err != nil {
		return err
	}

	defer listener.Close()
	log.Printf("[Master connection watcher started] [%s]\n", fmt.Sprintf("%s:%d", s.Config.Listener, s.Config.Port))

	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Println("(masters/Serve)", err)
			continue
		}

		go s.handle(conn)
	}
}