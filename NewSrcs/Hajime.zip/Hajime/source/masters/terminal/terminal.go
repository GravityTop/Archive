package terminal

import (
	"io"
	"sync"

	"golang.org/x/crypto/ssh"
	"golang.org/x/term"
)

// Terminal represents a connection with the CNC
type Terminal struct {
	conn  *ssh.ServerConn
	mutex sync.Mutex
	wr    io.ReadWriter

	term  *term.Terminal
}

// New declares the terminal and it's parameters
func New(wr io.ReadWriter, conn *ssh.ServerConn) *Terminal {
	return &Terminal{
		term: term.NewTerminal(wr, ""),
		conn: conn,
		wr: wr,
	}
}

// Close will forceful shut the session
func (term *Terminal) Close() error {
	return term.conn.Close()
}