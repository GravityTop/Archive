package commands

import "hajime/source/masters/sessions"

func init() {
	Register(&Command{
		Name:          "clear",
		Description:   "clears your terminal screen",
		Execute: func(session *sessions.Session, args []string) error {
			return session.ExecuteBranding(make(map[string]any), "resources", "branding", "clear_splash.tfx")
		},
	})
}