package commands

import (
	"encoding/binary"
	"hajime/source"
	"hajime/source/masters/sessions"
)

func init() {
	Register(&Command{
		Name:        "update",
		Description: "updates all the binaries distributed",
		Admin:       true,
		Execute: func(session *sessions.Session, _ []string) error {
			payload := make([]byte, 4)
			binary.BigEndian.PutUint16(payload, 4)
			payload = append(payload, []byte(source.Options.String("server", "server.application", "server.application.slaves" ,"server.application.slaves.payload"))...)
			devices := source.Broadcast(payload, -1)

			return session.ExecuteBranding(map[string]any{"sent_too": devices}, "resources", "branding", "updated.tfx")
		},
	})
}