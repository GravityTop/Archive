package sessions

import (
	"errors"
	"hajime/modules/tinyKaboom"
	"hajime/source"
	"path/filepath"
)

// ExecuteBranding will indirectly execute the tinyKaboom
func (session *Session) ExecuteBranding(objects map[string]any, branding ...string) error {
	kaboom := tinykaboom.New()
	if err := session.sync(kaboom); err != nil {
		return err
	}

	/* ranges through the objects and places them into memory */
	for key, value := range objects {
		ok := kaboom.Var(key, value)
		if ok {
			continue
		}

		return errors.New("duplictate object")
	}
	
	content, ok := source.Options.Config.Renders[filepath.Join(branding...)]
	if !ok {
		return errors.New("branding not found")
	}

	_, err := kaboom.Interpreter(session.Term).Execute(string(content))
	return err
}

// ExecuteBrandingToString will directly execute to the out
func (session *Session) ExecuteBrandingToString(objects map[string]any, branding ...string) (string, error) {
	kaboom := tinykaboom.New()
	if err := session.sync(kaboom); err != nil {
		return "", err
	}

	/* ranges through the objects and places them into memory */
	for key, value := range objects {
		ok := kaboom.Var(key, value)
		if ok {
			continue
		}

		return "", errors.New("duplictate object")
	}

	content, ok := source.Options.Config.Renders[filepath.Join(branding...)]
	if !ok {
		return "", errors.New("branding not found")
	}

	return kaboom.Interpreter(session.Term).ExecuteString(string(content))
}

// sync will append a bunch of filler objects to the map
func (s *Session) sync(kaboom *tinykaboom.TinyKaboom) error {
	if !kaboom.Struct(*s.User, "user") {
		return errors.New("duplicate object")
	}

	if !kaboom.Func("clear", func() string { return "\x1bc" }) {
		return errors.New("duplicate object")
	}

	if !kaboom.Func("devices", func() int { return len(source.Clone()) }) {
		return errors.New("duplicate object")
	}

	kaboom.Var("online", len(Sessions))
	kaboom.Var("name", source.Options.String("server", "server.application", "server.application.name"))
	return nil
}