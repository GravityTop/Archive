package sessions

import (
	"crypto/rand"
	"encoding/binary"
	"hajime/source/db"
	"hajime/source/masters/terminal"
	"sync"
	"time"
)

var (
	Sessions = make(map[uint32]*Session)
	mutex    sync.Mutex
)

// Session represents a authenticated session
type Session struct {
	id   uint32
	Term *terminal.Terminal
	User *db.User

	Connected time.Time
}

// New will make a session structure
func New(term *terminal.Terminal, user *db.User) *Session {
	return &Session{
		Term: term,
		User: user,

		Connected: time.Now(),
	}
}

// Add will insert the session into the sessions map
func (s *Session) Add() error {
	mutex.Lock()
	defer mutex.Unlock()
	buf := make([]byte, 4)
	if len(Sessions) == 0 {
		go s.ServeWorker()
	}

	for {
		if _, err := rand.Read(buf); err != nil {
			return err
		}

		id := binary.BigEndian.Uint32(buf)
		if _, ok := Sessions[id]; !ok {
			s.id = id
			Sessions[id] = s
			return nil
		}
	}
}

// Remove will delete the session from the map
func (s *Session) Remove() {
	mutex.Lock()
	defer mutex.Unlock()

	delete(Sessions, s.id)
}