package source

// Attack specifies a flood and it's options
type Attack struct {
	Description string `json:"description"`
	MethodID    uint   `json:"method_id"`
	Flags       []uint `json:"flags"`
}

// Flag is a customizable component of a Attack
type Flag struct {
	Name        string 
	ID          uint   `json:"id"`
	Description string `json:"description"`
	Regexp      string `json:"regexp"`
}

// List of all attack methods
var Attacks map[string]*Attack = make(map[string]*Attack)

// Flags are the customizable options for floods
var Flags map[string]*Flag = make(map[string]*Flag)

// GetFlagID will obtain the flag through it's ID
func GetFlagID(id uint) *Flag {
	for name, flag := range Flags {
		if flag.ID != id {
			continue
		}

		flag.Name = name
		return flag
	}
	
	return nil
}