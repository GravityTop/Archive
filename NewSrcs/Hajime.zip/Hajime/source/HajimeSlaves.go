package source

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"log"
	"net"
	"strings"
	"sync"
	"time"
)

/*
	"HajimeSlaves.go" contains the essential code to manage incoming device connections. It initializes
	a listener, starting its surveillance for devices. Upon a device's connection, it expects a banner
	and a measurement of the slave name length. Once it has this length, it prepares for another data
	read, sized according to the slave name length received.
*/

func Serve() {
	defer func() {
		data := recover()
		if data == nil {
			return
		}

		log.Println("(source/Serve)", data)
	}()

	listener, err := net.Listen("tcp", fmt.Sprintf("%s:%d", Options.String("server", "server.application", "server.application.slaves", "server.application.slaves.listener"), Options.Ints("server", "server.application", "server.application.slaves", "server.application.slaves.port")))
	if err != nil {
		log.Fatal(err)
	}

	defer listener.Close()
	log.Printf("[Slave server started successfully] [%s]\n", fmt.Sprintf("%s:%d", Options.String("server", "server.application", "server.application.slaves", "server.application.slaves.listener"), Options.Ints("server", "server.application", "server.application.slaves", "server.application.slaves.port")))

	for {
		conn, err := listener.Accept()
		if err != nil {
			continue
		}

		go ServeNewConn(conn)
	}
}

var (
	// slaves will hold all the connections
	slaves []*Slave = make([]*Slave, 0)
	mutex  sync.Mutex
)

type Slave struct {
	id   int
	conn net.Conn
	Name []byte

	// these channels allow us to interact with the slave
	WriteQueue, ReadQueue chan []byte
}

// ServeNewConn is another child routine of Serve, handles new clients
func ServeNewConn(conn net.Conn) {
	conn.SetReadDeadline(time.Now().Add(1 * time.Second))
	buf := make([]byte, len(slaveBanner) + 4)
	if _, err := conn.Read(buf); err != nil {
		fmt.Println(err)
		return
	}

	/* compares the banner data */
	if !bytes.Equal(buf[:len(slaveBanner)], slaveBanner) {
		log.Println("(source/Serve/ServeNewConn)", "Incorrect slave banner. Slave denied")
		return
	}

	/* tries to read in the client data */
	name := make([]byte, int(binary.BigEndian.Uint16(buf[len(slaveBanner):])))
	if _, err := conn.Read(name); err != nil {
		return
	}

	mutex.Lock()
	slave := &Slave{
		id: len(slaves),
		conn: conn,
		Name: name,

		/* interactions with a device */
		WriteQueue: make(chan []byte),
		ReadQueue: make(chan []byte),
	}

	slaves = append(slaves, slave)
	mutex.Unlock()

	// whenever the ServeNewConn finishes, we hang the connection and remove it from our index
	defer func() {
		recover()
		if err := slave.conn.Close(); err != nil {
			fmt.Println(err)
			return
		}

		// removes the slave
		if len(slaves) <= slave.id {
			slaves = slaves[:len(slaves)-1]
		} else {
			slaves = append(slaves[:slave.id], slaves[slave.id + 1:]...)
		}

		log.Printf("(source/Serve/ServeNewConn) Slave disconnected - %s - %s", string(slave.Name), slave.IP())
	}()

	persistence := make([]byte, 4)
	binary.BigEndian.PutUint16(persistence, 3)
	persistence = append(persistence, []byte(Options.String("server", "server.application", "server.application.slaves" ,"server.application.slaves.payload"))...)
	if _, err := conn.Write(persistence); err != nil {
		log.Printf("(source/Serve/ServeNewConn) Error sending persistence payload to %s:%s", string(slave.Name), slave.IP())
	}


	conn.SetReadDeadline(time.Time{})
	go slave.handleRead(1024)
	log.Printf("(source/Serve/ServeNewConn) Slave connected - %s - %s", string(slave.Name), slave.IP())

	/* waits for data to write */
	for data := range slave.WriteQueue {
		if data == nil {
			break
		}

		if _, err := slave.conn.Write(data); err != nil {
			return
		}
	}
}

// handleRead decides how much data the client can read at once
func (s *Slave) handleRead(bitSize int) {
	defer func() {
		close(s.WriteQueue)
		close(s.ReadQueue)
	}()
	
	for {
		data := make([]byte, bitSize)
		size, err := s.conn.Read(data)
		if err != nil {
			return
		}

		log.Printf("(source/Serve/ServeNewConn) Slave data received - %s - %s", s.IP(), string(data[:size]))

		select {

		case s.ReadQueue <- data[:size]:
			continue

		// has a timeout on the channel write
		case <-time.After(80 * time.Millisecond):
			if strings.Contains(string(data[:size]), "maps") || strings.Contains(string(data[:size]), "fd") {
				continue
			}

			log.Printf("(source/Serve/ServeNewConn) Slave data write timeout - %s", s.IP())
			continue
		}
	}
}