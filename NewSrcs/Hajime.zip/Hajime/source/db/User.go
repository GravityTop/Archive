package db

import (
	"bytes"
	"errors"
)

type User struct {
	ID       int
	Username string
	Password []byte
	Salt     []byte
	Admin    bool
	Parent   int
}

// NewUser will make a brand new user inside the database
func (conn *DB) NewUser(self, user *User) (err error) {
	if user, err := conn.GetUser(user.Username); user != nil && err == nil {
		return errors.New("duplicate user")
	}

	user.Salt = *NewSalt(8)
	user.Password = NewHash(user.Password, &user.Salt)
	statement, err := conn.conn.Prepare("INSERT INTO `users` (`id`, `username`, `password`, `salt`, `admin`, `parent`) VALUES (NULL, ?, ?, ?, ?, ?)")
	if err != nil {
		return err
	}

	defer statement.Close()
	if _, err := statement.Exec(user.Username, user.Password, user.Salt, user.Admin, self.ID); err != nil {
		return err
	}
	
	return
}

// GetUser will try find the user inside the database
func (conn *DB) GetUser(user string) (*User, error) {
	statement, err := conn.conn.Prepare("SELECT `id`, `username`, `password`, `salt`, `admin`, `parent` FROM `users` WHERE `username` = ?")
	if err != nil {
		return nil, err
	}

	defer statement.Close()
	return conn.ScanUser(statement.QueryRow(user))
}

// GetUsers will find all the users this user has permissions over.
func (conn *DB) GetUsers(self *User) ([]*User, error) {
	statement, err := conn.conn.Prepare("SELECT `id`, `username`, `password`, `salt`, `admin`, `parent` FROM `users` WHERE `parent` = ?")
	if err != nil {
		return nil, err
	}

	defer statement.Close()
	query, err := statement.Query(self.ID)
	if err != nil {
		return nil, err
	}

	users := make([]*User, 0)

	defer query.Close()
	for query.Next() {
		user, err := conn.ScanUser(query)
		if err != nil || user.ID == self.ID {
			continue 
		}

		children, err := conn.GetUsers(user)
		if err != nil {
			continue
		}

		users = append(users, append(children, user)...)
	}

	return users, nil
}

// GetUserSelf will look for the users as it's parent instead as a friend
func (conn *DB) GetUserSelf(self *User, user string) (*User, error) {
	scope, err := conn.GetUsers(self)
	if err != nil {
		return nil, err
	}

	for _, user := range scope {
		if user.Username != self.Username {
			continue
		}

		return user, nil
	}

	return nil, errors.New("user not found")
}

// DeleteUser will remove the user from the database
func (conn *DB) DeleteUser(self, user *User) (err error) {
	user, err = conn.GetUserSelf(self, user.Username)
	if err != nil || user == nil {
		return err
	}

	statement, err := conn.conn.Prepare("DELETE FROM `users` WHERE `id` = ?")
	if err != nil {
		return err
	}

	defer statement.Close()
	if _, err := statement.Exec(user.ID); err != nil {
		return err
	}

	return
}

// IsPassword compares the password hashed with the orginal password of the user
func (user *User) IsPassword(password []byte) bool {
	return bytes.Equal(NewHash(password, &user.Salt), user.Password)
}

// ScanUser will grab the data which the query keeps
func (conn *DB) ScanUser(query Query) (*User, error) {
	user := new(User)
	err := query.Scan(
		&user.ID,
		&user.Username, 
		&user.Password,
		&user.Salt,
		&user.Admin,
		&user.Parent,
	)

	return user, err
}