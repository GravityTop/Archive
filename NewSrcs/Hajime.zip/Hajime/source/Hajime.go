package source

import (
	"encoding/json"
	"hajime/modules/goconfig"
	"log"
	"path/filepath"
)

// Version represents the current version of this application
const Version string = "v0.0"

// Options declares a brand new config worker
var Options *goconfig.Options = &goconfig.Options{
	Config: goconfig.NewConfig(),
}

// slaveBanner is what a device must define before connecting
var slaveBanner []byte = []byte{0, 1, 4, 3, 2}

// on initialization we try to open the config
func init() {
	Options.Config.NewInclusion(".json", func(content []byte, file string, m map[string]any) error {
		switch file {

		case filepath.Join("resources", "attacks", "attacks.json"):
			Attacks = make(map[string]*Attack)
			return json.Unmarshal(content, &Attacks)

		case filepath.Join("resources", "attacks", "flags.json"):
			Flags = make(map[string]*Flag)
			return json.Unmarshal(content, &Flags)

		default:
			return json.Unmarshal(content, &m)
		}
	})

	err := Options.Config.Parse("resources")
	if err != nil {
		log.Fatal(err)
	}

	Options, err = Options.Config.Options()
	if err != nil {
		log.Fatal(err)
	}
}