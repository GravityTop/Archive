package source

import (
	"errors"
	"log"
	"math/rand"
	"net"
	"time"
)

// IP will return the slaves ip address
func (s *Slave) IP() string {
	ip, _, err := net.SplitHostPort(s.conn.RemoteAddr().String())
	if err == nil {
		return ip
	}

	log.Println("(source/Serve/ServeNewConn/IP)", err)
	return s.conn.RemoteAddr().String()
}

// Write doesn't write to the conn, it writes to the channels which forwards to the conn
func (s *Slave) Write(payload []byte) error {
	select {

	case s.WriteQueue <- payload:
		return nil

	case <-time.After(80 * time.Millisecond):
		return errors.New("write timeout")
	}
}

// CloneTypes will return all the unique types connected and how many
func CloneTypes() map[string]int {
	allClients := Clone()
	if len(allClients) == 0 {
		return make(map[string]int)
	}

	clients := make(map[string]int)
	for _, client := range allClients {
		if len(client.Name) == 0 {
			client.Name = []byte("Unknown")
		}

		conn, ok := clients[string(client.Name)]
		if !ok {
			clients[string(client.Name)] = 1
			continue
		}

		clients[string(client.Name)] = conn + 1
	}

	return clients
}

// Clone will copy the clients array and return it
func Clone() []Slave {
	mutex.Lock()
	defer mutex.Unlock()
	buf := make([]Slave, 0)
	for _, slave := range slaves {
		buf = append(buf, *slave)
	}

	return buf
}

// Broadcast will write the payload to all the slaves
func Broadcast(bytes []byte, count int) int {
	slaves := Clone()
	rand.Seed(time.Now().UnixNano())
	rand.Shuffle(len(slaves), func(i, j int) {slaves[i], slaves[j] = slaves[j], slaves[i]})
	if count < len(slaves) && count >= 1 {
		slaves = slaves[:count]
	}

	writers := 0

	for _, recv := range slaves {
		err := recv.Write(bytes)
		if err != nil {
			continue
		}

		writers++
	}

	return writers
}