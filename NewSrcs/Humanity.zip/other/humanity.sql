DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `username` varchar(255) NOT NULL,
                         `password` varchar(255) NOT NULL,
                         `concurrents` int(11) NOT NULL,
                         `max_time` int(11) NOT NULL,
                         `cooldown` int(11) DEFAULT 10,
                         `SlotBypass` BOOLEAN DEFAULT FALSE,
                         `DurationBypass` BOOLEAN DEFAULT FALSE,
                         `BlacklistBypass` BOOLEAN DEFAULT FALSE,
                         `CooldownBypass` BOOLEAN DEFAULT FALSE,
                         `expiry` BIGINT,
                         `IsAdmin` BOOLEAN DEFAULT FALSE,
                         PRIMARY KEY (`id`)
);

INSERT INTO `users`
(`id`, `username`, `password`, `concurrents`, `max_time`, `cooldown`, `SlotBypass`, `DurationBypass`, `BlacklistBypass`, `CooldownBypass`, `expiry`, `IsAdmin`)
VALUES (1, 'admin', 'meow123', 5, 3000, 0, true, true, true, true, 0, true);
