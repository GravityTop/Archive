package main

import (
	"bufio"
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/olekukonko/tablewriter"
	"golang.org/x/crypto/bcrypt"
	"log"
	"net"
	"strings"
	"time"
)

func main() {
	db, err := sql.Open("mysql", "root:root@tcp(127.0.0.1:3306)/humanity")
	if err != nil {
		log.Fatal(err)
	}
	defer func(db *sql.DB) {
		err := db.Close()
		if err != nil {
			log.Println(err)
		}
	}(db)

	listener, err := net.Listen("tcp", "localhost:12345")
	if err != nil {
		log.Fatal(err)
	}
	defer listener.Close()

	fmt.Println("Telnet server started. Listening on localhost:12345")

	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Println(err)
			continue
		}

		go handleConnection(db, conn)
	}
}

func handleConnection(db *sql.DB, conn net.Conn) {
	defer conn.Close()

	fmt.Fprintf(conn, "Welcome to humanity's admin system!\r\n")
	fmt.Fprintf(conn, " ~ Type 'help' for available commands\r\n")
	fmt.Fprintf(conn, "\r\n")

	scanner := bufio.NewScanner(conn)

	for scanner.Scan() {
		input := scanner.Text()
		parts := strings.Fields(input)

		if len(parts) == 0 {
			continue
		}

		command := parts[0]

		switch command {
		case "insert":
			insertUser(db, conn)
		case "delete":
			if len(parts) < 2 {
				fmt.Fprintln(conn, "usage: delete <userID>")
				continue
			}
			userID := parts[1]
			deleteUser(db, userID, conn)
		case "list":
			listUsers(db, conn)
		case "edit":
			if len(parts) < 4 {
				fmt.Fprintln(conn, "usage: edit <username> <key> <new value>")
				continue
			}
			username := parts[1]
			key := parts[2]
			newValue := parts[3]
			editUser(db, username, key, newValue, conn)
		case "exit":
			fmt.Fprintln(conn, "Goodbye!")
			return
		default:
			fmt.Fprintln(conn, "Invalid command, type 'help' to view all commands.")
		}
	}
}

func insertUser(db *sql.DB, conn net.Conn) {
	var (
		username        string
		password        string
		concurrents     int
		maxTime         int
		BypassBlacklist bool
		CooldownBypass  bool
		DurationBypass  bool
		BlacklistBypass bool
		cooldown        int
		expiryDays      int
	)

	fmt.Fprintf(conn, "Enter Username: ")
	fmt.Fscanln(conn, &username)
	fmt.Fprintf(conn, "Enter Password: ")
	fmt.Fscanln(conn, &password)
	fmt.Fprintf(conn, "Enter Concurrents: ")
	fmt.Fscanln(conn, &concurrents)
	fmt.Fprintf(conn, "Enter Max Time: ")
	fmt.Fscanln(conn, &maxTime)
	fmt.Fprintf(conn, "Enter BlacklistBypass (false or true): ")
	fmt.Fscanln(conn, &BlacklistBypass)
	fmt.Fprintf(conn, "Enter CooldownBypass (false or true): ")
	fmt.Fscanln(conn, &CooldownBypass)
	fmt.Fprintf(conn, "Enter DurationBypass (false or true): ")
	fmt.Fscanln(conn, &DurationBypass)
	fmt.Fprintf(conn, "Enter SlotBypass (false or true): ")
	fmt.Fscanln(conn, &BypassBlacklist)
	fmt.Fprintf(conn, "Enter Cooldown: ")
	fmt.Fscanln(conn, &cooldown)
	fmt.Fprintf(conn, "Enter Expiry (in days): ")
	fmt.Fscanln(conn, &expiryDays)

	var expiry *int64
	if expiryDays > 0 {
		expiryTime := time.Now().Add(time.Duration(expiryDays) * 24 * time.Hour)
		expiryUnix := expiryTime.Unix()
		expiry = &expiryUnix
	}

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		log.Fatal(err)
	}

	_, err = db.Exec("INSERT INTO users (username, password, concurrents, max_time, BlacklistBypass, CooldownBypass, DurationBypass, SlotBypass, cooldown, expiry) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
		username, hashedPassword, concurrents, maxTime, BlacklistBypass, CooldownBypass, DurationBypass, BypassBlacklist, cooldown, expiry)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Fprintf(conn, "User inserted successfully.\r\n")
}

func deleteUser(db *sql.DB, userID string, conn net.Conn) {
	_, err := db.Exec("DELETE FROM users WHERE id=?", userID)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Fprintf(conn, "User deleted successfully.\r\n")
}

func listUsers(db *sql.DB, conn net.Conn) {
	rows, err := db.Query("SELECT id, username, password, concurrents, max_time, SlotBypass, DurationBypass, BlacklistBypass, CooldownBypass, cooldown, expiry FROM users")
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()

	table := tablewriter.NewWriter(conn)
	table.SetHeader([]string{"ID", "Username", "Password", "Concurrents", "Max Time", "SlotBypass", "DurationBypass", "BlacklistBypass", "CooldownBypass", "Cooldown", "Expiry"})

	for rows.Next() {
		var (
			id              int
			username        string
			password        string
			concurrents     int
			maxTime         int
			SlotBypass      bool
			DurationBypass  bool
			BlacklistBypass bool
			CooldownBypass  bool
			cooldown        int
			expiry          sql.NullInt64
		)
		if err := rows.Scan(&id, &username, &password, &concurrents, &maxTime, &SlotBypass, &DurationBypass, &BlacklistBypass, &CooldownBypass, &cooldown, &expiry); err != nil {
			log.Fatal(err)
		}

		expiryString := "N/A"
		if expiry.Valid {
			expiryTime := time.Unix(expiry.Int64, 0)
			remainingDays := int(expiryTime.Sub(time.Now()).Hours() / 24)
			expiryString = fmt.Sprintf("%d days", remainingDays)
		}

		table.Append([]string{fmt.Sprintf("%d", id), username, password, fmt.Sprintf("%d", concurrents), fmt.Sprintf("%d", maxTime), fmt.Sprintf("%t", SlotBypass), fmt.Sprintf("%t", DurationBypass), fmt.Sprintf("%t", BlacklistBypass), fmt.Sprintf("%t", CooldownBypass), fmt.Sprintf("%d", cooldown), expiryString})
	}

	table.Render()
}

func editUser(db *sql.DB, username, key, newValue string, conn net.Conn) {
	switch key {
	case "concurrents", "max_time", "cooldown":
		_, err := db.Exec("UPDATE users SET "+key+"=? WHERE username=?", newValue, username)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Fprintf(conn, "User updated successfully.\r\n")
	case "BlacklistBypass", "CooldownBypass", "DurationBypass", "SlotBypass":
		boolValue := false
		if newValue == "true" {
			boolValue = true
		}
		_, err := db.Exec("UPDATE users SET "+key+"=? WHERE username=?", boolValue, username)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Fprintf(conn, "User updated successfully.\r\n")
	case "password":
		hashedPassword, err := bcrypt.GenerateFromPassword([]byte(newValue), bcrypt.DefaultCost)
		if err != nil {
			log.Fatal(err)
		}
		_, err = db.Exec("UPDATE users SET password=? WHERE username=?", hashedPassword, username)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Fprintf(conn, "Password updated successfully.\r\n")
	default:
		fmt.Fprintf(conn, "Invalid key. Available keys: concurrents, max_time, cooldown, BlacklistBypass, CooldownBypass, DurationBypass, SlotBypass, password\r\n")
	}
}
