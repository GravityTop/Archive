package database

import (
	"database/sql"
	"log"
)

var Db *sql.DB

func Connect() {
	var err error
	Db, err = sql.Open("mysql", "root:root@tcp(127.0.0.1:3306)/humanity")
	if err != nil {
		log.Fatal(err)
	}
}
