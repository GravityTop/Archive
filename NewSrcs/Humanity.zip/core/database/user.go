package database

import (
	"database/sql"
	"golang.org/x/crypto/bcrypt"
	"log"
)

type UserInfo struct {
	// account info
	Concurrents int   `json:"concurrents"`
	MaxTime     int   `json:"max_time"`
	Cooldown    int   `json:"cooldown"`
	Expiry      int64 `json:"expiry"`

	// bypass
	BypassBlacklist bool `json:"BypassBlacklist"`
	SlotBypass      bool `json:"SlotBypass"`
	DurationBypass  bool `json:"DurationBypass"`
	CooldownBypass  bool `json:"CooldownBypass"`
}

func IsValidUser(username, password string) bool {
	query := "SELECT password FROM users WHERE username = ?"
	var storedPassword string
	err := Db.QueryRow(query, username).Scan(&storedPassword)
	if err != nil {
		log.Printf("validation error: %v", err)
		return false
	}

	err = bcrypt.CompareHashAndPassword([]byte(storedPassword), []byte(password))
	if err != nil {
		return false // passwords don't match
	}

	return true // passwords match
}

func GetUserInfo(username string) UserInfo { //`DurationBypass`, `BlacklistBypass`, `CooldownBypass`
	var userInfo UserInfo

	query := "SELECT concurrents, max_time, cooldown, expiry, SlotBypass, DurationBypass, BlacklistBypass, CooldownBypass FROM users WHERE username = ?"
	rows, err := Db.Query(query, username)
	if err != nil {
		log.Printf("Error fetching user info: %v", err)
		return userInfo
	}
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			log.Printf("Error closing rows: %v", err)
		}
	}(rows)

	if rows.Next() {
		err := rows.Scan(&userInfo.Concurrents, &userInfo.MaxTime, &userInfo.Cooldown, &userInfo.Expiry, &userInfo.SlotBypass, &userInfo.DurationBypass, &userInfo.BypassBlacklist, &userInfo.CooldownBypass)
		if err != nil {
			log.Printf("Error scanning user info: %v", err)
		}
	}

	return userInfo
}
