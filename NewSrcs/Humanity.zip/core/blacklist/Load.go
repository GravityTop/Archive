package blacklist

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
)

func IsBlacklisted(host string) bool {
	db, err := sql.Open("mysql", "root:root@tcp(127.0.0.1:3306)/humanity")
	if err != nil {
		fmt.Println("Error opening the database connection:", err)
		return false
	}
	defer db.Close()

	query := "SELECT COUNT(*) FROM blacklist WHERE host = ?"
	var count int
	err = db.QueryRow(query, host).Scan(&count)
	if err != nil {
		fmt.Println("Error querying the database:", err)
		return false
	}
	if count > 0 {
		fmt.Printf("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[1;93mWARN\u001B[0m %s is blacklisted\n", host)
		return true
	}

	return false
}
