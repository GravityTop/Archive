package attacks

func Remove(attack *OngoingAttack) {
	Mutex.Lock()
	defer Mutex.Unlock()

	if attacks, ok := UserOngoingAttacks[attack.Username]; ok {
		for i, a := range attacks {
			if a == attack {
				UserOngoingAttacks[attack.Username] = append(attacks[:i], attacks[i+1:]...)
				break
			}
		}
	}

	for i, a := range GlobalOngoingAttacks {
		if a == attack {
			GlobalOngoingAttacks = append(GlobalOngoingAttacks[:i], GlobalOngoingAttacks[i+1:]...)
			break
		}
	}
}
