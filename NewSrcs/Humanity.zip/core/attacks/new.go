package attacks

import (
	"fmt"
	"github.com/valyala/fasthttp"
	"sync"
	"time"
)

var Mutex sync.Mutex
var UserOngoingAttacks map[string][]*OngoingAttack
var GlobalOngoingAttacks []*OngoingAttack

type OngoingAttack struct {
	Username  string
	StartTime time.Time
	Duration  time.Duration
}

func Request(url string) {
	req := fasthttp.AcquireRequest()
	req.SetRequestURI(url)

	resp := fasthttp.AcquireResponse()

	client := &fasthttp.Client{}
	err := client.Do(req, resp)
	if err != nil {
		fmt.Printf("[http error]: %v\n", err)
	}

	body := resp.Body()

	_ = body

	fasthttp.ReleaseRequest(req)
	fasthttp.ReleaseResponse(resp)
}
