package validation

var MethodConfig map[string]struct {
	APIs []string `json:"apis"`
}

func IsValidMethod(method string) bool {
	_, valid := MethodConfig[method]
	return valid
}
