package validation

import (
	"time"
)

var Cooling = make(map[string]time.Time)

func SetUserCooldown(username string) {
	Cooling[username] = time.Now() // set the cooldown to start now
}

func IsCooldown(username string, cooldown int) bool {
	cooldownTime, ok := Cooling[username]
	if !ok {
		return false // our user isn't on cooldown, proceed
	}

	elapsed := time.Since(cooldownTime) // get the actual time of their cooldown

	return elapsed.Seconds() < float64(cooldown) // return what's left on the cooldown
}
