package validation

import "strings"

func Replace(apiURL, host, port, duration, method string) string {
	apiURL = replacePlaceholder(apiURL, "{host}", host)
	apiURL = replacePlaceholder(apiURL, "{port}", port)
	apiURL = replacePlaceholder(apiURL, "{duration}", duration)
	apiURL = replacePlaceholder(apiURL, "{method}", method)
	return apiURL
}

func replacePlaceholder(input, placeholder, value string) string {
	return strings.Replace(input, placeholder, value, -1)
}
