package discord

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"api/core/config"
)

func LogDiscordWebhook(username, host, port, duration, method string) {
	if config.GetConfig().Logs.Discord.WebhookURL == "" {
		fmt.Println("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[31mERROR\x1b[0m, Webhook isn't set in config!")
		return
	}

	embed := map[string]interface{}{
		"title":     "New attack started!",
		"color":     0xFF0000,
		"timestamp": time.Now().Format(time.RFC3339),
		"fields": []map[string]interface{}{
			{
				"name":   "Username",
				"value":  username,
				"inline": true,
			},
			{
				"name":   "Time Started",
				"value":  time.Now().Format("2006-01-02 15:04:05"),
				"inline": true,
			},
			{
				"name":   "Host",
				"value":  host,
				"inline": true,
			},
			{
				"name":   "Port",
				"value":  port,
				"inline": true,
			},
			{
				"name":   "Duration (seconds)",
				"value":  duration,
				"inline": true,
			},
			{
				"name":   "Method",
				"value":  method,
				"inline": true,
			},
		},
	}

	payload := map[string]interface{}{
		"username": "Humanity",
		"embeds":   []map[string]interface{}{embed},
	}

	payloadBytes, err := json.Marshal(payload)
	if err != nil {
		fmt.Println(err)
		return
	}

	resp, err := http.Post(config.GetConfig().Logs.Discord.WebhookURL, "application/json", bytes.NewBuffer(payloadBytes))
	if err != nil {
		fmt.Println(err)
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != 204 {
		fmt.Printf("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[31mERROR\x1b[0m, Discord webhook responsed with status %d\n", resp.StatusCode)
	}
}
