package config

import (
	"encoding/json"
	"io/ioutil"
)

type DiscordConfig struct {
	WebhookURL string `json:"webhookUrl"`
}

type ApiConfig struct {
	Host string `json:"host"`
	Port int    `json:"port"`
}

type LogsConfig struct {
	Telegram struct {
		BotToken string `json:"botToken"`
		ChatID   string `json:"chatId"`
	} `json:"telegram"`
	Discord DiscordConfig `json:"discord"`
}

type CncConfig struct {
	Host string `json:"host"`
	Port int    `json:"port"`
}

type Config struct {
	Api  ApiConfig  `json:"api"`
	Logs LogsConfig `json:"logs"`
	Cnc  CncConfig  `json:"cnc"`
}

var config Config

func LoadConfig() error {
	configPath := "assets/config.json"
	data, err := ioutil.ReadFile(configPath)
	if err != nil {
		return err
	}

	if err := json.Unmarshal(data, &config); err != nil {
		return err
	}

	return nil
}

func GetConfig() Config {
	return config
}
