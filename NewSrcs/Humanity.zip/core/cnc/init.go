package cnc

import (
	"api/core/cnc/commands"
	"api/core/config"
	"bufio"
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
	"log"
	"net"
	"strconv"
	"strings"
)

type cConn struct {
	net.Conn
}

func (c cConn) Println(s string) {
	c.Write([]byte(s + "\r\n"))
}

func Start(db *sql.DB) {
	listener, err := net.Listen("tcp", config.GetConfig().Cnc.Host+":"+strconv.Itoa(config.GetConfig().Cnc.Port))
	if err != nil {
		log.Fatal(err)
	}
	defer listener.Close()

	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Println(err)
			continue
		}

		go handleConnection(db, cConn{conn})
	}
}

func handleConnection(db *sql.DB, conn cConn) {
	defer conn.Close()

	conn.Println("Welcome to humanity's admin panel.")
	conn.Println("\r\n")

	scanner := bufio.NewScanner(conn)

	for scanner.Scan() {
		input := scanner.Text()
		parts := strings.Fields(input)

		if len(parts) == 0 {
			continue
		}

		command := parts[0]

		switch command {
		case "user":
			commands.Users(db, conn, parts)
		case "exit":
			commands.Exit(conn)
		case "clear":
			conn.Println("\033[2J")
		default:
			conn.Println("Invalid command.")
		}
	}
}
