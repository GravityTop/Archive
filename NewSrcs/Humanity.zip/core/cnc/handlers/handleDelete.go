package handlers

import (
	"database/sql"
	"fmt"
	"log"
	"net"
)

func DeleteUser(db *sql.DB, userID string, conn net.Conn) {
	_, err := db.Exec("DELETE FROM users WHERE id=?", userID)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Fprintf(conn, "User deleted successfully.\r\n")
}
