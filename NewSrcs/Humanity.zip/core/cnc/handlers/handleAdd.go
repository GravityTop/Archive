package handlers

import (
	"database/sql"
	"fmt"
	"golang.org/x/crypto/bcrypt"
	"log"
	"net"
	"time"
)

func AddUser(db *sql.DB, conn net.Conn) {
	var (
		username        string
		password        string
		concurrents     int
		maxTime         int
		BlacklistBypass bool
		CooldownBypass  bool
		DurationBypass  bool
		SlotBypass      bool
		cooldown        int
		expiryDays      int
	)

	fmt.Fprintf(conn, "Enter Username: ")
	fmt.Fscanln(conn, &username)
	fmt.Fprintf(conn, "Enter Password: ")
	fmt.Fscanln(conn, &password)
	fmt.Fprintf(conn, "Enter Concurrents: ")
	fmt.Fscanln(conn, &concurrents)
	fmt.Fprintf(conn, "Enter Max Time: ")
	fmt.Fscanln(conn, &maxTime)
	fmt.Fprintf(conn, "Enter BlacklistBypass (false or true): ")
	fmt.Fscanln(conn, &BlacklistBypass)
	fmt.Fprintf(conn, "Enter CooldownBypass (false or true): ")
	fmt.Fscanln(conn, &CooldownBypass)
	fmt.Fprintf(conn, "Enter DurationBypass (false or true): ")
	fmt.Fscanln(conn, &DurationBypass)
	fmt.Fprintf(conn, "Enter SlotBypass (false or true): ")
	fmt.Fscanln(conn, &SlotBypass)
	fmt.Fprintf(conn, "Enter Cooldown: ")
	fmt.Fscanln(conn, &cooldown)
	fmt.Fprintf(conn, "Enter Expiry (in days): ")
	fmt.Fscanln(conn, &expiryDays)

	var expiry *int64
	if expiryDays > 0 {
		expiryTime := time.Now().Add(time.Duration(expiryDays) * 24 * time.Hour)
		expiryUnix := expiryTime.Unix()
		expiry = &expiryUnix
	}

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		log.Fatal(err)
	}

	_, err = db.Exec("INSERT INTO users (username, password, concurrents, max_time, BlacklistBypass, CooldownBypass, DurationBypass, SlotBypass, cooldown, expiry) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
		username, hashedPassword, concurrents, maxTime, BlacklistBypass, CooldownBypass, DurationBypass, SlotBypass, cooldown, expiry)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Fprintf(conn, "User inserted successfully.\r\n")
}
