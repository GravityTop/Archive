package handlers

import (
	"database/sql"
	"fmt"
	"github.com/olekukonko/tablewriter"
	"log"
	"net"
	"time"
)

func ListUsers(db *sql.DB, conn net.Conn) {
	rows, err := db.Query("SELECT id, username, password, concurrents, max_time, SlotBypass, DurationBypass, BlacklistBypass, CooldownBypass, cooldown, expiry FROM users")
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()

	table := tablewriter.NewWriter(conn)
	table.SetHeader([]string{"ID", "Username", "Password", "Concurrents", "Max Time", "SlotBypass", "DurationBypass", "BlacklistBypass", "CooldownBypass", "Cooldown", "Expiry"})

	for rows.Next() {
		var (
			id              int
			username        string
			password        string
			concurrents     int
			maxTime         int
			SlotBypass      bool
			DurationBypass  bool
			BlacklistBypass bool
			CooldownBypass  bool
			cooldown        int
			expiry          sql.NullInt64
		)
		if err := rows.Scan(&id, &username, &password, &concurrents, &maxTime, &SlotBypass, &DurationBypass, &BlacklistBypass, &CooldownBypass, &cooldown, &expiry); err != nil {
			log.Fatal(err)
		}

		expiryString := "N/A"
		if expiry.Valid {
			expiryTime := time.Unix(expiry.Int64, 0)
			remainingDays := int(expiryTime.Sub(time.Now()).Hours() / 24)
			expiryString = fmt.Sprintf("%d days", remainingDays)
		}

		table.Append([]string{fmt.Sprintf("%d", id), username, password, fmt.Sprintf("%d", concurrents), fmt.Sprintf("%d", maxTime), fmt.Sprintf("%t", SlotBypass), fmt.Sprintf("%t", DurationBypass), fmt.Sprintf("%t", BlacklistBypass), fmt.Sprintf("%t", CooldownBypass), fmt.Sprintf("%d", cooldown), expiryString})
	}

	table.Render()
}
