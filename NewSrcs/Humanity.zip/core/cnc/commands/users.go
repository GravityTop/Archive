package commands

import (
	"api/core/cnc/handlers"
	"database/sql"
	"fmt"
	"net"
)

func Users(db *sql.DB, conn net.Conn, args []string) {
	if len(args) < 2 {
		fmt.Fprintln(conn, "Usage: user <add|delete|edit|list> [args]")
		return
	}

	subcommand := args[1]

	switch subcommand {
	case "add":
		handlers.AddUser(db, conn)
	case "delete":
		if len(args) < 3 {
			fmt.Fprintln(conn, "Usage: user delete <userID>")
			return
		}
		userID := args[2]
		handlers.DeleteUser(db, userID, conn)
	case "list":
		handlers.ListUsers(db, conn)
	case "edit":
		if len(args) < 5 {
			fmt.Fprintln(conn, "Usage: user edit <username> <key> <new value>")
			return
		}
		username := args[2]
		key := args[3]
		newValue := args[4]
		handlers.EditUser(db, username, key, newValue, conn)
	default:
		fmt.Fprintln(conn, "Invalid subcommand. Usage: user <add|delete|edit|list> [args]")
	}
}
