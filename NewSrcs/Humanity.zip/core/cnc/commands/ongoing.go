package commands

import "net"

func Ongoing(conn net.Conn) {
	conn.Write([]byte(""))
}
