package commands

import (
	"fmt"
	"net"
)

func HelpCommand(conn net.Conn) {
	fmt.Fprintf(conn, "Available commands:\r\n")
	fmt.Fprintf(conn, " - add: Add a user\r\n")
	fmt.Fprintf(conn, "   Usage: add\r\n")
	fmt.Fprintf(conn, " - delete: Delete a user\r\n")
	fmt.Fprintf(conn, "   Usage: delete <userID>\r\n")
	fmt.Fprintf(conn, " - list: List all users\r\n")
	fmt.Fprintf(conn, "   Usage: list\r\n")
	fmt.Fprintf(conn, " - edit: Edit user information\r\n")
	fmt.Fprintf(conn, "   Usage: edit <username> <key> <new value>\r\n")
	fmt.Fprintf(conn, " - exit: Exit the C2 server\r\n")
	fmt.Fprintf(conn, "\r\n")
}
