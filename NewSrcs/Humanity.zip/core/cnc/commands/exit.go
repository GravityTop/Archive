package commands

import (
	"fmt"
	"net"
)

func Exit(conn net.Conn) {
	fmt.Fprintln(conn, "Goodbye!")
	return
}
