package telegram

import (
	"api/core/config"
	"fmt"
	"time"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api/v5"
)

func Log(username, host, port, duration, method string) {
	bot, err := tgbotapi.NewBotAPI(config.GetConfig().Logs.Telegram.BotToken)
	if err != nil {
		fmt.Printf("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[31mERROR\x1b[0m, %s\n", err)
	}

	message := tgbotapi.NewMessageToChannel(config.GetConfig().Logs.Telegram.ChatID, "")
	message.Text = "New attack started!\n" +
		"Username: " + username + "\n" +
		"Time started: " + time.Now().Format("2006-01-02 15:04:05") + "\n" +
		"Host: " + host + "\n" +
		"Port: " + port + "\n" +
		"Duration: " + duration + " seconds\n" +
		"Method: " + method
	_, err = bot.Send(message)
	if err != nil {
		fmt.Printf("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[31mERROR\x1b[0m, %s\n", err)
		return
	}
}

func LogBlacklisted(username, host, port, duration, method string) {
	bot, err := tgbotapi.NewBotAPI(config.GetConfig().Logs.Telegram.BotToken)
	if err != nil {
		fmt.Printf("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[31mERROR\x1b[0m, %s\n", err)
	}

	message := tgbotapi.NewMessageToChannel(config.GetConfig().Logs.Telegram.ChatID, "")
	message.Text = "User attempted to attack blacklisted target!\n" +
		"Username: " + username + "\n" +
		"Time started: " + time.Now().Format("2006-01-02 15:04:05") + "\n" +
		"Host: " + host + "\n" +
		"Port: " + port + "\n" +
		"Duration: " + duration + " seconds\n" +
		"Method: " + method
	_, err = bot.Send(message)
	if err != nil {
		fmt.Printf("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[31mERROR\x1b[0m, %s\n", err)
		return
	}
}
