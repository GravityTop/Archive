package modules

import (
	"api/core/validation"
	"encoding/json"
	"io/ioutil"
	"log"
)

func LoadMethods() {
	methodConfigData, err := ioutil.ReadFile("assets/methods.json")
	if err != nil {
		log.Fatal(err) // fatal error: methods file probably doesn't exist or invalid format
	}
	err = json.Unmarshal(methodConfigData, &validation.MethodConfig)
	if err != nil {
		log.Fatal(err)
	}
}
