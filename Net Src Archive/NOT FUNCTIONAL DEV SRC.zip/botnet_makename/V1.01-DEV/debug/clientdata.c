#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>

typedef struct {
    unsigned char connected;
    int fd;
    uint32_t ip;
} BotInfo;

typedef struct Node {
    BotInfo bot;
    struct Node* next;
} Node;

typedef struct {
    Node* head;
    int count;
    pthread_mutex_t lock;
} BotList;

void initializeBotInfo(BotInfo* bot) {
    bot->connected = 0;
    bot->fd = 0;
    bot->ip = 0;
}

void copyBotInfo(BotInfo* dest, const BotInfo* src) {
    dest->connected = src->connected;
    dest->fd = src->fd;
    dest->ip = src->ip;
}

BotList createBotList() {
    BotList list;
    memset(&list, 0, sizeof(BotList));
    list.head = NULL;
    list.count = 0;
    pthread_mutex_init(&(list.lock), NULL);
    return list;
}

int isDuplicateFD(BotList* list, int fd) {
    Node* current = list->head;

    while (current != NULL) {
        if (current->bot.fd == fd) {
            return 1;
        }

        current = current->next;
    }

    return 0;
}

int isDuplicateAddress(BotList* list, uint32_t ip) {
    Node* current = list->head;

    while (current != NULL) {
        if (current->bot.ip == ip) {
            return 1;
        }

        current = current->next;
    }

    return 0;
}

void addBot(BotList* list, BotInfo bot) {
    pthread_mutex_lock(&(list->lock));

    if (list->count > 0) {
        if (isDuplicateAddress(list, bot.ip)) {
            printf("Cannot add bot. Duplicate IP address.\n");
            pthread_mutex_unlock(&(list->lock));
            return;
        }

        if (isDuplicateFD(list, bot.fd)) {
            printf("Cannot add bot. Duplicate file descriptor (fd).\n");
            pthread_mutex_unlock(&(list->lock));
            return;
        }
    }

    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("Memory allocation failed for new node.\n");
        pthread_mutex_unlock(&(list->lock));
        return;
    }
    memset(&(newNode->bot), 0, sizeof(BotInfo));
    initializeBotInfo(&(newNode->bot));
    copyBotInfo(&(newNode->bot), &bot);
    newNode->next = list->head;
    list->head = newNode;
    list->count++;

    pthread_mutex_unlock(&(list->lock));
}

void deleteBot(BotList* list, BotInfo bot) {
    pthread_mutex_lock(&(list->lock));

    Node* current = list->head;
    Node* previous = NULL;

    while (current != NULL) {
        if (memcmp(&(current->bot), &bot, sizeof(BotInfo)) == 0) {
            if (previous == NULL) {
                list->head = current->next;
            }
            else {
                previous->next = current->next;
            }
            memset(current, 0, sizeof(Node));
            free(current);
            current = NULL;

            list->count--;
            break;
        }

        previous = current;
        current = current->next;
    }

    pthread_mutex_unlock(&(list->lock));
}

BotInfo* findBotByIP(BotList* list, uint32_t ip) {
    pthread_mutex_lock(&(list->lock));

    BotInfo* foundBot = NULL;
    Node* current = list->head;

    while (current != NULL) {
        if (current->bot.ip == ip) {
            foundBot = &(current->bot);
            break;
        }

        current = current->next;
    }

    pthread_mutex_unlock(&(list->lock));
    return foundBot;
}

BotInfo* findBotByFD(BotList* list, int fd) {
    pthread_mutex_lock(&(list->lock));

    BotInfo* foundBot = NULL;
    Node* current = list->head;

    while (current != NULL) {
        if (current->bot.fd == fd) {
            foundBot = &(current->bot);
            break;
        }

        current = current->next;
    }

    pthread_mutex_unlock(&(list->lock));
    return foundBot;
}

void cleanup(BotList* list) {
    pthread_mutex_lock(&(list->lock));
    pthread_mutex_destroy(&(list->lock));

    Node* current = list->head;
    Node* temp;

    while (current != NULL) {
        temp = current->next;
        memset(current, 0, sizeof(Node));
        free(current);
        current = NULL;
        current = temp;
    }

    list->head = NULL;
    list->count = 0;

    pthread_mutex_unlock(&(list->lock));
}
// Function to be executed in the pthread
void* testBotList(void* arg) {
    printf("Creating bot list\n");
    BotList botList = createBotList();

    printf("Initializing bots\n");
    // Example usage
    BotInfo bot1, bot2, bot3;

    memset(&bot1, 0, sizeof(BotInfo));
    memset(&bot2, 0, sizeof(BotInfo));
    memset(&bot3, 0, sizeof(BotInfo));

    initializeBotInfo(&bot1);
    initializeBotInfo(&bot2);
    initializeBotInfo(&bot3);

    bot1.ip = 1;
    bot2.ip = 2;
    bot3.ip = 3;
    bot1.fd = 1;
    bot2.fd = 2;
    bot3.fd = 3;

    printf("Adding bots\n");

    addBot(&botList, bot1);
    addBot(&botList, bot2);
    addBot(&botList, bot3);

    printf("Number of bots in the list: %d\n", botList.count); // Output: 3

    uint32_t searchIp = 19216802;
    BotInfo* foundBot = findBotByIP(&botList, searchIp);

    if (foundBot != NULL) {
        printf("Bot with IP %u found. Connected: %d, FD: %d\n", searchIp, foundBot->connected, foundBot->fd);
    }
    else {
        printf("Bot with IP %u not found.\n", searchIp);
    }

    int searchFd = 789;
    foundBot = findBotByFD(&botList, searchFd);

    if (foundBot != NULL) {
        printf("Bot with FD %d found. Connected: %d, IP: %u\n", searchFd, foundBot->connected, foundBot->ip);
    }
    else {
        printf("Bot with FD %d not found.\n", searchFd);
    }

    deleteBot(&botList, bot2);
    printf("Number of bots in the list after deletion: %d\n", botList.count); // Output: 2

    cleanup(&botList);

    pthread_exit(NULL);
}

int main() {
    pthread_t thread;
    pthread_create(&thread, NULL, &testBotList, NULL);
    pthread_join(thread, NULL);

    return 0;
}