#include <windows.h>
 
int main()
{
    SC_HANDLE schSCManager;
    SC_HANDLE schService;
 
    // Get a handle to the SCM database. 
 
    schSCManager = OpenSCManager( 
        NULL,                    // local computer
        NULL,                    // ServicesActive database 
        SC_MANAGER_ALL_ACCESS);  // full access rights 
 
    if (NULL == schSCManager) 
    {
        printf("OpenSCManager failed (%d)\n", GetLastError());
        return 1;
    }
 
    // Create the service
 
    schService = CreateService( 
        schSCManager,              // SCM database 
        "MyDaemonService",         // name of service 
        "My Daemon Service",       // service name to display 
        SERVICE_ALL_ACCESS,        // desired access 
        SERVICE_WIN32_OWN_PROCESS, // service type 
        SERVICE_DEMAND_START,      // start type 
        SERVICE_ERROR_NORMAL,      // error control type 
        "C:\\MyDaemon.exe",        // path to service's binary 
        NULL,                      // no load ordering group 
        NULL,                      // no tag identifier 
        NULL,                      // no dependencies 
        NULL,                      // LocalSystem account 
        NULL);                     // no password 
 
    if (schService == NULL) 
    {
        printf("CreateService failed (%d)\n", GetLastError()); 
        CloseServiceHandle(schSCManager);
        return 1;
    }
    else printf("Service installed successfully\n"); 
 
    // Start the service
 
    if (!StartService( 
            schService,  // handle to service 
            0,           // number of arguments 
            NULL))       // no arguments 
    {
        printf("StartService failed (%d)\n", GetLastError()); 
    }
    else printf("Service started successfully\n"); 
 
    CloseServiceHandle(schService); 
    CloseServiceHandle(schSCManager);
    return 0;
}