echo "Building bot/*.c (STATIC & GDB/VALGRIND DEBUG)"
gcc -o bot.dbg.GDB bot/*.c -DDEBUG -O3 -g
gcc -o bot.dbg.S bot/*.c -DDEBUG -O3 -static

echo "Building controller/src/*.c (STATIC & GDB/VALGRIND DEBUG)"
gcc -o controller/server.x86.S controller/src/*.c -pthread -O3 -static
gcc -o controller/server.x86.GDB controller/src/*.c -pthread -O3 -g


echo "Building NEW FEATURE debug/clientdata.c (STATIC & GDB/VALGRIND DEBUG)"
gcc -o debug/clientdata.x86.S debug/clientdata.c -O3 -static
gcc -o debug/clientdata.x86.GDB debug/clientdata.c -O3 -g

echo "Building POSSIBLE FEATURE debug/data_packer.c (STATIC & GDB/VALGRIND DEBUG)"
gcc -o debug/data_packer.x86.S debug/data_packer.c -O3 -static
gcc -o debug/data_packer.x86.GDB debug/data_packer.c -O3 -g

