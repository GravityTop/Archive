#pragma once

#include <stdint.h>

typedef enum 
{
    FALSE = 0,
    TRUE = 1
} Boolean;

typedef struct 
{
    unsigned char tag[32];
    int connected;
    int fd;
    uint32_t ip;
} BotInfo;

typedef struct 
{
    char commandName[50];
    unsigned char id;
} Command;

typedef struct 
{
    int fd;
    uint32_t ip;
} AdminArgs;

BotInfo *retrieve_all_bots(int *numptrs);

