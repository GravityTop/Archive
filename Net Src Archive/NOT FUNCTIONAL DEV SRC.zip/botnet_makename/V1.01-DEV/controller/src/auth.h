// header
#ifndef AUTH_H
#define AUTH_H

#include <stdbool.h>
#include <time.h>

#define MAXFDS 1000000
#define USER_TIMEOUT 3600
#define MAX_BLACKLIST_SIZE 100
#define MAX_TARGET_LENGTH 100
#define MAX_LINE_LENGTH 200
#define MAX_PLANS 20

typedef enum
{
    USER = 0,
    ADMIN = 1
} UserType;

typedef struct
{
    char username[32];
    char password[32];
    UserType type;
} Credentials;

typedef struct
{
    char username[32];
    int planIndex;
    UserType type;
} UserInfo;

typedef struct
{
    char targets[MAX_BLACKLIST_SIZE][MAX_TARGET_LENGTH];
} Blacklist;

bool validateLogin(const Credentials *credentials, UserInfo *user);

#endif