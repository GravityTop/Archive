#pragma once

#include "headers.h"

typedef void (*command_func)(AdminArgs *admin, unsigned char **argv, int argc);
typedef struct {
  unsigned char name[32];
  command_func func;
} command_t;


void command_init();
unsigned char commandHandler(AdminArgs *admin, unsigned char **argv, int argc);

void bots_cmd(AdminArgs *admin, unsigned char **argv, int argc);
void settings_cmd(AdminArgs *admin, unsigned char **argv, int argc);
