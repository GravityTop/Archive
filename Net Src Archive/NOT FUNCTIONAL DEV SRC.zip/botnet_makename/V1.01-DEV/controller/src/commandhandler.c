#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "commands.h"

static command_t *commands = NULL;
static size_t num_commands = 0;

inline static void command_add(const char *name, command_func funcPTR) {
  command_t *cmd = malloc(sizeof(command_t));
  memset(cmd, 0, sizeof(command_t));

  strncpy(cmd->name, name, sizeof(cmd->name)-1);
  cmd->func = funcPTR;

  commands = realloc(commands, sizeof(command_t) * (num_commands + 1));
  commands[num_commands++] = *cmd;
}

void command_init() {
  command_add("bots", bots_cmd);
  command_add("set", settings_cmd);
}

unsigned char commandHandler(AdminArgs *admin, unsigned char **argv, int argc) {
  int i;
  for (i = 0; i < num_commands; i++) {
    command_t *cmd = &commands[i];
    if (strcmp(argv[0], cmd->name) == 0) {
      cmd->func(admin, argv, argc);
      return 1;
      break;
    }
  }

  return 0;
}
