#include "auth.h"
#include <stdio.h>
#include <string.h>

bool validateLogin(const Credentials *credentials, UserInfo *user)
{
    FILE *file = fopen("credentials.txt", "r");
    if (file == NULL) 
    {
        printf("Error opening credentials file.\n");
        return false;
    }

    char line[256];
    while (fgets(line, sizeof(line), file) != NULL) 
    {
        char storedUsername[50];
        char storedPassword[50];
        char userType[10];

        line[strcspn(line, "\r\n")] = '\0';

        if (sscanf(line, "%49[^:]:%49[^:]:%9[^:]", storedUsername, storedPassword, userType) == 3)
        {
            if (strcmp(credentials->username, storedUsername) == 0 && strcmp(credentials->password, storedPassword) == 0) 
            {
                fclose(file);
                strncpy(user->username, storedUsername, sizeof(user->username) - 1);
                user->username[sizeof(user->username) - 1] = '\0';

                if (strcmp(userType, "admin") == 0)
                    user->type = ADMIN;
                else
                    user->type = USER;
                return true;
            }
        }
    }

    fclose(file);
    return false;
}
