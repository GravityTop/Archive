#pragma once

#include <stdint.h>
#include <netinet/ip.h>
#include "main.h"


void init_rand(uint32_t x);
uint32_t rand_cmwc(void);

void util_zero(void *ptr, size_t len);
void util_memset(void *ptr, int value, size_t num_bytes);
size_t util_strlen(void *ptr);
void util_cpy(void *ptr, void *src, size_t len);

void debug_print(const char * message);
uint8_t **util_tokenize(uint8_t *buf, size_t buf_size, int *count, uint8_t delim);

void init_(void);
int connect_(const int fd, const struct sockaddr* saddr, socklen_t saddr_len);
ssize_t read_(const int sockfd, void *buf, const size_t nbytes);
size_t write_(const int sockfd, const void *buf, const size_t nbytes);
int close_(const int fd);
int socket_(const int domain, const int type, const int protocol);
int bind_(const int sockfd, const struct sockaddr *addr, const socklen_t addrlen);
int listen_(const int sockfd, const int backlog);
int accept_(const int sockfd, struct sockaddr *addr, socklen_t *addrlen);

