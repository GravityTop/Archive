#pragma once

unsigned short checksum(unsigned short *ptr, int nbytes);
unsigned short game_checksum(unsigned short *buf, int nwords);
unsigned short tcp_checksum(struct iphdr *iph, struct tcphdr *tcph, int tcplen);
int rand_int(void);
int randy_int(void);