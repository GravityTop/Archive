#ifdef DEBUG
#include <stdio.h>
#else
#include <stddef.h>
#endif

#ifdef _WIN32
  /* See http://stackoverflow.com/questions/12765743/getaddrinfo-on-win32 */
  #ifndef _WIN32_WINNT
    #define _WIN32_WINNT 0x0501  /* Windows XP. */
  #endif
  #include <winsock2.h>
  #include <Ws2tcpip.h>
  #include <stdint.h>
  #include <sys/types.h>
  #include <errno.h>
  #include <time.h>
#else
  /* Assume that any non-Windows platform uses POSIX-style sockets instead. */
  #include <sys/socket.h>
  #include <arpa/inet.h>
  #include <netdb.h>  /* Needed for getaddrinfo() and freeaddrinfo() */
  #include <unistd.h> /* Needed for close() */
  #include <stdlib.h>
  #include <stdint.h>
  #include <sys/types.h>
  #include <errno.h>
  #include <time.h>
#endif

#include "headers/main.h"
#include "headers/utils.h"
#define PHI 0x9e3779b9
static uint32_t Q[4096], c = 362436;

void init_rand(uint32_t x)
{
        int i;

        Q[0] = x;
        Q[1] = x + PHI;
        Q[2] = x + PHI + PHI;

        for (i = 3; i < 4096; i++) Q[i] = Q[i - 3] ^ Q[i - 2] ^ PHI ^ i;
}

uint32_t rand_cmwc(void)
{
        uint64_t t, a = 18782LL;
        static uint32_t i = 4095;
        uint32_t x, r = 0xfffffffe;
        i = (i + 1) & 4095;
        t = a * Q[i] + c;
        c = (uint32_t)(t >> 32);
        x = t + c;
        if (x < c) {
                x++;
                c++;
        }
        return (Q[i] = r - x);
}

void debug_print(const char *message) 
{
    #ifdef DEBUG
        printf("%s\r\n", message);
    #endif
    #ifdef _WIN32
        OutputDebugStringA(message);
    #endif
}

void init_(void)
{
#ifdef _WIN32
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
#endif
}

/**
 * @brief basic connect() wrapper
 * 
 * @param fd 
 * @param saddr 
 * @param saddr_len 
 */
int connect_(const int fd, const struct sockaddr* saddr, socklen_t saddr_len) {
#ifdef _WIN32
    if (connect(fd, saddr, saddr_len) == SOCKET_ERROR) {
        if (WSAGetLastError() != WSAEWOULDBLOCK) {
            return -1;
        }
        return 0;
    }
#else
    errno = 0;
    if (connect(fd, saddr, saddr_len) < 0) {
        if (errno != EINPROGRESS) {
            return -1;
        }
        return 0;
    }
#endif
    return 1;
}

/**
 * @brief safer read() wrapper
 * 
 * @param sockfd 
 * @param buf 
 * @param nbytes 
 * @return size_t 
 */
ssize_t read_(const int sockfd, void *buf, const size_t nbytes) {
    ssize_t n = 0;
#ifdef _WIN32
    n = recv(sockfd, buf, nbytes, 0);
#else
    n = recv(sockfd, buf, nbytes, MSG_NOSIGNAL);
#endif
    return n;
}

size_t write_(const int sockfd, const void* buf, const size_t nbytes) {
    size_t n;
    size_t bytes_to_send;

    const char* tmp_buff = buf;

    bytes_to_send = nbytes;

    while (TRUE) {
#ifdef _WIN32
        n = send(sockfd, tmp_buff, bytes_to_send, 0);
#else
        n = send(sockfd, tmp_buff, bytes_to_send, MSG_NOSIGNAL);
#endif

        if (n < 0) {
            if (errno == EINTR)
                continue;
            else
                return -errno;
        }

        if ((size_t) n == bytes_to_send)
            break;

        tmp_buff += n;
        bytes_to_send -= n;
    }

    return nbytes;
}

/**
 * @brief basic accept() wrapper
 * 
 * @param sockfd 
 * @param saddr 
 * @param saddrlen_ptr 
 * @return int 
 */
int accept_(const int sockfd, struct sockaddr* saddr, socklen_t* saddrlen_ptr) {
    int fd = accept(sockfd, saddr, saddrlen_ptr);

#ifdef _WIN32
    if (fd == INVALID_SOCKET) {
#else
    if (fd < 0) {
#endif
#ifdef DEBUG
        printf("accept() errorr\r\n");
#endif
    }

    return fd;
}

/**
 * @brief basic listen() wrapper
 * 
 * @param fd 
 * @param backlog 
 */
int listen_(const int fd, const int backlog) {
    if (listen(fd, backlog) < 0) {
#ifdef DEBUG
        printf("listen() error\r\n");
#endif
        return 0;
    }
    return 1;
}

/**
 * @brief basic bind() wrapper
 * 
 * @param fd 
 * @param saddr 
 * @param saddr_len 
 */
int bind_(const int fd, const struct sockaddr* saddr, const socklen_t saddr_len) {
    if (bind(fd, saddr, saddr_len) < 0) {
#ifdef DEBUG
        printf("bind() error\r\n");
#endif
        return 0;
    }
    return 1;
}

/**
 * @brief basic socket() wrapper
 * 
 * @param family 
 * @param type 
 * @param protocol 
 * @return int 
 */
int socket_(const int family, const int type, const int protocol) {
    int sockfd = socket(family, type, protocol);
#ifdef _WIN32
    if (sockfd == INVALID_SOCKET) {
#else
    if (sockfd < 0) {
#endif
#ifdef DEBUG
        printf("socket() error\r\n");
#endif
        return -1;
    }

    return sockfd;
}

void util_memset(void *ptr, int value, size_t num_bytes)
{
    unsigned char *byte_ptr = (unsigned char *)ptr;
    for (size_t i = 0; i < num_bytes; i++)
    {
        *byte_ptr = (unsigned char)value;
        byte_ptr++;
    }
}

void util_zero(void *ptr, size_t len)
{
    if(ptr != NULL)
    {
        uint8_t *bytes = (uint8_t *)ptr;
        size_t x = 0;
        for(x = 0; x < len; x++)
        {
            bytes[x] = 0;
        }
    }
    return;
}

size_t util_strlen(void *ptr)
{
    register unsigned char *ptr_b = NULL;
    unsigned int len = 0;
    ptr_b = ptr;
    while(1)
    {
        if(*ptr_b == 0)
        {
            break;
        }
        len++;
        ptr_b ++;
    }
    return len;
}

void util_cpy(void *ptr, void *src, size_t len)
{
    if(ptr != NULL)
    {
        uint8_t *ptr_bytes = (uint8_t *)ptr;
        uint8_t *src_bytes = (uint8_t *)src;
        size_t x = 0;
        for(x = 0; x < len; x ++)
        {
            ptr_bytes[x] = src_bytes[x];
        }
    }
    return;
}

uint8_t **util_tokenize(uint8_t *buf, size_t buf_size, int *count, uint8_t delim)
{
    uint8_t **ret = NULL;
    size_t ret_count = 0, token_pos = 0;
    uint8_t *token = malloc(512);
    
    if (token == NULL) {
        // Handle malloc failure
    }
    
    util_zero(token, 512);

    for (size_t pos = 0; pos < buf_size; pos++)
    {
        if(buf[pos] == delim)
        {
            token[token_pos] = 0;
            token_pos += 1;
            
            ret = realloc(ret, (ret_count + 1) * sizeof(uint8_t *));
            if (ret == NULL) {
                // Handle realloc failure
            }
            ret[ret_count] = malloc(token_pos + 1);
            if (ret[ret_count] == NULL) {
                // Handle malloc failure
            }
            util_zero(ret[ret_count], token_pos+1);
            util_cpy(ret[ret_count], token, token_pos);
            ret_count++;

            util_zero(token, 512);
            token_pos = 0;
            continue;
        }

        token[token_pos] = buf[pos];
        token_pos++;
        if (token_pos == 512)
        {
            util_zero(token, 512);
            token_pos = 0;
        }
    }

    if (token_pos > 0)
    {
        token[token_pos] = 0;
        token_pos += 1;
        
        ret = realloc(ret, (ret_count + 1) * sizeof(uint8_t *));
        if (ret == NULL) {
            // Handle realloc failure
        }
        ret[ret_count] = malloc(token_pos + 1);
        if (ret[ret_count] == NULL) {
            // Handle malloc failure
        }
        util_zero(ret[ret_count], token_pos+1);
        util_cpy(ret[ret_count], token, token_pos);
        ret_count++;

        util_zero(token, 512);
        token_pos = 0;
    }

    *count = ret_count;

    util_zero(token, 512);
    free(token);

    if (ret_count > 0) return ret;


    /*if (ret != NULL) {
        for (size_t i = 0; i < ret_count; i++) {
            free(ret[i]);
        }
        free(ret);
    }
    */
    return NULL;
}

