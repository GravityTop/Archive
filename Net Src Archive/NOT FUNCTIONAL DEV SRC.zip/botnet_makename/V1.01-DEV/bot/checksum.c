// checksum
#ifdef DEBUG
#include <stdio.h>
#else
#include <stddef.h>
#endif


#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <sys/socket.h>

struct tcp_pseudo
{
    uint32_t src_addr;
    uint32_t dst_addr;
    uint8_t zero;
    uint8_t proto;
    uint16_t length;
} __attribute__((packed));

unsigned int randy_int(void)
{
    unsigned int min_value = 0x21435894;  // Minimum value: 21 43 58 94
    unsigned int max_value = 0xfe9745f9;  // Maximum value: fe 97 45 f9
    return min_value + rand() % (max_value - min_value + 1);
}

unsigned int rand_int(void)
{
    srand(time(NULL));
    unsigned int a = rand() % 0xffff;
    return a;
}

unsigned short game_checksum(unsigned short *buf, int nwords)
{
    unsigned long sum;
    for (sum = 0; nwords > 0; nwords--)
        sum += *buf++;
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    return (unsigned short)(~sum);
}

unsigned short checksum(unsigned short *buf, int count)
{
    register uint64_t sum = 0;
    while (count > 1)
    {
        sum += *buf++;
        count -= 2;
    }
    if (count > 0)
    {
        sum += *(unsigned char *)buf;
    }
    while (sum >> 16)
    {
        sum = (sum & 0xffff) + (sum >> 16);
    }
    return (uint16_t)(~sum);
}

unsigned short tcp_checksum(struct iphdr *iph, struct tcphdr *tcph, int tcplen)
{
    struct tcp_pseudo pseudohead;

    pseudohead.src_addr = iph->saddr;
    pseudohead.dst_addr = iph->daddr;
    pseudohead.zero = 0;
    pseudohead.proto = IPPROTO_TCP;
    pseudohead.length = htons(tcplen);

    int totaltcp_len = sizeof(struct tcp_pseudo) + tcplen;
    unsigned char *tcp = malloc(totaltcp_len);
    memcpy(tcp, (unsigned char *)&pseudohead, sizeof(struct tcp_pseudo));
    memcpy(tcp + sizeof(struct tcp_pseudo), (unsigned char *)tcph, tcplen);

    unsigned short output = checksum((unsigned short *)tcp, totaltcp_len);
    free(tcp);

    return output;
}