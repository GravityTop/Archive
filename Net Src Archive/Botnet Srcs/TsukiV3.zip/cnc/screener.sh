ulimit -n 999999
screen -S cnc ./control 56744 56005 750
sh screen.sh